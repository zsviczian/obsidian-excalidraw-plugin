import type ExcalidrawPlugin from "src/core/main";
import { ExcalidrawLib } from "../../types/excalidrawLib";
/**
 * Creates the plugin-wide capability adapter consumed by the evaluated
 * Excalidraw package runtime.
 *
 * @remarks
 * Settings methods read current values rather than capturing a stale snapshot.
 * The adapter exposes only semantic operations and never the plugin instance,
 * settings object, or active-view state.
 */
export declare const createObsidianExcalidrawHostAdapter: (plugin: ExcalidrawPlugin, protocolVersion: typeof ExcalidrawLib.OBSIDIAN_EXCALIDRAW_HOST_PROTOCOL_VERSION) => ExcalidrawLib.ObsidianExcalidrawHostAdapter;
