import type ExcalidrawPlugin from "src/core/main";
import { ExcalidrawLib } from "../../types/excalidrawLib";
/**
 * Creates the narrow, window-runtime host adapter consumed by the Excalidraw
 * fork's common and element packages.
 *
 * @remarks
 * Capability methods read current plugin state rather than capturing settings
 * values. The package manager owns both this adapter and its disposer, so the
 * adapter cannot outlive the corresponding evaluated Excalidraw runtime.
 */
export declare const createObsidianCommonHostAdapter: (plugin: ExcalidrawPlugin, protocolVersion: typeof ExcalidrawLib.OBSIDIAN_COMMON_HOST_PROTOCOL_VERSION) => ExcalidrawLib.ObsidianCommonHostAdapter;
