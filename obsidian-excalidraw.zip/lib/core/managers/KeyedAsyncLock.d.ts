/** Serializes asynchronous operations sharing the same key. */
export declare class KeyedAsyncLock {
    private readonly tails;
    run<T>(key: string, operation: () => Promise<T>): Promise<T>;
}
