export type DrawingModifyRoute = "full-reload" | "incremental-sync" | "raw-reload";
/** Whether a suppressed notification must still reach content inspection. */
export declare const shouldInspectSuppressedModifyContent: (fileExtension: string) => boolean;
interface DrawingModifyRouteInput {
    fileExtension: string;
    isEditingMarkdownSideInSplitView: boolean;
    isDirty: boolean;
    isPersistenceBusy: boolean;
    isStale: boolean;
}
/**
 * Selects how an open drawing consumes one matching Vault modify event.
 *
 * A dirty or busy Markdown view must reconcile rather than replace its live
 * scene, even when the existing inactivity heuristic would otherwise request
 * a full reload.
 */
export declare const getDrawingModifyRoute: ({ fileExtension, isEditingMarkdownSideInSplitView, isDirty, isPersistenceBusy, isStale, }: DrawingModifyRouteInput) => DrawingModifyRoute;
export {};
