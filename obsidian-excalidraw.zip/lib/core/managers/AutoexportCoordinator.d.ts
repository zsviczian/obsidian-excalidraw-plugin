import type ExcalidrawPlugin from "../main";
import type { ExcalidrawViewScene } from "../../types/excalidrawViewTypes";
import { type PreparedSaveExportData, type PreparedSaveExportOptions, type SaveOperationContext } from "../../view/managers/saveSnapshot";
import { type AutoexportSaveBatchScheduler } from "./AutoexportSaveBatchGate";
export type AutoexportFormat = "svg" | "png" | "excalidraw";
export type AutoexportTheme = "light" | "dark" | null;
export interface PreparedAutoexportOutput {
    readonly format: AutoexportFormat;
    readonly theme: AutoexportTheme;
    readonly destinationPath: string;
}
interface PreparedAutoexportRequestBase extends SaveOperationContext {
    readonly sourceFilePath: string;
    readonly sourceFileCtime: number;
    readonly capturedRevision: number;
}
/** Lightweight marker preventing an older revision from writing stale output. */
export interface PreparedAutoexportBarrierRequest extends PreparedAutoexportRequestBase {
    readonly kind: "barrier";
    readonly outputs: readonly [];
}
/** Immutable render intent captured while the originating view is alive. */
export interface PreparedAutoexportRenderRequest extends PreparedAutoexportRequestBase {
    readonly kind: "render";
    readonly scene: ExcalidrawViewScene;
    readonly exportOptions: PreparedSaveExportOptions;
    readonly exportData: PreparedSaveExportData | null;
    readonly outputs: readonly PreparedAutoexportOutput[];
}
export type PreparedAutoexportRequest = PreparedAutoexportBarrierRequest | PreparedAutoexportRenderRequest;
interface AutoexportScheduler extends AutoexportSaveBatchScheduler {
    readonly now: () => number;
}
/**
 * Runs automatic exports after successful source persistence.
 *
 * One request is active per source identity and only its newest trailing
 * request is retained. Heavy rendering is serialized globally and yields
 * between formats. Final writes additionally compare the hook-resolved
 * destination, preventing an older render from overwriting newer output.
 */
export declare class AutoexportCoordinator {
    private readonly plugin;
    private readonly scheduler;
    private readonly queue;
    private readonly saveBatchGate;
    private readonly renderExecution;
    private readonly destinationWrites;
    private readonly deferredMigrations;
    constructor(plugin: ExcalidrawPlugin, scheduler: AutoexportScheduler);
    /** Accepts one prepared request in successful source-write order. */
    enqueue(request: PreparedAutoexportRequest): void;
    /** Holds automatic rendering while one view drains its save queue. */
    beginSaveActivity(sourceFilePath: string, sourceFileCtime: number): () => void;
    /** Defers migration rendering while immediately invalidating older output. */
    deferUntilMigrationComplete(leafId: string, request: PreparedAutoexportRequest): void;
    /** Releases or discards the render after the replacement load settles. */
    completeMigration(leafId: string, filePath: string, loadSucceeded: boolean): void;
    /** Prevents work owned by an unloaded plugin runtime from writing later. */
    destroy(): void;
    private createBarrier;
    private execute;
    private prepareThemeContext;
    private createDataSource;
    private renderSVG;
    private renderPNG;
    private createRenderScene;
    private getExportSettings;
    private writeIfCurrent;
    private resolveSourceFile;
    private getSourceKey;
    private getSourceKeyFromIdentity;
    private yieldToMainTask;
}
export {};
