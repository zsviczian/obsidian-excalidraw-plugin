import { PackageLease, Packages } from "../../types/types";
import type ExcalidrawPlugin from "src/core/main";
/**
 * Owns the plugin's single private React/Excalidraw runtime.
 *
 * Each view receives the same package but retains an idempotent lease keyed by
 * its actual window. The window key governs migration persistence and the
 * temporary `ExcalidrawLib` compatibility alias only; rendering ownership is
 * supplied independently through each Excalidraw instance's `ownerDocument`.
 */
export declare class PackageManager {
    private readonly plugin;
    private runtimePackage;
    private packageLeaseCountMap;
    private commonHostDisposer;
    private excalidrawHostDisposer;
    private runtimeAliasWindows;
    constructor(plugin: ExcalidrawPlugin);
    /**
     * Validates that a package contains all required components
     */
    private validatePackage;
    /**
     * Registers plugin capabilities with one evaluated Excalidraw runtime.
     */
    private configureObsidianCommonHost;
    /** Registers plugin-wide settings with one evaluated Excalidraw runtime. */
    private configureObsidianExcalidrawHost;
    /** Disposes the plugin capabilities registered with the shared runtime. */
    private disposeObsidianHosts;
    /** Stores and configures the plugin's single evaluated runtime package. */
    private setRuntimePackage;
    /** Returns the one runtime used by every main-window and popout view. */
    getRuntimePackage(): Packages;
    /**
     * Acquires the shared runtime while retaining the view's actual window.
     *
     * @remarks
     * Window identity remains view-owned migration/persistence state. Popout
     * leases additionally own the temporary `window.ExcalidrawLib` compatibility
     * alias and remove it when the final view in that window releases its lease.
     */
    acquirePackage(win: Window): PackageLease;
    /** Releases one view-owned package lease without consulting mutable DOM. */
    private releasePackageLease;
    /**
     * Returns the shared runtime and exposes its compatibility API in `win`.
     *
     * @remarks
     * The runtime is never evaluated in the supplied window. Rendering ownership
     * is provided separately through Excalidraw's stable `ownerDocument` prop.
     */
    getPackage(win: Window): Packages;
    /** Removes only the window-local alias; the shared runtime remains alive. */
    private removeRuntimeAlias;
    /**
     * Compatibility facade retained for callers that explicitly clean a window.
     * The plugin-wide runtime and host registrations live until `destroy()`.
     */
    deletePackage(win: Window): void;
    destroy(): void;
}
