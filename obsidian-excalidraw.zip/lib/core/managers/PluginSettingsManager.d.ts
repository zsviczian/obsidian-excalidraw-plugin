import { type App, type PluginManifest } from "obsidian";
import { type ExcalidrawSettings } from "src/core/settingsDefaults";
import { type SettingsRecoveryChoice, type SettingsRecoveryPromptMode } from "src/shared/Dialogs/SettingsRecoveryPrompt";
type PersistedExcalidrawSettings = Partial<ExcalidrawSettings> & Record<string, unknown>;
interface PluginSettingsHost {
    app: App;
    manifest: PluginManifest;
    settings: ExcalidrawSettings;
    loadData(): Promise<unknown>;
    saveData(data: unknown): Promise<void>;
}
interface SettingsRecoveryStoreLike {
    load(): Promise<PersistedExcalidrawSettings | null>;
    save(settings: PersistedExcalidrawSettings): Promise<void>;
    destroy(): void;
}
type SettingsRecoveryPromptHandler = (mode: SettingsRecoveryPromptMode) => Promise<SettingsRecoveryChoice>;
/**
 * Owns plugin settings persistence, default assembly, and compatibility
 * migrations while leaving startup readiness and settings UI registration to
 * the plugin lifecycle.
 */
export declare class PluginSettingsManager {
    private readonly host;
    private readonly writer;
    private readonly recoveryStore;
    private hasCompletedInitialLoad;
    private persistenceBlockedByInvalidData;
    private missingRecoveryNoticeShown;
    private awaitingStartupRecoveryChoice;
    private readonly promptForRecoveryChoice;
    constructor(host: PluginSettingsHost, recoveryStore?: SettingsRecoveryStoreLike, promptForRecoveryChoice?: SettingsRecoveryPromptHandler);
    /**
     * Loads persisted settings, applies defaults and migrations, and decrypts
     * protected API-key fields.
     *
     * @remarks Unknown persisted properties are intentionally retained.
     * @returns `false` when the disk payload was invalid. Runtime callers use
     * this to suppress cache invalidation for a rejected synchronized payload.
     */
    loadSettings(): Promise<boolean>;
    /** Encrypts protected fields and persists the current settings object. */
    saveSettings(): Promise<void>;
    /** Whether plugin startup is intentionally waiting for a recovery choice. */
    get isAwaitingStartupRecoveryChoice(): boolean;
    private persistSnapshot;
    /** Closes the device-local recovery database connection. */
    destroy(): void;
    private getSettingsDataFileState;
    private blockPersistenceWhileWaitingForFile;
    private showMissingRecoveryNotice;
    private requestStartupRecoveryChoice;
    private loadRecoverySnapshot;
    private saveRecoverySnapshot;
}
export {};
