import type { Packages } from "src/types/types";
import type ExcalidrawPlugin from "src/core/main";
type RuntimePackageProvider = () => Packages;
/**
 * Owns CJK and custom-font discovery, document registration, and
 * readiness state while preserving the plugin's existing public font facade.
 */
export declare class FontManager {
    private readonly plugin;
    private readonly getRuntimePackage;
    private isLocalCJKFontAvailabe;
    private fontsReady;
    private readonly registeredFontFaces;
    constructor(plugin: ExcalidrawPlugin, getRuntimePackage: RuntimePackageProvider);
    /** Whether font initialization permits the plugin readiness wait to finish. */
    get isReady(): boolean;
    /** Returns the enabled CJK ranges when local CJK font assets are available. */
    getCJKFontSettings(): {
        c: boolean;
        j: boolean;
        k: boolean;
    };
    /** Reads a configured CJK font asset from the vault. */
    loadFontFromFile(fontName: string): Promise<ArrayBuffer | undefined>;
    /**
     * Loads configured CJK and custom fonts into every open Obsidian document
     * and registers custom font metrics with the shared Excalidraw runtime.
     */
    initializeFonts(): Promise<void>;
    private registerFontFaces;
    /** Removes custom and CJK font registrations from all open documents. */
    removeFonts(): void;
    private getOpenObsidianDocuments;
}
export {};
