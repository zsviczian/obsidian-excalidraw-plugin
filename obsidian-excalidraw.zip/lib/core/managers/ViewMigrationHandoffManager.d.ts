import type { AppState, BinaryFiles } from "@zsviczian/excalidraw/types/excalidraw/types";
import type { ExcalidrawElement } from "@zsviczian/excalidraw/types/element/src/types";
import type { ExcalidrawDataMigrationState } from "../../shared/ExcalidrawData";
import type { TextMode } from "../../shared/TextMode";
import type { ViewSaveMigrationState } from "../../view/managers/ViewSaveCoordinator";
/** Drawing-owned runtime state that may cross an Obsidian window migration. */
export interface ViewMigrationDrawingState {
    elements: readonly ExcalidrawElement[];
    appState: AppState;
    files: BinaryFiles;
    textMode: TextMode;
    compatibilityMode: boolean;
    excalidrawData: ExcalidrawDataMigrationState;
    save: ViewSaveMigrationState;
}
/** Metadata used to register one transient migration handoff. */
export interface ViewMigrationHandoffRegistration {
    leafId: string;
    filePath: string;
    fileMtime: number;
    drawing: ViewMigrationDrawingState;
}
/** Identity and freshness checks required to consume a migration handoff. */
export interface ViewMigrationHandoffRequest {
    token: string;
    leafId: string;
    filePath: string;
    fileMtime: number;
}
interface ViewMigrationHandoffScheduler {
    now: () => number;
    setTimeout: (callback: () => void, delay: number) => number;
    clearTimeout: (timer: number) => void;
}
interface ViewMigrationHandoffManagerOptions {
    ttlMs?: number;
    scheduler?: ViewMigrationHandoffScheduler;
}
/**
 * Owns bounded, one-shot drawing handoffs between recreated views.
 *
 * Entries contain drawing state only. They never retain an `ExcalidrawView`,
 * React root, DOM node, `Window`, listener, or package lease. Consumption
 * removes the entry before validation so stale or mismatched state cannot be
 * retried, and a single expiry timer bounds abandoned payload lifetime.
 */
export declare class ViewMigrationHandoffManager {
    private readonly ttlMs;
    private readonly scheduler;
    private readonly entries;
    private readonly tokensByLeaf;
    private cleanupTimer;
    private tokenSequence;
    constructor(options?: ViewMigrationHandoffManagerOptions);
    /** Registers a handoff, replacing any older payload for the same leaf. */
    register(registration: ViewMigrationHandoffRegistration): string;
    /**
     * Consumes a matching handoff exactly once.
     *
     * A token mismatch, leaf/path mismatch, file modification, or TTL expiry
     * returns `null` and discards the candidate so the caller must use its
     * ordinary disk-backed load path.
     */
    consume(request: ViewMigrationHandoffRequest): ViewMigrationDrawingState | null;
    /** Drops all retained drawing state and cancels expiry work. */
    destroy(): void;
    private deleteEntry;
    private pruneExpired;
    private scheduleCleanup;
}
export {};
