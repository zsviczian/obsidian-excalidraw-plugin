import type ExcalidrawPlugin from "src/core/main";
/**
 * Registers workspace monkey patches that adapt Obsidian behavior
 * for Excalidraw and known plugin integrations.
 */
export declare class MonkeyPatchManager {
    private readonly plugin;
    constructor(plugin: ExcalidrawPlugin);
    initialize(): void;
    private patchTemplaterGetActiveViewOfType;
    private patchHoverEditorGetRoot;
    private patchWorkspaceLeafExcalidrawDefault;
    private static isCallerFromTemplaterPlugin;
}
