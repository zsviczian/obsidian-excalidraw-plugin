export interface AutoexportSaveBatchScheduler {
    readonly setTimeout: (callback: () => void, delayMs: number) => number;
    readonly clearTimeout: (timer: number) => void;
}
interface AutoexportSaveBatchGateOptions<T> {
    readonly scheduler: AutoexportSaveBatchScheduler;
    readonly settleDelayMs: number;
    readonly getSourceKey: (request: T) => string;
    readonly shouldRender: (request: T) => boolean;
    readonly invalidate: (request: T) => void;
    readonly release: (request: T) => void;
}
/** Coalesces persisted snapshots until every known save loop is idle. */
export declare class AutoexportSaveBatchGate<T> {
    private readonly options;
    private destroyed;
    private readonly sourceStates;
    constructor(options: AutoexportSaveBatchGateOptions<T>);
    /** Marks one view-owned save loop active for a source identity. */
    beginActivity(sourceKey: string): () => void;
    /** Accepts the newest successfully persisted snapshot for one source. */
    publish(request: T): void;
    destroy(): void;
    private getOrCreateState;
    private schedulePending;
    private cancelTimer;
    private deleteIfEmpty;
}
export {};
