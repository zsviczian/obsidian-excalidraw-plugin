import { MarkdownPostProcessorContext } from "obsidian";
import type ExcalidrawPlugin from "../main";
import { CustomMutationObserver } from "../../utils/debugHelper";
export declare const initializeMarkdownPostProcessor: (p: ExcalidrawPlugin) => void;
/**
 *
 * @param el
 * @param ctx
 */
export declare const markdownPostProcessor: (el: HTMLElement, ctx: MarkdownPostProcessorContext) => Promise<void>;
/**
 * internal-link quick preview
 * @param e
 * @returns
 */
export declare const hoverEvent: (e: MouseEvent & {
    linktext?: string;
    sourcePath?: string;
}) => void;
export declare const legacyExcalidrawPopoverObserver: CustomMutationObserver | MutationObserver;
