import { FrontMatterCache, TAbstractFile, TFile } from "obsidian";
import type ExcalidrawPlugin from "src/core/main";
import { PaneTarget } from "src/types/utilTypes";
export declare class PluginFileManager {
    private plugin;
    private app;
    private excalidrawFiles;
    get settings(): import("../settingsDefaults").ExcalidrawSettings;
    constructor(plugin: ExcalidrawPlugin);
    initialize(): Promise<void>;
    /**
     * Returns whether a vault file is an Excalidraw drawing.
     *
     * Parsed frontmatter is authoritative when available. During a vault write,
     * Obsidian can temporarily remove that frontmatter from the metadata cache;
     * in that gap, retain the last confirmed classification from
     * {@link excalidrawFiles}. The metadata `changed` event updates that set, so
     * deliberately removing the Excalidraw frontmatter still declassifies the
     * file once the replacement metadata is published.
     */
    isExcalidrawFile(f: TFile): boolean;
    updateFileCache(file: TFile, frontmatter?: FrontMatterCache, deleted?: boolean): void;
    getExcalidrawFiles(): Set<TFile>;
    destroy(): void;
    createDrawing(filename: string, foldername?: string, initData?: string): Promise<TFile>;
    getBlankDrawing(): Promise<string>;
    embedDrawing(file: TFile): Promise<void>;
    exportLibrary(): Promise<void>;
    /**
     * Opens a drawing file
     * @param drawingFile
     * @param location
     * @param active
     * @param subpath
     * @param justCreated
     * @param popoutLocation
     */
    openDrawing(drawingFile: TFile, location: PaneTarget, active?: boolean, subpath?: string, justCreated?: boolean, popoutLocation?: {
        x?: number;
        y?: number;
        width?: number;
        height?: number;
    }): void;
    /**
     * Extracts the text elements from an Excalidraw scene into a string of ids as headers followed by the text contents
     * @param {string} data - Excalidraw scene JSON string
     * @returns {string} - Text starting with the "# Text Elements" header and followed by each "## id-value" and text
     */
    exportSceneToMD(data: string, compressOverride?: boolean): Promise<string>;
    /**
     * Extracts binary files embedded in a converted legacy scene and rewrites
     * the Markdown drawing with durable vault attachment links.
     *
     * The target file must already exist because Obsidian determines its
     * attachment folder relative to that file. This method resolves only after
     * every embedded file has been persisted.
     */
    persistLegacySceneFilesInMarkdown(markdown: string, file: TFile): Promise<string>;
    /**
     * watch filename change to rename .svg, .png; to sync to .md; to update links
     * @param file
     * @param oldPath
     * @returns
     */
    renameEventHandler(file: TAbstractFile, oldPath: string): Promise<void>;
    modifyEventHandler(file: TAbstractFile): Promise<void>;
    private removeBAKFromCache;
    private moveBAKFile;
    /**
     * watch file delete and delete corresponding .svg and .png
     * @param file
     * @returns
     */
    deleteEventHandler(file: TAbstractFile): Promise<void>;
}
