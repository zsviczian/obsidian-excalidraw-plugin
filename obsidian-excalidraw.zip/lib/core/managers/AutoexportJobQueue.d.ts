export interface AutoexportJobGuard {
    readonly sequence: number;
    isCurrentSource(): boolean;
    isCurrentDestination(destinationKey: string): boolean;
}
interface AutoexportJobQueueOptions<T> {
    readonly getSourceKey: (job: T) => string;
    readonly getDestinationKeys: (job: T) => readonly string[];
    readonly execute: (job: T, guard: AutoexportJobGuard) => Promise<void>;
    readonly onFailure?: (error: unknown) => void;
    readonly schedule?: (callback: () => void) => void;
}
/** One active job and one newest trailing job for each source identity. */
export declare class AutoexportJobQueue<T> {
    private readonly options;
    private destroyed;
    private sequence;
    private readonly sourceStates;
    private readonly latestSourceSequence;
    private readonly latestDestinationSequence;
    private readonly destinationReferences;
    constructor(options: AutoexportJobQueueOptions<T>);
    enqueue(job: T): void;
    /** Invalidates pending/final-write guards without interrupting source saves. */
    destroy(): void;
    private drain;
    private scheduleDrain;
    private createGuard;
    private releaseDestinations;
}
export {};
