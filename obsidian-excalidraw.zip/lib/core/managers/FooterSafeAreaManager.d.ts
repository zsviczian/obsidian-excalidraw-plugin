import type { App } from "obsidian";
import type { ExcalidrawSettings } from "src/core/settingsDefaults";
interface FooterSafeAreaHost {
    app: App;
    settings: ExcalidrawSettings;
}
/**
 * Owns the optional phone and tablet footer-padding stylesheet across Obsidian
 * documents, including cleanup when the plugin unloads.
 */
export declare class FooterSafeAreaManager {
    private readonly host;
    constructor(host: FooterSafeAreaHost);
    /** Applies or removes footer padding according to the current device and settings. */
    updateFooterSafeAreaPadding(): void;
    /** Removes every footer-padding stylesheet owned by the plugin. */
    destroy(): void;
    private getOpenObsidianDocuments;
}
export {};
