import type ExcalidrawPlugin from "src/core/main";
import type ExcalidrawView from "src/view/ExcalidrawView";
export declare class ObserverManager {
    private plugin;
    private app;
    private themeObserver;
    private fileExplorerObserver;
    private modalContainerObserver;
    private modalObservedView;
    private workspaceDrawerLeftObserver;
    private workspaceDrawerRightObserver;
    private activeViewDoc;
    get settings(): import("../settingsDefaults").ExcalidrawSettings;
    constructor(plugin: ExcalidrawPlugin);
    initialize(): void;
    destroy(): void;
    addThemeObserver(): void;
    removeThemeObserver(): void;
    experimentalFileTypeDisplayToggle(enabled: boolean): void;
    /**
     * Display characters configured in settings, in front of the filename, if the markdown file is an excalidraw drawing
     * Must be called after the workspace is ready
     * The function is called from onload()
     */
    private experimentalFileTypeDisplay;
    /**
     * Saves a dirty drawing when an Obsidian modal opens in its live document.
     *
     * @param view - The active or same-leaf replacement view to observe.
     */
    addModalContainerObserver(view?: ExcalidrawView): void;
    removeModalContainerObserver(): void;
    private addWorkspaceDrawerObserver;
}
