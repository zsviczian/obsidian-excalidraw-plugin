export interface ViewMigrationPersistenceHandoff {
    leafId: string;
    filePath: string;
    data: string;
}
/**
 * Owns bounded serialized drawing handoffs from a destroyed popout view to
 * the replacement view in Obsidian's main window.
 *
 * Entries contain drawing text and stable identifiers only. They never retain
 * a view, DOM node, React runtime, package lease, or Window. Consumption is
 * one-shot, and abandoned entries expire promptly.
 */
export declare class ViewMigrationPersistenceHandoffManager {
    private readonly entries;
    private cleanupTimer;
    /** Registers or replaces the pending drawing text for one workspace leaf. */
    register(handoff: ViewMigrationPersistenceHandoff): void;
    /** Consumes matching drawing text exactly once. */
    consume(leafId: string, filePath: string): string | null;
    /** Discards an abandoned handoff after a failed view replacement. */
    discard(leafId: string): void;
    /** Clears retained text and its main-window cleanup timer. */
    destroy(): void;
    private pruneExpired;
    private scheduleCleanup;
}
