/** Stores and formats plugin startup timing events without owning startup order. */
export declare class StartupTimer {
    private readonly pluginVersion;
    private readonly events;
    private lastLogTimestamp;
    constructor(initialTimestamp: number, pluginVersion: string);
    /**
     * Starts a new timing baseline while retaining events recorded before the
     * reset, matching the existing constructor-to-layout startup breakdown.
     */
    reset(timestamp: number): void;
    /** Records one startup event with total and previous-event elapsed times. */
    logEvent(message: string, loadTimestamp: number): void;
    /** Writes the complete startup timing breakdown to the debug log. */
    printBreakdown(): void;
}
