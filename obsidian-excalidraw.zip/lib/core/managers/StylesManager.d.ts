import type ExcalidrawPlugin from "src/core/main";
export declare let REM_VALUE: number;
export declare class StylesManager {
    private stylesMap;
    private styleLight;
    private styleDark;
    private plugin;
    constructor(plugin: ExcalidrawPlugin);
    private onCSSChange;
    private onWindowOpen;
    private onWindowClose;
    private harvestStyles;
    private copyPropertiesToTheme;
    destroy(): void;
}
