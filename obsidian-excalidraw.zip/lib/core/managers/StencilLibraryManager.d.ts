import type { LibraryItems } from "@zsviczian/excalidraw/types/excalidraw/types";
import type ExcalidrawPlugin from "src/core/main";
/**
 * Owns stencil-library persistence and keeps each item's source file stable.
 * Vault writes are reconciled with the latest file contents to avoid clobbering
 * files updated by sync after the library was loaded.
 */
export declare class StencilLibraryManager {
    private readonly plugin;
    private itemSource;
    private currentItems;
    private loaded;
    private loadRevision;
    private loadPromise;
    private migrationPrompt;
    private saveQueue;
    private reloadTimer;
    private readonly ownWritePaths;
    private isUpdatingOpenViews;
    constructor(plugin: ExcalidrawPlugin);
    hasLegacyItems(): boolean;
    invalidate(): void;
    getLibrary(): Promise<LibraryItems>;
    setLibrary(items: LibraryItems): Promise<void>;
    showMigrationPrompt(): Promise<void>;
    switchToLegacyStorage(): Promise<void>;
    /** Reloads the merged vault library in every initialized Excalidraw view. */
    reloadLibrariesInOpenViews(): Promise<void>;
    private ensureMigrationDecision;
    private runMigrationPrompt;
    private migrateLegacyLibrary;
    private scheduleOpenViewReload;
    private getVaultLibrary;
    /** Coalesces concurrent view initialization into one vault-library load. */
    private ensureLoaded;
    /** Reads a coherent library snapshot without mutating the active cache. */
    private loadFromVault;
    private persistChanges;
    private withFileStatus;
    private mergeById;
    private createFileData;
    private getFolderPath;
    private getLocalLibraryPath;
    private ensureFolder;
    private readLibraryFile;
    /** Writes a non-empty library or removes its file when no items remain. */
    private persistLibraryFile;
}
