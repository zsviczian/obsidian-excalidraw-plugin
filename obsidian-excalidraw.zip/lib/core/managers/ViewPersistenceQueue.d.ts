import type { TFile } from "obsidian";
import type { PreparedAutoexportRequest } from "./AutoexportCoordinator";
export type ViewPersistenceReason = "view-unload" | "window-migration";
/** Immutable drawing text accepted from a view that may immediately retire. */
export interface ViewPersistenceRequest {
    readonly producerId: string;
    readonly targetGeneration: number;
    readonly operationId: number;
    readonly requestedRevision: number;
    readonly capturedRevision: number;
    readonly filePath: string;
    readonly expectedFileCtime: number;
    readonly text: string;
    readonly hasNonDeletedElements: boolean;
    readonly reason: ViewPersistenceReason;
    /** Required by window migration so autoexport waits for its replacement. */
    readonly migrationLeafId?: string;
    readonly autoexportRequest?: PreparedAutoexportRequest;
}
export type ViewPersistenceResult = {
    readonly status: "persisted";
    readonly request: ViewPersistenceRequest;
} | {
    readonly status: "invalid-request" | "target-missing" | "target-changed" | "handoff-expired" | "failed";
    readonly request: ViewPersistenceRequest;
    readonly error: unknown;
};
interface ViewPersistenceQueueOptions {
    readonly resolveFile: (filePath: string) => TFile | null;
    readonly write: (file: TFile, text: string) => Promise<void>;
    readonly scheduleBackup: (filePath: string, text: string) => void;
    readonly now: () => number;
    readonly scheduleCleanup: (callback: () => void, delayMs: number) => number;
    readonly cancelCleanup: (timer: number) => void;
    readonly handoffTtlMs?: number;
    readonly onFailure?: (result: Exclude<ViewPersistenceResult, {
        status: "persisted";
    }>) => void;
    readonly onBackupScheduleFailure?: (error: unknown, request: ViewPersistenceRequest) => void;
    readonly onPersisted?: (request: ViewPersistenceRequest) => void;
    readonly onPersistedCallbackFailure?: (error: unknown, request: ViewPersistenceRequest) => void;
    readonly beginPersistenceActivity?: (request: ViewPersistenceRequest) => () => void;
}
/**
 * A data-only reservation for one drawing path. The owner must release it in
 * `finally`; the queue never retains the live view performing the write.
 */
export interface ViewPersistenceWriteLease {
    release(): void;
}
export interface ViewMigrationPersistenceHandoff {
    readonly leafId: string;
    readonly request: ViewPersistenceRequest;
}
export interface ViewMigrationPersistenceConsumption {
    readonly request: ViewPersistenceRequest;
    readonly completion: Promise<ViewPersistenceResult>;
}
/**
 * Persists immutable drawing text after its originating view may be destroyed.
 *
 * Requests for one path execute in accepted order and are never coalesced:
 * independent view revisions do not establish that a later arrival supersedes
 * an earlier snapshot. Queue entries contain no view, DOM, Window, React root,
 * package lease, or callback closing over those objects. Successful writes
 * schedule their exact text for BAK before releasing the path reservation.
 *
 * There is intentionally no destructive `destroy()`: plugin unload starts
 * asynchronous view conversions before their unload handoffs arrive. Each
 * path chain releases itself after its final accepted write settles, and the
 * plugin-main-window cleanup timer releases abandoned migration reservations.
 */
export declare class ViewPersistenceQueue {
    private readonly options;
    private readonly pathTails;
    private readonly migrationHandoffs;
    private cleanupTimer;
    constructor(options: ViewPersistenceQueueOptions);
    /** Accepts responsibility immediately and resolves after the physical write. */
    enqueue(request: ViewPersistenceRequest): Promise<ViewPersistenceResult>;
    /**
     * Reserves the same per-path write boundary for a live `TextFileView` save.
     * Only the gate is retained here; the caller keeps and invokes its own live
     * write after acquisition.
     */
    acquireWriteLease(filePath: string): Promise<ViewPersistenceWriteLease>;
    /**
     * Reserves persistence order for immutable text supplied by a source popout.
     * No Vault write starts until the replacement view consumes the handoff.
     */
    registerMigrationHandoff(handoff: ViewMigrationPersistenceHandoff): void;
    /**
     * Transfers execution ownership to the replacement main-window view. The
     * returned completion represents the physical Vault write.
     */
    consumeMigrationHandoff(leafId: string, filePath: string): ViewMigrationPersistenceConsumption | null;
    /** Releases ordering after a failed source-view replacement. */
    discardMigrationHandoff(leafId: string): void;
    private reservePath;
    private executeReservation;
    private rejectMigrationTarget;
    private pruneExpiredHandoffs;
    private scheduleHandoffCleanup;
    private execute;
    private fail;
}
export {};
