import { WorkspaceLeaf } from "obsidian";
import type ExcalidrawPlugin from "src/core/main";
import { ExcalidrawAutomate } from "src/shared/ExcalidrawAutomate";
import ExcalidrawView from "src/view/ExcalidrawView";
/**
 * Registers event listeners for the plugin
 * Must be constructed after the workspace is ready (onLayoutReady)
 * Intended to be called from onLayoutReady in onload()
 */
export declare class EventManager {
    private plugin;
    private app;
    leafChangeTimeout: number | null;
    private removeEventLisnters;
    private previouslyActiveLeaf;
    private splitViewLeafSwitchTimestamp;
    private debunceActiveLeafChangeHandlerTimer;
    get settings(): import("../settingsDefaults").ExcalidrawSettings;
    get ea(): ExcalidrawAutomate;
    get activeExcalidrawView(): ExcalidrawView;
    set activeExcalidrawView(view: ExcalidrawView);
    private registerEvent;
    constructor(plugin: ExcalidrawPlugin);
    destroy(): void;
    initialize(): Promise<void>;
    isRecentSplitViewSwitch(): boolean;
    registerEvents(): Promise<void>;
    setDebounceActiveLeafChangeHandler(): void;
    private onLayoutChangeHandler;
    private onPasteHandler;
    private onRenameHandler;
    private onModifyHandler;
    private onDeleteHandler;
    onActiveLeafChangeHandler(leaf: WorkspaceLeaf): Promise<void>;
    private onClickSaveActiveDrawing;
    private onFileMenuSaveActiveDrawing;
    private onFileMenuHandler;
    private onEditorMenuHandler;
}
