/** Classification helpers for safely loading plugin settings data. */
/** Observable state of the plugin's `data.json` file before loading it. */
export type SettingsDataFileState = "missing" | "empty" | "present" | "unknown";
/** Result of validating one settings load attempt. */
export type SettingsDataLoadClassification = "valid" | "first-installation" | "invalid";
/** Returns true for the object shape accepted as persisted settings data. */
export declare const isSettingsDataRecord: (value: unknown) => value is Record<string, unknown>;
/**
 * Distinguishes a genuine first installation from an empty, malformed, or
 * failed settings load that must not replace already loaded settings.
 */
export declare function classifySettingsDataLoad(options: {
    value: unknown;
    fileState: SettingsDataFileState;
    loadFailed: boolean;
    isInitialLoad: boolean;
}): SettingsDataLoadClassification;
