/**
 * Device-local, transactional storage for the last known good settings.
 *
 * The recovery copy deliberately lives outside the vault and Obsidian's
 * localStorage. IndexedDB can hold large legacy settings records and replaces
 * the single recovery record atomically if a write completes.
 */
interface SettingsRecoveryStoreOptions {
    databaseName: string;
    indexedDBFactory?: IDBFactory | null;
}
/**
 * Stores one durable last-known-good settings snapshot for the current vault.
 */
export declare class SettingsRecoveryStore<Snapshot extends Record<string, unknown>> {
    private readonly options;
    private database;
    private databasePromise;
    private readonly indexedDBFactory;
    private destroyed;
    constructor(options: SettingsRecoveryStoreOptions);
    /** Returns the last complete settings snapshot, if one is available. */
    load(): Promise<Snapshot | null>;
    /** Atomically replaces the last-known-good settings snapshot. */
    save(settings: Snapshot): Promise<void>;
    /** Closes the database connection owned by this plugin instance. */
    destroy(): void;
    private getDatabase;
    private openDatabase;
}
export {};
