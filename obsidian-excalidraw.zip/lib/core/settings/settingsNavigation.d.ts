import type { App } from "obsidian";
/** Returns whether the current Obsidian runtime exposes page navigation. */
export declare function canNavigateSettingsPages(app: App): boolean;
/**
 * Navigates to a declarative settings page through Obsidian's unpublished
 * settings API.
 *
 * The method is deliberately isolated behind structural and exception guards
 * because it is not part of Obsidian's public compatibility contract.
 *
 * @returns `true` when Obsidian accepted the navigation request, otherwise
 * `false` so callers can leave the current page intact.
 */
export declare function navigateToSettingsPage(app: App, tabId: string, pagePath: readonly string[]): boolean;
