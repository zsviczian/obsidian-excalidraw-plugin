/**
 * Markdown export for Obsidian's declarative settings tree.
 *
 * The exporter reads the declarations rather than the currently mounted page,
 * so nested and conditionally rendered settings remain discoverable in one
 * document.
 */
import type { SettingDefinitionItem } from "src/types/obsidianDeclarativeSettings";
interface MarkdownDefinitionMetadata {
    controlType?: string;
    omit?: boolean;
}
/** Adds export-only metadata without exposing custom fields to Obsidian. */
export declare function annotateMarkdownDefinition<T extends object>(definition: T, metadata: MarkdownDefinitionMetadata): T;
/** Converts a complete declarative settings tree into one Markdown document. */
export declare function declarativeSettingsToMarkdown(definitions: readonly SettingDefinitionItem[]): string;
export {};
