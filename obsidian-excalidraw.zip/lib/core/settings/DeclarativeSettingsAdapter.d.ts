/**
 * Obsidian 1.13 declarative adapter for canonical setting specifications.
 */
import type { SettingBindingRegistry } from "src/core/settings/SettingBindingRegistry";
import type { LegacySettingsAdapter } from "src/core/settings/LegacySettingsAdapter";
import type { SettingBindingKey, SettingSpec } from "src/core/settings/settingSpecs";
import type { SettingDefinition } from "src/types/obsidianDeclarativeSettings";
/** Converts canonical setting rows into Obsidian 1.13 definitions. */
export declare class DeclarativeSettingsAdapter {
    private readonly bindings;
    private readonly legacyAdapter;
    private registerBindings;
    constructor(bindings: SettingBindingRegistry, legacyAdapter: LegacySettingsAdapter);
    /** Starts a definition build, optionally replacing the live control bindings. */
    beginBuild(registerBindings?: boolean): void;
    /** Converts one canonical row during the current definition build. */
    toDefinition(spec: SettingSpec): SettingDefinition<SettingBindingKey>;
    private requiresCustomRender;
    private toRenderedDefinition;
    private toSearchText;
}
