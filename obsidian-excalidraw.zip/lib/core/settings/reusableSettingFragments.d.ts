import type { SettingDefinitionItem } from "src/types/obsidianDeclarativeSettings";
/** A setting row may render more than once from the same definition tree. */
export declare function cloneSettingFragment(value: string | DocumentFragment): string | DocumentFragment;
export declare function cloneSettingFragment(value: string | DocumentFragment | undefined): string | DocumentFragment | undefined;
/** Give Obsidian a fresh fragment each time it reads a rich description. */
export declare function makeDescriptionsReusable<K extends string>(items: SettingDefinitionItem<K>[]): SettingDefinitionItem<K>[];
