/**
 * Serialized stable-snapshot writer for plugin settings.
 */
/** Persistence operation required by the serialized settings writer. */
export interface SerializedSettingsWriterHost<Snapshot> {
    saveData(data: Snapshot): Promise<void>;
}
/**
 * Serializes complete settings writes so an older save cannot finish after a
 * newer one. Each request captures an immutable JSON snapshot before waiting
 * for an earlier write.
 */
export declare class SerializedSettingsWriter<Snapshot extends Record<string, unknown>> {
    private readonly host;
    private persistenceChain;
    constructor(host: SerializedSettingsWriterHost<Snapshot>);
    /** Queues one stable snapshot and resolves when that snapshot is saved. */
    persist(settings: Snapshot): Promise<void>;
}
