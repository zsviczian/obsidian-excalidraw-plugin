/**
 * Coalesces settings mutations so rapid controls do not enqueue one complete
 * `data.json` write per input event.
 */
/** Persistence operations owned by the settings tab. */
export interface SettingsPersistenceQueueHost {
    /** Persists the latest in-memory settings snapshot. */
    persistSettings(): Promise<void>;
    /** Applies side effects that must observe a successfully persisted snapshot. */
    applyPendingActions(): Promise<void>;
    /** Returns true while persistence would replace a control being edited. */
    shouldDeferPersistence?(): boolean;
}
/**
 * Trailing-edge persistence queue for settings mutations.
 *
 * Rapid mutations are collapsed into one write. If another mutation arrives
 * while that write is in flight, one follow-up write persists the newest
 * snapshot before pending actions and callers are released.
 */
export declare class SettingsPersistenceQueue {
    private readonly host;
    private readonly debounceMilliseconds;
    private requestedRevision;
    private completedRevision;
    private debounceTimer;
    private activeRun;
    private waiters;
    constructor(host: SettingsPersistenceQueueHost, debounceMilliseconds?: number);
    /**
     * Records a mutation and resolves after a persisted snapshot containing it
     * has had its pending actions applied.
     */
    enqueue(): Promise<void>;
    /** Immediately starts any scheduled persistence and awaits completion. */
    flush(): Promise<void>;
    private schedule;
    private cancelTimer;
    private startRun;
    private persistLatestRevision;
    private resolveWaitersThrough;
    private rejectWaiters;
}
