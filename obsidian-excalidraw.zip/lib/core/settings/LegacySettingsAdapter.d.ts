/**
 * Imperative renderer for canonical setting-row specifications.
 */
import { Setting, type TextComponent } from "obsidian";
import type { SettingBindingRegistry } from "src/core/settings/SettingBindingRegistry";
import type { SettingSpec, TextControl } from "src/core/settings/settingSpecs";
/** Legacy-only services used by custom text controls. */
export interface LegacySettingsAdapterHost {
    addVaultPathSupport(setting: Setting, text: TextComponent, kind: "file" | "folder" | "file-or-folder", options: NonNullable<TextControl["vaultPath"]>["options"]): void;
}
/** Builds or configures imperative Obsidian setting rows from canonical specs. */
export declare class LegacySettingsAdapter {
    private readonly bindings;
    private readonly host;
    constructor(bindings: SettingBindingRegistry, host: LegacySettingsAdapterHost);
    /**
     * Creates one legacy row. Slider return behavior remains `undefined` for
     * compatibility with the former in-class interpreter.
     */
    render(container: HTMLElement, spec: SettingSpec): Setting | undefined;
    /** Configures a row supplied by either the legacy or declarative host. */
    configure(setting: Setting, spec: SettingSpec): void;
}
