/**
 * Typed value and persistence bridge for canonical setting specifications.
 */
import type { ExcalidrawSettings } from "src/core/settingsDefaults";
import type { SettingSpec } from "src/core/settings/settingSpecs";
/** Services required to persist a canonical setting mutation. */
export interface SettingBindingHost {
    getSettings(): ExcalidrawSettings;
    queueSettingsUpdate(requestReloadDrawings: boolean): Promise<void>;
}
/**
 * Resolves declarative control keys and applies the same transformations,
 * hooks, save queue, and pending actions as the legacy controls.
 */
export declare class SettingBindingRegistry {
    private readonly bindings;
    private readonly host;
    constructor(host: SettingBindingHost);
    /** Clears bindings before a fresh declarative definition build. */
    clear(): void;
    /** Registers one native declarative control binding for the current build. */
    register(spec: SettingSpec): void;
    /** Reads a registered declarative control value. */
    getControlValue(key: string): unknown;
    /** Writes a registered declarative control value and awaits persistence. */
    setControlValue(key: string, value: unknown): Promise<void>;
    /** Reads the UI-facing value for either adapter. */
    getSpecValue(spec: SettingSpec): boolean | string | number;
    /** Applies a UI-facing value from either adapter. */
    setSpecValue(spec: SettingSpec, value: unknown, afterWrite?: () => void): Promise<void>;
    /**
     * Applies a legacy UI value without extending the component callback until
     * queued disk persistence completes.
     */
    setLegacySpecValue(spec: SettingSpec, value: unknown, afterWrite?: () => void): Promise<void>;
    private setSpecValueInternal;
    private getBinding;
    private setSettingValue;
    private persistAndRunAfterUpdate;
    private requireBoolean;
    private requireString;
    private requireNumber;
    private invalidValueError;
}
