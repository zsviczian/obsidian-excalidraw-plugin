import ExcalidrawPlugin from "src/core/main";
export declare const EDITOR_FADEOUT = "fadeOutExcalidrawMarkup";
export declare class EditorHandler {
    private plugin;
    private activeEditorExtensions;
    constructor(plugin: ExcalidrawPlugin);
    destroy(): void;
    setup(): void;
    updateCMExtensionState(extensionIdentifier: string, extensionState: boolean): void;
    update(): void;
}
