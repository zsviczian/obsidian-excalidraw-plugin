import { DecorationSet, EditorView, ViewPlugin, ViewUpdate } from "@codemirror/view";
export declare const HideTextBetweenCommentsExtension: ViewPlugin<{
    view: EditorView;
    decorations: DecorationSet;
    reExcalidrawData: RegExp;
    reTextElements: RegExp;
    reDrawing: RegExp;
    linecount: number;
    isExcalidraw: boolean;
    updateDecorations(view: EditorView): DecorationSet;
    update(update: ViewUpdate): void;
}, undefined>;
