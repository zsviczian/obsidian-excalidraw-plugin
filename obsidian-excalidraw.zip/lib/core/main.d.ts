import { ExcalidrawExtrasGateway } from "../utils/ExcalidrawExtrasGateway";
import { TFile, Plugin, WorkspaceLeaf, App, PluginManifest, ViewStateResult, TAbstractFile, FrontMatterCache } from "obsidian";
import type { ExcalidrawSettings } from "./settingsDefaults";
import { ExcalidrawAutomate } from "../shared/ExcalidrawAutomate";
import { FileId } from "@zsviczian/excalidraw/types/element/src/types";
import { ScriptEngine } from "../shared/Scripts";
import { DeviceType, PackageLease, Packages } from "../types/types";
import { PaneTarget } from "../types/utilTypes";
import { ExcalidrawConfig } from "../shared/ExcalidrawConfig";
import { EditorHandler } from "./editor/EditorHandler";
import { WeakArray } from "../shared/WeakArray";
import ExcalidrawView from "../view/ExcalidrawView";
import { ExcalidrawSidepanelView } from "../view/sidepanel/Sidepanel";
import en from "src/lang/locale/en";
import { KeyBlocker } from "src/types/excalidrawAutomateTypes";
import { UIMode } from "src/shared/Dialogs/UIModeSettingComponent";
import type { MarkdownImageData } from "src/types/markdownImageTypes";
import { StencilLibraryManager } from "./managers/StencilLibraryManager";
import type { StencilLibraryData } from "src/types/stencilLibraryTypes";
import { type ViewMigrationDrawingState, type ViewMigrationHandoffRegistration, type ViewMigrationHandoffRequest } from "./managers/ViewMigrationHandoffManager";
import { type ViewMigrationPersistenceConsumption, type ViewMigrationPersistenceHandoff, type ViewPersistenceRequest, type ViewPersistenceWriteLease } from "./managers/ViewPersistenceQueue";
import { type PreparedAutoexportRequest } from "./managers/AutoexportCoordinator";
type FileMasterInfo = {
    isHyperLink: boolean;
    isLocalLink: boolean;
    path: string;
    hasSVGwithBitmap: boolean;
    blockrefData: string;
    colorMapJSON?: string;
};
export default class ExcalidrawPlugin extends Plugin {
    extrasGateway: ExcalidrawExtrasGateway;
    private fileManager;
    private observerManager;
    private packageManager;
    private monkeyPatchManager;
    private commandManager;
    private eventManager;
    private settingsManager;
    private settingsTab;
    private footerSafeAreaManager;
    private fontManager;
    private startupTimer;
    private viewMigrationHandoffManager;
    private viewPersistenceQueue;
    private autoexportCoordinator;
    stencilLibraryManager: StencilLibraryManager;
    eaInstances: WeakArray<ExcalidrawAutomate>;
    fourthFontLoaded: boolean;
    excalidrawConfig: ExcalidrawConfig;
    excalidrawFileModes: {
        [file: string]: string;
    };
    settings: ExcalidrawSettings;
    /** Session-scoped autosave gate controlled by the temporary commands. */
    autosaveEnabled: boolean;
    activeExcalidrawView: ExcalidrawView;
    lastActiveExcalidrawFilePath: string;
    lastActiveExcalidrawLeafID: string;
    hover: {
        linkText: string;
        sourcePath: string;
    };
    private legacyExcalidrawPopoverObserver;
    opencount: number;
    ea: ExcalidrawAutomate;
    filesMaster: Map<FileId, FileMasterInfo>;
    equationsMaster: Map<FileId, string>;
    markdownImagesMaster: Map<FileId, MarkdownImageData>;
    mermaidsMaster: Map<FileId, string>;
    scriptEngine: ScriptEngine;
    private stylesManager;
    editorHandler: EditorHandler;
    forceToOpenInMarkdownFilepath: string;
    loadTimestamp: number;
    isReady: boolean;
    private settingsReady;
    wasPenModeActivePreviously: boolean;
    popScope: (() => void) | null;
    lastPDFLeafID: string;
    forceExcalidrawViewMode: boolean;
    constructor(app: App, manifest: PluginManifest);
    /** Records a startup timing event without changing lifecycle ordering. */
    logStartupEvent(message: string): void;
    /** Prints the startup breakdown; spelling retained for compatibility. */
    printStarupBreakdown(): void;
    get locale(): string;
    get window(): Window;
    /**
     * used by Excalidraw to getSharedMermaidInstance
     * @returns shared mermaid instance
     */
    getMermaid(): Promise<{
        loaded: boolean;
        api: Promise<typeof import("@excalidraw/mermaid-to-excalidraw")>;
    }>;
    isPenMode(): boolean;
    /** Returns the configured CJK ranges when local font assets are available. */
    getCJKFontSettings(): {
        c: boolean;
        j: boolean;
        k: boolean;
    };
    /** Reads a configured CJK font file from the vault. */
    loadFontFromFile(fontName: string): Promise<ArrayBuffer | undefined>;
    onload(): Promise<void>;
    private onloadCheckForOnceOffSettingsUpdates;
    private onloadOnLayoutReady;
    awaitSettings(): Promise<void>;
    awaitInit(): Promise<void>;
    /**
     * Loads the Excalidraw frontmatter tags to Obsidian property suggester so people can more easily find relevant front matter switches
     * Must run after the workspace is ready
     * @returns
     */
    private setPropertyTypes;
    /** Initializes configured CJK and custom fonts across open documents. */
    initializeFonts(): Promise<void>;
    /** Removes plugin-owned runtime fonts from all open documents. */
    removeFonts(): void;
    /** Updates the optional mobile footer padding across open documents. */
    updateFooterSafeAreaPadding(): void;
    /**
     * Must be called after the workspace is ready
     */
    private switchToExcalidrawAfterLoad;
    forceSaveActiveView(checking: boolean): boolean;
    /**
     * Displays a transcluded .excalidraw image in markdown preview mode
     */
    private addMarkdownPostProcessor;
    enableLegacyFilePopoverObserver(): void;
    private actionRibbonClick;
    convertSingleExcalidrawToMD(file: TFile, replaceExtension?: boolean, keepOriginal?: boolean): Promise<TFile>;
    convertExcalidrawToMD(replaceExtension?: boolean, keepOriginal?: boolean): Promise<void>;
    /**
     * Loads the startup script that will add event hooks to ExcalidrawAutomate (if provided by the user)
     * Because of file operations, this must be run after the Obsidian Layout is ready
     * @returns
     */
    private runStartupScript;
    getLastActivePDFPageLink(requestorFile: TFile): string;
    activeLeafChangeEventHandler(leaf: WorkspaceLeaf): Promise<void>;
    setDebounceActiveLeafChangeHandler(): void;
    registerHotkeyOverrides(): void;
    onunload(): void;
    /**
     * Loads settings through the plugin-owned settings manager.
     */
    loadSettings(): Promise<void>;
    /** Persists the current settings through the plugin-owned settings manager. */
    saveSettings(): Promise<void>;
    /** Refreshes the mounted settings tab after script-defined settings change. */
    refreshSettingsTab(): void;
    /** Reloads externally changed settings and invalidates cached libraries. */
    onExternalSettingsChange(): Promise<void>;
    openSidepanel(reveal?: boolean): Promise<ExcalidrawSidepanelView | null>;
    getLegacyStencilLibrary(): StencilLibraryData;
    setLegacyStencilLibrary(library: StencilLibraryData, save?: boolean): Promise<void>;
    getStencilLibrary(): StencilLibraryData | Promise<StencilLibraryData>;
    setStencilLibrary(library: StencilLibraryData): Promise<void>;
    triggerEmbedUpdates(filepath?: string): void;
    getBlankDrawing(): Promise<string>;
    createDrawing(filename: string, foldername?: string, initData?: string): Promise<TFile>;
    createAndOpenDrawing(filename: string, location: PaneTarget, foldername?: string, initData?: string): Promise<string>;
    setMarkdownView(leaf: WorkspaceLeaf, eState?: ViewStateResult): Promise<void>;
    isExcalidrawFile(f: TFile): boolean;
    openDrawing(drawingFile: TFile, location: PaneTarget, active?: boolean, subpath?: string, justCreated?: boolean, popoutLocation?: {
        x?: number;
        y?: number;
        width?: number;
        height?: number;
    }): void;
    embedDrawing(file: TFile): Promise<void>;
    exportLibrary(): Promise<void>;
    renameEventHandler(file: TAbstractFile, oldPath: string): Promise<void>;
    modifyEventHandler(file: TAbstractFile): Promise<void>;
    deleteEventHandler(file: TAbstractFile): Promise<void>;
    addThemeObserver(): void;
    removeThemeObserver(): void;
    addModalContainerObserver(view?: ExcalidrawView): void;
    removeModalContainerObserver(): void;
    experimentalFileTypeDisplayToggle(enabled: boolean): void;
    getPackage(win: Window): Packages;
    /** Acquires explicit ownership of the runtime package for one view window. */
    acquirePackage(win: Window): PackageLease;
    deletePackage(win: Window): void;
    /** Registers drawing-owned runtime state for one recreated view. */
    registerViewMigrationHandoff(registration: ViewMigrationHandoffRegistration): string;
    /** Consumes validated drawing-owned runtime state for one recreated view. */
    consumeViewMigrationHandoff(request: ViewMigrationHandoffRequest): ViewMigrationDrawingState | null;
    /** Registers serialized drawing text for a popout-to-main migration. */
    registerViewMigrationPersistenceHandoff(handoff: ViewMigrationPersistenceHandoff): void;
    /** Consumes serialized drawing text for the replacement main-window view. */
    consumeViewMigrationPersistenceHandoff(leafId: string, filePath: string): ViewMigrationPersistenceConsumption | null;
    /** Discards a handoff when the old view could not be replaced. */
    discardViewMigrationPersistenceHandoff(leafId: string): void;
    /** Transfers immutable drawing text out of a retiring view runtime. */
    handoffViewPersistence(request: ViewPersistenceRequest): void;
    /** Submits an immutable autoexport after a successful live source write. */
    enqueuePreparedAutoexport(request: PreparedAutoexportRequest): void;
    /** Marks one view save queue active for automatic-export coalescing. */
    beginAutoexportSaveActivity(sourceFilePath: string, sourceFileCtime: number): () => void;
    /** Holds heavy migration autoexport work until the replacement view loads. */
    deferPreparedAutoexportUntilMigrationComplete(leafId: string, request: PreparedAutoexportRequest): void;
    /** Releases or discards a migration export after replacement load settles. */
    completeMigrationAutoexport(leafId: string, filePath: string, loadSucceeded: boolean): void;
    /** Reserves the plugin-owned per-path boundary for a live view write. */
    acquireViewPersistenceWriteLease(filePath: string): Promise<ViewPersistenceWriteLease>;
    get taskbone(): import("../shared/OCR/Taskbone").default;
    get insertImageDialog(): import("../shared/Dialogs/InsertImageDialog").InsertImageDialog;
    get insertMDDialog(): import("../shared/Dialogs/InsertMDDialog").InsertMDDialog;
    get insertLinkDialog(): import("../shared/Dialogs/InsertLinkDialog").InsertLinkDialog;
    get importSVGDialog(): import("../shared/Dialogs/ImportSVGDialog").ImportSVGDialog;
    isRecentSplitViewSwitch(): boolean;
    get leafChangeTimeout(): number;
    clearLeafChangeTimeout(): void;
    updateFileCache(file: TFile, frontmatter: FrontMatterCache): void;
    runAction(action: "anyFile" | "LaTeX" | "card"): void;
    getLabel(key: keyof typeof en): string;
    getObsidianDevice(): DeviceType;
    getHighlightColor(sceneBgColor: string, opacity?: number): string;
    /**
     * Attaches an inline link suggester to the specified input element.
     * @param inputEl The text input element to attach the suggester to.
     * @param widthWrapper Optional HTML element to wrap the width of suggester element.
     * @param containerEl Optional container element used as collision boundary.
     * @param suppressPlaceholder Whether to suppress the placeholder text. Defaults to true.
     * @returns A KeyBlocker instance for managing keyboard input.
     */
    attachInlineLinkSuggester(inputEl: HTMLInputElement | HTMLTextAreaElement, widthWrapper?: HTMLElement, containerEl?: HTMLDivElement, suppressPlaceholder?: boolean): KeyBlocker;
    getPreferredUIMode(): UIMode;
}
export {};
