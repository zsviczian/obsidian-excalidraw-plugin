/**
 * Plugin settings data model: the persisted-settings interface and its
 * default values, decoupled from `src/core/settings.ts`'s
 * `ExcalidrawSettingTab` UI class.
 *
 * Kept separate so that files needing only the settings shape/defaults
 * (e.g. `PluginSettingsManager`) don't statically pull in the settings-tab
 * UI class and its ~50 dialog/component imports. This is also the natural
 * home for a future declarative `getSettingDefinitions()` array, since that
 * array binds directly against these same keys and defaults.
 */
import { Modifier } from "obsidian";
import { PenStyle } from "src/types/penTypes";
import { DynamicStyle, GridSettings } from "src/types/types";
import { PreviewImageType } from "src/types/utilTypes";
import { EmbeddableMDCustomProps } from "src/shared/Dialogs/EmbeddableSettings";
import type { MarkdownImageDeletionPreference, MarkdownImageSettings } from "src/types/markdownImageTypes";
import { ModifierKeySet, ModifierSetType } from "src/utils/modifierkeyHelper";
import { Rank } from "src/constants/actionIcons";
import { PDFExportSettings } from "src/shared/Dialogs/PDFExportSettingsComponent";
import { UIMode } from "src/shared/Dialogs/UIModeSettingComponent";
import { ScriptSettingValue } from "src/types/excalidrawAutomateTypes";
import { AIImageModelConfig, AIModelConfig, AIProviderProfile } from "src/types/AIUtilTypes";
import type { StencilLibraryData, StencilLibraryMigrationStatus, StencilLibraryStorageMode } from "src/types/stencilLibraryTypes";
export interface ExcalidrawSettings {
    showTabTitlebarButtons: boolean;
    copyLinkToElemenetAnchorTo100: boolean;
    copyFrameLinkByName: boolean;
    disableDoubleClickTextEditing: boolean;
    phoneFooterSafeAreaPadding: boolean;
    tabletFooterSafeAreaPadding: boolean;
    folder: string;
    libraryFolderPath: string;
    libraryFileName: string;
    libraryStorageMode: StencilLibraryStorageMode;
    libraryMigrationStatus: StencilLibraryMigrationStatus;
    libraryMigrationSnoozeUntil: number;
    cropFolder: string;
    annotateFolder: string;
    embedUseExcalidrawFolder: boolean;
    templateFilePath: string;
    scriptFolderPath: string;
    allowJavaScriptFiles: boolean;
    storeScriptFilesAsJavaScript: boolean;
    fontAssetsPath: string;
    loadChineseFonts: boolean;
    loadJapaneseFonts: boolean;
    loadKoreanFonts: boolean;
    compress: boolean;
    decompressForMDView: boolean;
    onceOffCompressFlagReset: boolean;
    autosaveIntervalDesktop: number;
    autosaveIntervalMobile: number;
    drawingFilenamePrefix: string;
    drawingEmbedPrefixWithFilename: boolean;
    drawingFilnameEmbedPostfix: string;
    drawingFilenameDateTime: string;
    useExcalidrawExtension: boolean;
    cropSuffix: string;
    cropPrefix: string;
    annotateSuffix: string;
    annotatePrefix: string;
    annotatePreserveSize: boolean;
    displaySVGInPreview: boolean;
    previewImageType: PreviewImageType;
    renderingConcurrency: number;
    imageCacheRetentionDays: number;
    allowImageCache: boolean;
    allowImageCacheInScene: boolean;
    displayExportedImageIfAvailable: boolean;
    previewMatchObsidianTheme: boolean;
    width: string;
    height: string;
    overrideObsidianFontSize: boolean;
    dynamicStyling: DynamicStyle;
    isLeftHanded: boolean;
    desktopUIMode: UIMode;
    tabletUIMode: UIMode;
    phoneUIMode: UIMode;
    iframeMatchExcalidrawTheme: boolean;
    matchTheme: boolean;
    matchThemeAlways: boolean;
    matchThemeTrigger: boolean;
    defaultMode: string;
    defaultPenMode: "never" | "mobile" | "always";
    penModeDoubleTapEraser: boolean;
    penModeSingleFingerPanning: boolean;
    penModeCrosshairVisible: boolean;
    renderImageInMarkdownReadingMode: boolean;
    renderImageInHoverPreviewForMDNotes: boolean;
    renderImageInMarkdownToPDF: boolean;
    allowPinchZoom: boolean;
    allowWheelZoom: boolean;
    zoomToFitOnOpen: boolean;
    zoomToFitOnResize: boolean;
    zoomToFitMaxLevel: number;
    zoomStep: number;
    zoomMin: number;
    zoomMax: number;
    openInAdjacentPane: boolean;
    showSecondOrderLinks: boolean;
    focusOnFileTab: boolean;
    openInMainWorkspace: boolean;
    showLinkBrackets: boolean;
    syncElementLinkWithText: boolean;
    linkPrefix: string;
    urlPrefix: string;
    parseTODO: boolean;
    todo: string;
    done: string;
    hoverPreviewWithoutCTRL: boolean;
    linkOpacity: number;
    allowCtrlClick: boolean;
    forceWrap: boolean;
    pageTransclusionCharLimit: number;
    wordWrappingDefault: number;
    removeTransclusionQuoteSigns: boolean;
    oEmbedAllowed: boolean;
    pngExportScale: number;
    exportWithTheme: boolean;
    exportWithBackground: boolean;
    exportPaddingSVG: number;
    exportEmbedScene: boolean;
    keepInSync: boolean;
    autoexportSVG: boolean;
    autoexportPNG: boolean;
    autoExportLightAndDark: boolean;
    autoexportExcalidraw: boolean;
    embedType: "excalidraw" | "PNG" | "SVG";
    embedMarkdownCommentLinks: boolean;
    embedWikiLink: boolean;
    /**
     * If true, embed a placeholder image when no drawing is present. If false, do not embed any image.
     */
    embedPlaceholderImage: boolean;
    syncExcalidraw: boolean;
    compatibilityMode: boolean;
    experimentalFileType: boolean;
    experimentalFileTag: string;
    experimentalLivePreview: boolean;
    fadeOutExcalidrawMarkup: boolean;
    loadPropertySuggestions: boolean;
    experimentalEnableFourthFont: boolean;
    experimantalFourthFont: string;
    addDummyTextElement: boolean;
    zoteroCompatibility: boolean;
    fieldSuggester: boolean;
    enableOnloadScripts: boolean;
    enableCommandLinks: boolean;
    drawingOpenCount: number;
    library: string;
    library2: StencilLibraryData;
    imageElementNotice: boolean;
    mdSVGwidth: number;
    mdSVGmaxHeight: number;
    mdFont: string;
    mdFontColor: string;
    mdBorderColor: string;
    mdCSS: string;
    markdownImageSettings: MarkdownImageSettings;
    markdownImageDeletionPreference: MarkdownImageDeletionPreference;
    scriptEngineSettings: {
        [key: string]: {
            [key: string]: ScriptSettingValue | string | number | boolean;
        };
    };
    autostartScripts: {
        [scriptName: string]: "allow" | "deny" | "unknown";
    };
    autostartScriptFailures: {
        [scriptName: string]: boolean;
    };
    previousRelease: string;
    showReleaseNotes: boolean;
    useDeclarativeSettings: boolean;
    excalidrawMasteryPromoCollapsed: boolean;
    compareManifestToPluginVersion: boolean;
    showNewVersionNotification: boolean;
    latexBoilerplate: string;
    latexPreambleLocation: string;
    taskboneEnabled: boolean;
    taskboneAPIkey: string;
    pinnedScripts: string[];
    sidepanelTabs: string[];
    customPens: PenStyle[];
    numberOfCustomPens: number;
    pdfScale: number;
    pdfBorderBox: boolean;
    pdfFrame: boolean;
    pdfGapSize: number;
    pdfGroupPages: boolean;
    pdfLockAfterImport: boolean;
    pdfNumColumns: number;
    pdfNumRows: number;
    pdfDirection: "down" | "right";
    pdfImportScale: number;
    gridSettings: GridSettings;
    laserSettings: {
        DECAY_TIME: number;
        DECAY_LENGTH: number;
        COLOR: string;
    };
    embeddableMarkdownDefaults: EmbeddableMDCustomProps;
    markdownNodeOneClickEditing: boolean;
    canvasImmersiveEmbed: boolean;
    startupScriptPath: string;
    aiEnabled: boolean;
    aiVerboseLogging: boolean;
    aiProviderProfiles: Record<string, AIProviderProfile>;
    aiTextModelConfigs: Record<string, AIModelConfig>;
    aiImageModelConfigs: Record<string, AIImageModelConfig>;
    aiDefaultTextModel: string;
    aiDefaultMultimodalModel: string;
    aiDefaultImageGenerationModel: string;
    aiDefaultMaxOutgoingTokens: number;
    aiDefaultMaxResponseTokens: number;
    modifierKeyConfig: {
        Mac: Record<ModifierSetType, ModifierKeySet>;
        Win: Record<ModifierSetType, ModifierKeySet>;
    };
    slidingPanesSupport: boolean;
    areaZoomLimit: number;
    longPressDesktop: number;
    longPressMobile: number;
    doubleClickLinkOpenViewMode: boolean;
    rank: Rank;
    modifierKeyOverrides: {
        modifiers: Modifier[];
        key: string;
    }[];
    showSplashscreen: boolean;
    pdfSettings: PDFExportSettings;
    disableContextMenu: boolean;
}
export declare const KNOWN_AI_PROVIDER_PROFILES: Record<string, AIProviderProfile>;
export declare const cloneKnownAIProviderProfiles: () => {
    [k: string]: {
        provider: import("src/types/AIUtilTypes").AIProvider;
        apiKey: string;
        baseURL: string;
    };
};
export declare const KNOWN_AI_TEXT_MODEL_CONFIGS: Record<string, AIModelConfig>;
export declare const KNOWN_AI_IMAGE_MODEL_CONFIGS: Record<string, AIImageModelConfig>;
export declare const cloneModelConfigs: <TConfig extends AIModelConfig>(configs: Record<string, TConfig>) => Record<string, TConfig>;
export declare const DEFAULT_SETTINGS: ExcalidrawSettings;
