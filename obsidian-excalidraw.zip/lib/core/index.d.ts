import "obsidian";
import type { ExcalidrawAutomate } from "src/shared/ExcalidrawAutomate";
import type ExcalidrawView from "src/view/ExcalidrawView";
export type { ExcalidrawAutomate, ViewLinkClickContext, ViewLinkClickHook, } from "src/shared/ExcalidrawAutomate";
export type { ExcalidrawEphemeralState } from "src/types/excalidrawViewTypes";
export type { ExcalidrawBindableElement, ExcalidrawElement, FileId, FillStyle, StrokeRoundness, StrokeStyle, } from "@zsviczian/excalidraw/types/element/src/types";
export type { Point } from "src/types/types";
export type { MathJaxRenderOptions } from "src/types/mathJaxTypes";
export declare const getEA: (view?: ExcalidrawView) => ExcalidrawAutomate | null;
