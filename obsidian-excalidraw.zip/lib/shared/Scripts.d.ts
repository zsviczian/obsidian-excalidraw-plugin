import { App, Instruction, TFile } from "obsidian";
import ExcalidrawView from "../view/ExcalidrawView";
import ExcalidrawPlugin from "../core/main";
import { ExcalidrawAutomate } from "../shared/ExcalidrawAutomate";
import { WeakArray } from "./WeakArray";
import { ButtonDefinition } from "src/types/promptTypes";
import { type ScriptFileExtension } from "src/utils/scriptFileUtils";
export type ScriptIconMap = {
    [key: string]: {
        name: string;
        group: string;
        svgString: string;
    };
};
/** Identifies why the script engine invoked a script. */
export type ScriptExecutionSource = "manual" | "plugin-startup" | "view-autostart" | "sidepanel-restore" | "sidepanel-reload" | "drawing-onload";
export interface ScriptFileRenamePlan {
    renames: Array<{
        file: TFile;
        sourcePath: string;
        destinationPath: string;
    }>;
    conflicts: string[];
    includesStartupScript: boolean;
}
export declare class ScriptEngine {
    private plugin;
    private app;
    private scriptPath;
    scriptIconMap: ScriptIconMap;
    eaInstances: WeakArray<ExcalidrawAutomate>;
    /**
     * Selected-element action-provider unregister callbacks registered via
     * `ExcalidrawAutomate.registerElementActionProvider()`, keyed by script
     * name. Cleared in `unloadScript()` so a deleted script's buttons don't
     * linger in views that are still open.
     */
    private elementActionProviders;
    private scriptFileEventsSuspended;
    private scriptRegistryGeneration;
    private loadedScriptPaths;
    /** Compiled code keyed by vault path. EA instances and script state are never cached. */
    private compiledScripts;
    /** Successful or in-flight automatic attachments, scoped to a view and script path. */
    private autostartAttachments;
    /** EAs whose top-level script invocation currently has a view-autostart trigger. */
    private viewAutostartEAs;
    constructor(plugin: ExcalidrawPlugin);
    removeViewEAs(view: ExcalidrawView): void;
    destroy(): void;
    private isInScriptFolder;
    private isJavaScriptPath;
    private isScriptPath;
    /**
     * Resolves the configured startup-script path without changing the stored
     * setting. Extensionless paths retain the historical `.md` default; an
     * explicit `.js` path is accepted only when JavaScript-file loading is
     * enabled.
     */
    resolveStartupScriptPath(configuredPath: string): string | null;
    /** Returns whether an EA is currently running because of view autostart. */
    isViewAutostartExecution(ea: ExcalidrawAutomate): boolean;
    private invalidateCompiledScript;
    private clearCompiledScripts;
    private clearAutostartAttachment;
    private compileScript;
    /**
     * Returns compiled code for the current file version. In-flight requests for
     * the same path share one promise, while event and stat checks prevent stale
     * code from surviving edits or renames.
     */
    private getCompiledScript;
    private modifyEventHandler;
    private deleteEventHandler;
    private createEventHandler;
    private renameEventHandler;
    registerEventHandlers(): void;
    /**
     * Runs a coordinated script-file mutation without letting the vault event
     * handlers trigger full registry reloads for each intermediate file change.
     * The caller is responsible for refreshing the affected registry entries.
     */
    withScriptFileEventsSuspended<T>(operation: () => Promise<T>): Promise<T>;
    updateScriptPath(): void;
    getListofScripts(): TFile[];
    loadScripts(generation?: number): Promise<void>;
    /** Reloads the script command and toolbar registry after discovery changes. */
    reloadScripts(): Promise<void>;
    /** Refreshes one script after an in-place write without reloading all scripts. */
    refreshManagedScriptFile(file: TFile): Promise<void>;
    /** Removes one deleted script from the live registry without a full reload. */
    removeManagedScriptFile(scriptPath: string, scriptName: string): Promise<void>;
    /**
     * Builds a non-destructive plan for moving scripts to the selected local
     * extension. A configured startup script outside the Scripts folder is
     * included. Same-named destination files are reported and skipped.
     */
    getScriptFileMigrationPlan(targetExtension: ScriptFileExtension): ScriptFileRenamePlan;
    /**
     * Applies a previously confirmed script-extension migration. File events
     * are suppressed during the batch, pinned paths and the startup path are
     * updated atomically with settings, and completed renames are rolled back
     * if a later rename or settings write fails.
     */
    migrateScriptFiles(plan: ScriptFileRenamePlan): Promise<number>;
    /**
     * Renames one managed script to the requested local extension while keeping
     * pinned-script and startup-script paths synchronized.
     */
    renameManagedScriptFile(file: TFile, destinationPath: string): Promise<void>;
    getScriptName(f: TFile | string): string;
    getScriptFileByName(scriptName: string): TFile | null;
    addScriptIconToMap(scriptPath: string, name: string, generation?: number): Promise<void>;
    loadScript(f: TFile, generation?: number): Promise<void>;
    unloadScripts(): void;
    /**
     * Registers a cleanup callback for a selected-element action provider a
     * script registered via `ExcalidrawAutomate.registerElementActionProvider()`,
     * so it can be unregistered if the script's file is deleted while a view
     * using it is still open. Not needed for the ordinary view-close case,
     * which `SelectedElementActionsMenu.destroy()` already handles.
     */
    trackElementActionProvider(scriptName: string, unregister: () => void): void;
    /**
     * Removes a script's entry from `settings.autostartScripts` and
     * `settings.autostartScriptFailures` when its file is deleted or renamed
     * away, so a stale allow/deny permission or failure flag does not linger
     * under a name that no longer resolves to any script file. A renamed
     * script starts fresh (prompts again) under its new name.
     */
    private purgeAutostartPermission;
    /**
     * Records whether a script's most recent autostart run failed, so it can
     * be surfaced as a warning in the autostart settings/modal UI. Only
     * writes to disk when the flag actually changes (not on every autostart
     * run) to avoid a `saveSettings()` call every time an allow-listed
     * script runs. Purely informational: never touches `autostartScripts`
     * itself, so a failing script is never auto-removed from the allow
     * list - the user does that manually.
     */
    private recordAutostartResult;
    /**
     * Ensures one automatic attachment per script path and view. A successful
     * attachment remains recorded for that view; a failed one is removed so a
     * later automatic request can retry. Manual execution bypasses this method.
     */
    private ensureViewAutostartAttachment;
    /**
     * Called by `ExcalidrawAutomate.registerAutostart()` right after a script
     * is freshly granted autostart permission, so the script attaches to
     * every other currently-open Excalidraw view immediately instead of only
     * the next time each view is opened. Reuses the same compiled-file path
     * `runAutostartScripts()` uses for newly-opened views; one script
     * failing does not affect the others.
     */
    attachAutostartScriptToOpenViews(scriptName: string, excludeView?: ExcalidrawView): void;
    /**
     * Runs every script the user has allow-listed for autostart (see
     * `ExcalidrawAutomate.registerAutostart()`) once against a newly-opened
     * view. Called from `ExcalidrawRoot.ts`'s mount effect, after the view's
     * `selectedElementActionsMenu` is ready. Fire-and-forget: does not block
     * initial render. Deliberately independent of the sidepanel autostart
     * feature (`Sidepanel.ts`, not touched) — different persisted field,
     * different trigger, different execution owner.
     */
    runAutostartScripts(view: ExcalidrawView): void;
    unloadScript(basename: string, path: string): void;
    /** Executes a script file through the transparent compiled-code cache. */
    executeScriptFile(view: ExcalidrawView, file: TFile, title: string, executionSource?: ScriptExecutionSource): Promise<unknown>;
    /**
     * Executes the configured startup file using the plugin-global EA while
     * sharing ScriptEngine's loading, compilation, utilities, and error path.
     */
    executeStartupScript(file: TFile, ea: ExcalidrawAutomate): Promise<unknown>;
    /**
     * Executes supplied source with a fresh EA. Raw source remains uncached
     * because drawing-onload callers pass code embedded inside another file.
     */
    executeScript(view: ExcalidrawView, script: string, title: string, file: TFile, executionSource?: ScriptExecutionSource): Promise<unknown>;
    private executeExecutable;
    private updateToolPannels;
    static inputPrompt(view: ExcalidrawView, plugin: ExcalidrawPlugin, app: App, header: string, placeholder?: string, value?: string, buttons?: ButtonDefinition[], lines?: number, displayEditorButtons?: boolean, customComponents?: (container: HTMLElement) => void, blockPointerInputOutsideModal?: boolean, controlsOnTop?: boolean, draggable?: boolean): Promise<string>;
    static suggester<T>(app: App, displayItems: string[], items: T[], hint?: string, instructions?: Instruction[]): Promise<T | undefined>;
}
