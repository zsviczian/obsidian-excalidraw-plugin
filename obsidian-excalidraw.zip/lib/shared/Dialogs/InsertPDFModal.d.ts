import { TFile } from "obsidian";
import ExcalidrawView from "../../view/ExcalidrawView";
import ExcalidrawPlugin from "../../core/main";
import { Modal } from "obsidian";
export declare class InsertPDFModal extends Modal {
    private plugin;
    private view;
    private borderBox;
    private frame;
    private gapSize;
    private groupPages;
    private direction;
    private numColumns;
    private numRows;
    private lockAfterImport;
    private pagesToImport;
    private pageDimensionsByPage;
    private importScale;
    private imageSizeMessage;
    private pdfDoc;
    private pdfFile;
    private dirty;
    constructor(plugin: ExcalidrawPlugin, view: ExcalidrawView);
    open(file?: TFile): void;
    onOpen(): void;
    onClose(): void;
    private loadPageDimensions;
    private getMaxSelectedPageDimensions;
    /**
     * Creates a list of numbers from page ranges representing the pages to import.
     * sets the pagesToImport property.
     * @param pageRanges A string representing the pages to import. e.g.: 1,3-5,7,9-10
     * @returns A list of numbers representing the pages to import.
     */
    private createPageListFromString;
    private setImageSizeMessage;
    createForm(): Promise<void>;
}
