import { FuzzySuggestModal, TFile } from "obsidian";
import ExcalidrawView from "../../view/ExcalidrawView";
import ExcalidrawPlugin from "../../core/main";
export declare class ImportSVGDialog extends FuzzySuggestModal<TFile> {
    plugin: ExcalidrawPlugin;
    private view;
    destroy(): void;
    constructor(plugin: ExcalidrawPlugin);
    getItems(): TFile[];
    getItemText(item: TFile): string;
    onChooseItem(item: TFile, _: KeyboardEvent): void;
    onClose(): void;
    start(view: ExcalidrawView): void;
}
