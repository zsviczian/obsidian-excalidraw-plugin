import { ModifierKeySet, ModifierSetType } from "src/utils/modifierkeyHelper";
/** Modifier-key categories rendered by the settings component. */
export declare const MODIFIER_KEY_CATEGORIES: readonly ["WebBrowserDragAction", "LocalFileDragAction", "InternalDragAction", "LinkClickAction"];
/** Returns the localized heading for one modifier-key category. */
export declare const getModifierKeyCategoryName: (modifierSetType: ModifierSetType) => string;
export declare class ModifierKeySettingsComponent {
    private contentEl;
    private modifierKeyConfig;
    private update;
    private isMacOS;
    constructor(contentEl: HTMLElement, modifierKeyConfig: {
        Mac: Record<string, ModifierKeySet>;
        Win: Record<string, ModifierKeySet>;
    }, update: () => void);
    render(): void;
    /** Renders one modifier-key category, optionally with its legacy fold. */
    renderCategory(modifierSetType: ModifierSetType, includeSummary: boolean): void;
}
