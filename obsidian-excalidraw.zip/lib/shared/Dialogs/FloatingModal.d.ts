import { App, Modal } from "obsidian";
export declare class FloatingModal extends Modal {
    private dragging;
    private offsetX;
    private offsetY;
    private readonly pointerDownHandler;
    private readonly pointerMoveHandler;
    private readonly pointerUpHandler;
    private disableKeyCapture;
    private previousActive?;
    private readonly modalKeydownStopHandler;
    private ownerWindow;
    private ownerDocument;
    constructor(app: App);
    protected shouldNotStartDrag(target: HTMLElement, event: PointerEvent | TouchEvent): boolean;
    private handlePointerDown;
    private handlePointerMove;
    private handlePointerUp;
    open(): void;
    close(): void;
    enableKeyCapture(): void;
    disableKeyCaptureFn(): void;
}
