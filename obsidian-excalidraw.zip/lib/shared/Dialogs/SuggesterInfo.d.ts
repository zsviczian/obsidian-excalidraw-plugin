type SuggesterInfo = {
    field: string;
    code: string;
    desc: string;
    after: string;
};
export declare const EXCALIDRAW_AUTOMATE_INFO: SuggesterInfo[];
export declare const EXCALIDRAW_SCRIPTENGINE_INFO: SuggesterInfo[];
export declare const FRONTMATTER_KEYS_INFO: SuggesterInfo[];
export {};
