import { Modal } from "obsidian";
import ExcalidrawPlugin from "src/core/main";
export declare class PublishOutOfDateFilesDialog extends Modal {
    private plugin;
    constructor(plugin: ExcalidrawPlugin);
    onClose(): void;
    onOpen(): void;
    createForm(recursive: boolean): Promise<void>;
}
