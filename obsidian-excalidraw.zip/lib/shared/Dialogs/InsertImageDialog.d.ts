import { FuzzySuggestModal, TFile } from "obsidian";
import ExcalidrawView from "../../view/ExcalidrawView";
import ExcalidrawPlugin from "../../core/main";
export declare class InsertImageDialog extends FuzzySuggestModal<TFile> {
    plugin: ExcalidrawPlugin;
    private view;
    destroy(): void;
    onClose(): void;
    constructor(plugin: ExcalidrawPlugin);
    getItems(): TFile[];
    getItemText(item: TFile): string;
    onChooseItem(item: TFile, event: KeyboardEvent): void;
    start(view: ExcalidrawView): void;
}
