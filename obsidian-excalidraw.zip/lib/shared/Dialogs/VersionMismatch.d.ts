import { Modal } from "obsidian";
import ExcalidrawPlugin from "src/core/main";
/**
 * A modal dialog that informs the user about a version mismatch between the version recorded by Obsidian and the actual version of the plugin executable.
 * Explain that this can be the result of a partial sync, such as an Obsidian Sync Standard plan, which does not syncronize files larger than 5MB, and the plugin executable is larger.
 * Explain that changing the plugin version information in Obsidian can lead to unexpected behavior in plugins suchs as the Plugin Update Tracker plugin or the BRAT plugin.
 * The user has a toggle button to disable this check in the future. There is additional information that this can be reenabled in plugin settings.
 * The user can click update obsidian version info to match the plugin version, and open Obsidian settings to redownload the plugin.
 * The user can click ignore to dismiss the dialog.
 */
export declare class VersionMismatchPrompt extends Modal {
    private plugin;
    private resolvePromise;
    promise: Promise<boolean>;
    private resolved;
    private isDirty;
    constructor(plugin: ExcalidrawPlugin);
    start(): Promise<boolean>;
    private buildUI;
    onClose(): void;
}
