import { Modal } from "obsidian";
import ExcalidrawPlugin from "src/core/main";
/**
 * Lists every script that has ever called `ExcalidrawAutomate.
 * registerAutostart()` (i.e. the user ran it at least once), each with an
 * editable Autostart / Manual start only / Ask every time control (reusing
 * the exact same labels as the permission prompt's buttons, so the two
 * surfaces speak one consistent vocabulary), and a warning if the script's
 * most recent autostart run failed (`settings.autostartScriptFailures`,
 * purely informational - it never changes the script's setting on its
 * own). A "Manual start only" (deny) decision is not a dead end: it can be
 * switched straight back to Autostart or Ask every time from here, without
 * needing to re-run the script to get prompted again.
 *
 * Rendered as a bordered table (header row + one row per script), reusing
 * the AI provider table's existing `.excalidraw-ai-provider-table` CSS (see
 * `renderAISettings()` in `settings.ts`) rather than adding near-duplicate
 * rules to `styles.css`, and rather than a foldable `<details>` section,
 * since this is a short, flat list rather than a large collapsible
 * settings group. Rendered both inline in Settings (under the Startup
 * script setting, in the ExcalidrawAutomate section) and inside
 * `AutostartScriptsModal` for the Command Palette entry point, matching
 * how `EmbeddalbeMDFileCustomDataSettingsComponent` is reused across
 * contexts.
 */
export declare class AutostartScriptsSettingsComponent {
    private contentEl;
    private plugin;
    constructor(contentEl: HTMLElement, plugin: ExcalidrawPlugin);
    render(): void;
}
export declare class AutostartScriptsModal extends Modal {
    private plugin;
    constructor(plugin: ExcalidrawPlugin);
    onOpen(): void;
    onClose(): void;
}
