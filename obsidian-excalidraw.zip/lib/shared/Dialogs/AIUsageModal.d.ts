import { App, Modal } from "obsidian";
import { AIUsageData } from "src/types/AIUtilTypes";
/**
 * Displays accumulated AI token usage for the current session.
 * Provides a per-model breakdown table and a button to copy the data
 * as a Markdown table.
 */
export declare class AIUsageModal extends Modal {
    private readonly usage;
    constructor(app: App, usage: AIUsageData);
    onOpen(): void;
    onClose(): void;
    private formatTokens;
    private buildMarkdownTable;
    private render;
}
