import { App } from "obsidian";
import type { StylesPanelMode } from "@zsviczian/excalidraw/types/common/src/editorInterface";
import type { ExcalidrawSettings } from "src/core/settingsDefaults";
export type UIMode = StylesPanelMode;
export declare class UIModeSettingsComponent {
    private containerEl;
    private settings;
    private app;
    private onChange;
    private reapplyButtonAction;
    constructor(containerEl: HTMLElement, settings: ExcalidrawSettings, app: App, onChange: () => void, reapplyButtonAction?: () => void);
    render(): void;
}
