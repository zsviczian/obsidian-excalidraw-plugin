import ExcalidrawView from "src/view/ExcalidrawView";
export declare const showFrameSettings: (view: ExcalidrawView) => void;
