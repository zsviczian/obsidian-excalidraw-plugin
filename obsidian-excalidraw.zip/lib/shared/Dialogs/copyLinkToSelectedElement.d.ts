import ExcalidrawView from "src/view/ExcalidrawView";
/**
 *
 * @param view - ExcalidrawView instance
 * @param prefix - defines the default button.
 * @returns
 */
export declare function copyLinkToSelectedElementToClipboard(view: ExcalidrawView, prefix: string): Promise<void>;
