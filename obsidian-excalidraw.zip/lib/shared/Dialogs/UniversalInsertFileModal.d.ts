import { TFile } from "obsidian";
import ExcalidrawView from "../../view/ExcalidrawView";
import type ExcalidrawPlugin from "../../core/main";
import { Modal } from "obsidian";
export type UniversalInsertFileAction = "image" | "embeddable";
export declare class UniversalInsertFileModal extends Modal {
    private plugin;
    private view;
    private center;
    private file;
    private preferredAction;
    constructor(plugin: ExcalidrawPlugin, view: ExcalidrawView);
    private onKeyDown;
    open(file?: TFile, center?: {
        x: number;
        y: number;
    }, preferredAction?: UniversalInsertFileAction): void;
    onOpen(): void;
    createForm(): Promise<void>;
    onClose(): void;
}
