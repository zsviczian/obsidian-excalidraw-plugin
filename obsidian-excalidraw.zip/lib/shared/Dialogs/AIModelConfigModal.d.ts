import { App, Modal } from "obsidian";
import { AIImageModelConfig, AIModelConfig, AIProviderProfile } from "src/types/AIUtilTypes";
type SaveHandler<TConfig extends AIModelConfig> = (modelId: string, config: TConfig, previousModelId?: string) => Promise<void> | void;
type AIModelConfigModalOptions<TConfig extends AIModelConfig> = {
    kind: "text" | "vision" | "image";
    providerIds: string[];
    providerProfiles: Record<string, AIProviderProfile>;
    previousModelId?: string;
    initialModelId?: string;
    initialConfig?: TConfig;
};
export declare class AIModelConfigModal<TConfig extends AIModelConfig | AIImageModelConfig> extends Modal {
    private readonly existingModelIds;
    private readonly onSave;
    private readonly options;
    private modelId;
    private config;
    private onKeyDown;
    private listenerHost;
    private backdropInteractionHandler;
    constructor(app: App, existingModelIds: string[], onSave: SaveHandler<TConfig>, options: AIModelConfigModalOptions<TConfig>);
    onOpen(): void;
    onClose(): void;
    private getTitle;
    private getCurrentProviderType;
    private isCurrentGeminiImageModel;
    private syncDerivedGeminiImageSizes;
    private createForm;
    private save;
}
export {};
