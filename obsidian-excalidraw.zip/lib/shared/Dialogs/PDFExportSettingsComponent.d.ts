import { PageOrientation, PageSize, PDFPageAlignment, PDFPageMarginString } from "src/types/exportUtilTypes";
export interface PDFExportSettings {
    pageSize: PageSize;
    pageOrientation: PageOrientation;
    fitToPage: number;
    paperColor: "white" | "scene" | "custom";
    customPaperColor: string;
    alignment: PDFPageAlignment;
    margin: PDFPageMarginString;
}
export declare class PDFExportSettingsComponent {
    private contentEl;
    private settings;
    private update?;
    constructor(contentEl: HTMLElement, settings: PDFExportSettings, update?: () => void);
    isOrientationAndTilingVisible(): boolean;
    render(): void;
}
