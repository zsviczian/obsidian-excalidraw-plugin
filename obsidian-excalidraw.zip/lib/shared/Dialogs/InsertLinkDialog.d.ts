import { FuzzyMatch, FuzzySuggestModal } from "obsidian";
import ExcalidrawPlugin from "src/core/main";
import { LinkSuggestion } from "src/types/types";
export declare class InsertLinkDialog extends FuzzySuggestModal<LinkSuggestion> {
    private plugin;
    private addText;
    private drawingPath;
    destroy(): void;
    constructor(plugin: ExcalidrawPlugin);
    getItems(): LinkSuggestion[];
    getItemText(item: LinkSuggestion): string;
    onChooseItem(item: LinkSuggestion): void;
    renderSuggestion(result: FuzzyMatch<LinkSuggestion>, itemEl: HTMLElement): void;
    getSuggestions(query: string): FuzzyMatch<LinkSuggestion>[];
    onClose(): void;
    private inLink;
    onOpen(): void;
    start(drawingPath: string, addText: (markdownlink: string, path?: string, alias?: string) => void, link?: string): void;
}
