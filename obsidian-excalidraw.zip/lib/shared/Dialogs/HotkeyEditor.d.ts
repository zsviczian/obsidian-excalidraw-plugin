import { BaseComponent } from "obsidian";
import type { ExcalidrawSettings } from "src/core/settingsDefaults";
export declare class HotkeyEditor extends BaseComponent {
    private settings;
    private containerEl;
    private capturing;
    private activeModifiers;
    isDirty: boolean;
    private applySettingsUpdate;
    private boundKeydownHandler;
    private boundKeyupHandler;
    constructor(containerEl: HTMLElement, settings: ExcalidrawSettings, applySettingsUpdate: () => void);
    onload(): void;
    private render;
    private startCapture;
    private onKeydown;
    private onKeyup;
    private stopCapture;
    unload(): void;
    private getModifiersFromEvent;
}
