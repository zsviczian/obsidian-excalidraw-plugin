import { type App, Modal } from "obsidian";
export type SettingsRecoveryChoice = "restore-recovery" | "reset-defaults" | "wait-for-file";
export type SettingsRecoveryPromptMode = "missing-with-recovery" | "invalid-without-recovery";
/** Resolves ambiguous startup settings loss without silently choosing for the user. */
export declare class SettingsRecoveryPrompt extends Modal {
    private readonly mode;
    private resolvePromise;
    private choice;
    constructor(app: App, mode: SettingsRecoveryPromptMode);
    /** Opens the prompt and resolves after the user chooses or closes it. */
    start(): Promise<SettingsRecoveryChoice>;
    onOpen(): void;
    onClose(): void;
}
