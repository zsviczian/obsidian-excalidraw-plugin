import ExcalidrawPlugin from "src/core/main";
import { Modal } from "obsidian";
export declare class UIModeSettings extends Modal {
    private plugin;
    private isDirty;
    constructor(plugin: ExcalidrawPlugin);
    onOpen(): void;
    onClose(): void;
    createForm(): Promise<void>;
    private applySettingsUpdate;
}
