import { App, Modal } from "obsidian";
import type ExcalidrawPlugin from "../../core/main";
type ReleaseNotesOptions = {
    message?: string;
    persistVersion?: boolean;
    title?: string;
};
export declare class ReleaseNotes extends Modal {
    private plugin;
    private options;
    private version;
    private renderComponent;
    constructor(app: App, plugin: ExcalidrawPlugin, version: string, options?: ReleaseNotesOptions);
    onOpen(): void;
    onClose(): void;
    createForm(): Promise<void>;
}
export {};
