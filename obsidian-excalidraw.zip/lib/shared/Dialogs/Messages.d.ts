export declare const RELEASE_NOTES: {
    [k: string]: string;
};
