import { App } from "obsidian";
import { EmbeddableMDCustomProps } from "./EmbeddableSettings";
export declare class EmbeddalbeMDFileCustomDataSettingsComponent {
    private contentEl;
    private mdCustomData;
    private update?;
    private isMDFile;
    private isFullFile;
    private app?;
    constructor(contentEl: HTMLElement, mdCustomData: EmbeddableMDCustomProps, update?: () => void, isMDFile?: boolean, isFullFile?: boolean, app?: App);
    render(): void;
}
