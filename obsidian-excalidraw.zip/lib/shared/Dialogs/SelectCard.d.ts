import { App, FuzzySuggestModal } from "obsidian";
import ExcalidrawView from "src/view/ExcalidrawView";
export declare class SelectCard extends FuzzySuggestModal<string> {
    app: App;
    private view;
    private sections;
    private center;
    private x;
    private y;
    constructor(app: App, view: ExcalidrawView, sections: string[]);
    getItems(): string[];
    getItemText(item: string): string;
    onChooseItem(item: string): void;
    start(center?: boolean): void;
}
