import { App, Modal } from "obsidian";
import { Rank } from "src/constants/actionIcons";
export declare class RankMessage extends Modal {
    private filecount;
    private rank;
    private color;
    private shield;
    private dark;
    private renderComponent;
    constructor(app: App, filecount: number, rank: Rank, color: string, shield: string, dark: string);
    onOpen(): void;
    onClose(): void;
    createForm(): Promise<void>;
}
