import { App, Modal } from "obsidian";
import { AIProviderProfile } from "src/types/AIUtilTypes";
type SaveHandler = (profileId: string, profile: AIProviderProfile, previousProfileId?: string) => Promise<void> | void;
export declare class AIProviderProfileModal extends Modal {
    private readonly existingProfileIds;
    private readonly onSave;
    private readonly options;
    private profileId;
    private profile;
    private onKeyDown;
    private listenerHost;
    private backdropInteractionHandler;
    constructor(app: App, existingProfileIds: string[], onSave: SaveHandler, options?: {
        previousProfileId?: string;
        initialProfileId?: string;
        initialProfile?: AIProviderProfile;
    });
    onOpen(): void;
    onClose(): void;
    private createForm;
    private save;
}
export {};
