import { App, FuzzySuggestModal, TFile } from "obsidian";
import ExcalidrawPlugin from "../../core/main";
export declare enum openDialogAction {
    openFile = 0,
    insertLinkToDrawing = 1
}
export declare class OpenFileDialog extends FuzzySuggestModal<TFile> {
    private plugin;
    private action;
    private onNewPane;
    destroy(): void;
    constructor(app: App, plugin: ExcalidrawPlugin);
    getItems(): TFile[];
    getItemText(item: TFile): string;
    onChooseItem(item: TFile): void;
    start(action: openDialogAction, onNewPane: boolean): void;
}
