import { FuzzySuggestModal, TFile } from "obsidian";
import ExcalidrawView from "../../view/ExcalidrawView";
import ExcalidrawPlugin from "../../core/main";
export declare class InsertMDDialog extends FuzzySuggestModal<TFile> {
    plugin: ExcalidrawPlugin;
    private view;
    destroy(): void;
    constructor(plugin: ExcalidrawPlugin);
    getItems(): TFile[];
    getItemText(item: TFile): string;
    onChooseItem(item: TFile): void;
    start(view: ExcalidrawView): void;
    onClose(): void;
}
