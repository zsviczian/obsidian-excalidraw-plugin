import { Modal, type App } from "obsidian";
/** Folder and filename selected in a {@link FileAndFolderSelectorModal}. */
export type FileAndFolderSelection = {
    folderPath: string;
    fileName: string;
};
/** Labels and initial values for a {@link FileAndFolderSelectorModal}. */
export type FileAndFolderSelectorOptions = FileAndFolderSelection & {
    title: string;
    folderLabel: string;
    fileNameLabel: string;
    submitButtonText: string;
};
/** Prompts for a Vault folder and filename. */
export declare class FileAndFolderSelectorModal extends Modal {
    private readonly options;
    private resolvePromise;
    private result;
    constructor(app: App, options: FileAndFolderSelectorOptions);
    /** Opens the modal and resolves with the selection or null when cancelled. */
    start(): Promise<FileAndFolderSelection | null>;
    onOpen(): void;
    onClose(): void;
}
