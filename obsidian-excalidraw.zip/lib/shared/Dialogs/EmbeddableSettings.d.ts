import { ExcalidrawEmbeddableElement } from "@zsviczian/excalidraw/types/element/src/types";
import { Modal, TFile } from "obsidian";
import ExcalidrawView from "src/view/ExcalidrawView";
import ExcalidrawPlugin from "src/core/main";
export type EmbeddableMDCustomProps = {
    useObsidianDefaults: boolean;
    backgroundMatchCanvas: boolean;
    backgroundMatchElement: boolean;
    backgroundColor: string;
    backgroundOpacity: number;
    borderMatchElement: boolean;
    borderColor: string;
    borderOpacity: number;
    filenameVisible: boolean;
    propertiesVisible?: boolean;
    lockedReadingMode?: boolean;
};
export declare class EmbeddableSettings extends Modal {
    private plugin;
    private view;
    private file;
    private element;
    private ea;
    private updatedFilepath;
    private zoomValue;
    private isYouTube;
    private youtubeStart;
    private isMDFile;
    private notExcalidrawIsInternal;
    private isLocalURI;
    private mdCustomData;
    private onKeyDown;
    private listenerHost;
    constructor(plugin: ExcalidrawPlugin, view: ExcalidrawView, file: TFile, element: ExcalidrawEmbeddableElement);
    onOpen(): void;
    onClose(): void;
    createForm(): Promise<void>;
    private applySettings;
}
