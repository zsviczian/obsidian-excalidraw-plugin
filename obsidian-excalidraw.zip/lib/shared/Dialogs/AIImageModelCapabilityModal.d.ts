import { App, Modal } from "obsidian";
import { AIImageModelCapability } from "src/types/AIUtilTypes";
type SaveHandler = (modelId: string, capability: AIImageModelCapability, previousModelId?: string) => Promise<void> | void;
export declare class AIImageModelCapabilityModal extends Modal {
    private readonly existingModelIds;
    private readonly onSave;
    private readonly options;
    private modelId;
    private supportsPromptImageTransforms;
    private supportsMaskImageEdits;
    private supportedSizes;
    private onKeyDown;
    private listenerHost;
    constructor(app: App, existingModelIds: string[], onSave: SaveHandler, options?: {
        previousModelId?: string;
        initialModelId?: string;
        initialCapability?: AIImageModelCapability;
    });
    onOpen(): void;
    onClose(): void;
    private createForm;
    private save;
}
export {};
