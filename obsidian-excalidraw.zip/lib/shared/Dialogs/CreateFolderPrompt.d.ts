import type ExcalidrawPlugin from "src/core/main";
/** Confirms and creates a missing vault folder without overwriting files. */
export declare const confirmAndCreateFolder: (plugin: ExcalidrawPlugin, requestedPath: string) => Promise<boolean>;
