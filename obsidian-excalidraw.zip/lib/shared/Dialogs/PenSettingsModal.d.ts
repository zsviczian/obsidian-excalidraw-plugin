import { Modal } from "obsidian";
import ExcalidrawView from "src/view/ExcalidrawView";
import ExcalidrawPlugin from "src/core/main";
export declare class PenSettingsModal extends Modal {
    private plugin;
    private view;
    private pen;
    private api;
    private shouldSave;
    private isDirty;
    private tempPenSettings;
    constructor(plugin: ExcalidrawPlugin, view: ExcalidrawView, pen: number);
    onOpen(): void;
    onClose(): void;
    private addActionButtons;
    createForm(): Promise<void>;
}
