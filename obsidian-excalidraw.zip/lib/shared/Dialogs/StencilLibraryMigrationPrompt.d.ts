import { Modal } from "obsidian";
import type ExcalidrawPlugin from "src/core/main";
import type { StencilLibraryMigrationChoice } from "src/types/stencilLibraryTypes";
export type StencilLibraryMigrationResult = {
    choice: StencilLibraryMigrationChoice;
    folderPath: string;
    fileName: string;
};
/** Explains and configures the one-time stencil-library storage migration. */
export declare class StencilLibraryMigrationPrompt extends Modal {
    private readonly plugin;
    private resolvePromise;
    private result;
    constructor(plugin: ExcalidrawPlugin);
    start(): Promise<StencilLibraryMigrationResult>;
    onOpen(): void;
    onClose(): void;
}
