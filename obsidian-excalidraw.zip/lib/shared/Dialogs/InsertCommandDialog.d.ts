import { App, FuzzySuggestModal } from "obsidian";
import type { ObsidianCommand } from "src/types/types";
export declare class InsertCommandDialog extends FuzzySuggestModal<ObsidianCommand> {
    private addText;
    destroy(): void;
    constructor(app: App);
    getItems(): ObsidianCommand[];
    getItemText(item: ObsidianCommand): string;
    onChooseItem(item: ObsidianCommand): void;
    start(addText: (value: string) => void): void;
    onClose(): void;
}
