import ExcalidrawView from "src/view/ExcalidrawView";
type PaletteName = "canvasBackground" | "elementBackground" | "elementStroke";
export declare const showColorPicker: (palette: PaletteName, anchorElement: HTMLElement, view?: ExcalidrawView, includeSceneColors?: boolean) => Promise<string | null>;
export {};
