import { App, Modal, FuzzyMatch, FuzzySuggestModal, Instruction, TFile, TextAreaComponent } from "obsidian";
import ExcalidrawView from "../../view/ExcalidrawView";
import ExcalidrawPlugin from "../../core/main";
import { KeyEvent } from "src/utils/modifierkeyHelper";
import { ExcalidrawElement } from "src/core";
import { ButtonDefinition } from "src/types/promptTypes";
import { Extension } from "@codemirror/state";
import { FloatingModal } from "./FloatingModal";
/**
 * Minimal type for obsidian-latex-suite plugin.
 * Only types the properties actually used by this codebase.
 */
export interface LatexSuitePlugin {
    editorExtensions?: Extension | Extension[];
}
export declare class Prompt extends Modal {
    private prompt_text;
    private default_value?;
    private placeholder?;
    private prompt_desc?;
    private promptEl;
    private resolve;
    constructor(app: App, prompt_text: string, default_value?: string, placeholder?: string, prompt_desc?: string);
    onOpen(): void;
    onClose(): void;
    createForm(): void;
    openAndGetValue(resolve: (value: string) => void): Promise<void>;
}
export declare class LaTexPrompt extends FloatingModal {
    private prompt_text;
    private default_value?;
    waitForClose: Promise<string>;
    private resolvePromise;
    private rejectPromise;
    private editorView;
    private readonly latexsSuitePlugin;
    protected constructor(app: App, prompt_text: string, default_value?: string);
    protected shouldNotStartDrag(target: HTMLElement, event: PointerEvent | TouchEvent): boolean;
    static Prompt(plugin: ExcalidrawPlugin, app: App, prompt_text?: string, default_value?: string): Promise<string>;
    private display;
    private createButton;
    private submitCallback;
    private cancelCallback;
    onOpen(): void;
    onClose(): void;
}
export declare class GenericInputPrompt extends Modal {
    private header;
    waitForClose: Promise<string>;
    private view;
    private plugin;
    private resolvePromise;
    private rejectPromise;
    private didSubmit;
    private inputComponent;
    private input;
    private buttons;
    private lines;
    private displayEditorButtons;
    private readonly placeholder;
    private selectionStart;
    private selectionEnd;
    private selectionUpdateTimer;
    private customComponents;
    private blockPointerInputOutsideModal;
    private controlsOnTop;
    private draggable;
    private cleanupDragListeners;
    private handleKeyDown;
    private handleCheckCaret;
    static Prompt(view: ExcalidrawView, plugin: ExcalidrawPlugin, app: App, header: string, placeholder?: string, value?: string, buttons?: ButtonDefinition[], lines?: number, displayEditorButtons?: boolean, customComponents?: (container: HTMLElement) => void, blockPointerInputOutsideModal?: boolean, controlsOnTop?: boolean, draggable?: boolean): Promise<string>;
    protected constructor(view: ExcalidrawView, plugin: ExcalidrawPlugin, app: App, header: string, placeholder?: string, value?: string, buttons?: ButtonDefinition[], lines?: number, displayEditorButtons?: boolean, customComponents?: (container: HTMLElement) => void, blockPointerInputOutsideModal?: boolean, controlsOnTop?: boolean, draggable?: boolean);
    private display;
    protected createInputField(container: HTMLElement, placeholder?: string, value?: string): TextAreaComponent;
    private createButton;
    private createButtonBar;
    private linkBtnClickCallback;
    private insertStringBtnClickCallback;
    private delBtnClickCallback;
    private uppercaseBtnClickCallback;
    private submitClickCallback;
    private cancelClickCallback;
    private submit;
    private cancel;
    private resolveInput;
    private removeInputListener;
    private specialCharsBtnClickCallback;
    onOpen(): void;
    private makeModalDraggable;
    onClose(): void;
}
export declare class GenericSuggester<T> extends FuzzySuggestModal<T> {
    private displayItems;
    private items;
    private hint?;
    private instructions?;
    private resolvePromise;
    private rejectPromise;
    promise: Promise<T>;
    private resolved;
    static Suggest<T>(app: App, displayItems: string[], items: T[], hint?: string, instructions?: Instruction[]): Promise<T>;
    constructor(app: App, displayItems: string[], items: T[], hint?: string, instructions?: Instruction[]);
    getItemText(item: T): string;
    getItems(): T[];
    selectSuggestion(value: FuzzyMatch<T>, evt: MouseEvent | KeyboardEvent): void;
    onChooseItem(item: T): void;
    onClose(): void;
}
export declare class NewFileActions extends Modal {
    waitForClose: Promise<TFile | null>;
    private resolvePromise;
    private rejectPromise;
    private newFile;
    private plugin;
    private path;
    private keys;
    private view;
    private openNewFile;
    private parentFile;
    private sourceElement;
    private followObsidianNewNoteLocation;
    constructor({ plugin, path, keys, view, openNewFile, parentFile, sourceElement, followObsidianNewNoteLocation, }: {
        plugin: ExcalidrawPlugin;
        path: string;
        keys: KeyEvent;
        view: ExcalidrawView;
        openNewFile?: boolean;
        parentFile?: TFile;
        sourceElement?: ExcalidrawElement;
        followObsidianNewNoteLocation?: boolean;
    });
    onOpen(): void;
    openFile(file: TFile): void;
    onClose(): void;
    createForm(): void;
}
/** Optional toggle shown with a multi-option confirmation prompt. */
export interface ConfirmationPromptToggle {
    name: string;
    description?: string;
    defaultValue?: boolean;
}
export declare class MultiOptionConfirmationPrompt<T = boolean | null> extends Modal {
    private plugin;
    private readonly toggle?;
    waitForClose: Promise<T>;
    /** Current value of the optional toggle. */
    toggleValue: boolean;
    private resolvePromise;
    private rejectPromise;
    private selectedValue;
    private readonly message;
    private readonly buttons;
    private ctaButtonLabel;
    private ctaButtonEl;
    constructor(plugin: ExcalidrawPlugin, message: string, buttons?: Map<string, T>, ctaButtonLabel?: string, toggle?: ConfirmationPromptToggle);
    private display;
    private createButton;
    onOpen(): void;
    onClose(): void;
}
export declare function linkPrompt(linkText: string, app: App, view?: ExcalidrawView, message?: string): Promise<[file: TFile, linkText: string, subpath: string]>;
export declare const templatePromt: (files: TFile[], app: App) => Promise<TFile>;
