/**
 ** About the various text fields of textElements
 ** rawText vs. text vs. original text
    text: The displyed text. This will have linebreaks if wrapped & will be the parsed text or the original-markup depending on Obsidian view mode
    originalText: this is the text without added linebreaks for wrapping. This will be parsed or markup depending on view mode
    rawText: text with original markdown markup and without the added linebreaks for wrapping
 */
import { App, TFile } from "obsidian";
import ExcalidrawPlugin from "../core/main";
import { TextMode } from "./TextMode";
import type ExcalidrawView from "../view/ExcalidrawView";
import { LinkParts } from "../utils/sceneDataUtils";
import { ExcalidrawElement, FileId } from "@zsviczian/excalidraw/types/element/src/types";
import { BinaryFiles, DataURL, SceneData } from "@zsviczian/excalidraw/types/excalidraw/types";
import { EmbeddedFile, type EmbeddedFileExportState } from "./EmbeddedFileLoader";
import { MimeType } from "src/types/embeddedFileLoaderTypes";
import { Mutable } from "@zsviczian/excalidraw/types/common/src/utility-types";
import { type MarkdownImageData, type MarkdownImageRenderSettings } from "src/types/markdownImageTypes";
import { changeThemeOfExcalidrawMD, DRAWING_COMPRESSED_REG, getExcalidrawMarkdownHeader, getExcalidrawMarkdownHeaderSection, getJSON, getMarkdownDrawingSection, getMarkdownDrawingSectionAsync, parseMarkdownImages, syncMarkdownImagesInHeader, unwrapMarkdownImageBlock } from "./excalidrawMarkdownParsing";
export { changeThemeOfExcalidrawMD, DRAWING_COMPRESSED_REG, getExcalidrawMarkdownHeader, getExcalidrawMarkdownHeaderSection, getJSON, getMarkdownDrawingSection, getMarkdownDrawingSectionAsync, parseMarkdownImages, syncMarkdownImagesInHeader, unwrapMarkdownImageBlock, };
type SceneDataWithFiles = SceneData & {
    files: BinaryFiles;
};
type LegacyGridColor = NonNullable<NonNullable<SceneData["appState"]>["gridColor"]> & {
    MajorGridFrequency?: number;
};
/**
 * `SceneDataWithFiles` (via `SceneData`) already declares optional
 * `elements`/`appState` fields. Intersecting it directly would make
 * TypeScript intersect those declarations with the stricter ones below
 * (e.g. `readonly ExcalidrawElement[] & Mutable<ExcalidrawElement>[]`)
 * instead of replacing them, which silently collapses every `.filter()`/
 * `.find()` call on `scene.elements` to `any`. Omitting them first makes
 * this an actual override.
 */
export type ExcalidrawDataScene = Omit<SceneDataWithFiles, "elements" | "appState"> & {
    type?: string;
    version?: number;
    source?: string;
    theme?: NonNullable<SceneData["appState"]>["theme"];
    prevTextMode?: TextMode;
    gridStep?: number;
    elements: Mutable<ExcalidrawElement>[];
    appState: Mutable<NonNullable<SceneData["appState"]>> & {
        previousGridSize?: number | null;
        gridColor?: LegacyGridColor;
    };
};
type RegExpMatchIteratorResult = IteratorResult<RegExpMatchArray, undefined>;
type LoadGenerationGuard = () => boolean;
export declare enum AutoexportPreference {
    none = 0,
    both = 1,
    png = 2,
    svg = 3,
    inherit = 4
}
export declare const REGEX_TAGS: {
    EXPR: RegExp;
    getResList: (text: string) => RegExpMatchIteratorResult[];
    getTag: (parts: RegExpMatchIteratorResult) => string;
    isTag: (parts: RegExpMatchIteratorResult) => boolean;
};
export declare const REGEX_LINK: {
    EXPR: RegExp;
    getResList: (text: string) => RegExpMatchIteratorResult[];
    getRes: (text: string) => IterableIterator<RegExpMatchArray>;
    isTransclusion: (parts: RegExpMatchIteratorResult) => boolean;
    getLink: (parts: RegExpMatchIteratorResult) => string;
    isWikiLink: (parts: RegExpMatchIteratorResult) => boolean;
    getAliasOrLink: (parts: RegExpMatchIteratorResult) => string;
    getWrapLength: (parts: RegExpMatchIteratorResult, defaultWrap: number) => number;
};
export declare const REG_LINKINDEX_HYPERLINK: RegExp;
export type EquationItem = {
    latex: string;
    isLoaded: boolean;
};
export type MermaidItem = {
    mermaid: string;
    isLoaded: boolean;
};
type TextElementData = {
    raw: string;
    parsed: string;
    hasTextLink: boolean;
};
/** Drawing-owned registries required to regenerate save-time export assets. */
export interface ExcalidrawDataExportState {
    sourceFilePath: string;
    files: ReadonlyMap<FileId, EmbeddedFileExportState>;
    markdownImages: ReadonlyMap<FileId, MarkdownImageData>;
    equations: ReadonlyMap<FileId, EquationItem>;
    markdownImageRenderDefaults: MarkdownImageRenderSettings;
    pdfScale: number;
}
/** Drawing-owned metadata transferred without retaining an old view. */
export interface ExcalidrawDataMigrationState {
    sourceFilePath: string;
    textElements: ReadonlyMap<string, TextElementData>;
    scene: ExcalidrawDataScene;
    deletedElements: readonly ExcalidrawElement[];
    showLinkBrackets: boolean;
    linkPrefix: string;
    embeddableTheme: "light" | "dark" | "auto" | "default";
    urlPrefix: string;
    autoexportPreference: AutoexportPreference;
    textMode: TextMode;
    loaded: boolean;
    elementLinks: ReadonlyMap<string, string>;
    files: ReadonlyMap<FileId, EmbeddedFile>;
    markdownImages: ReadonlyMap<FileId, MarkdownImageData>;
    equations: ReadonlyMap<FileId, EquationItem>;
    mermaids: ReadonlyMap<FileId, MermaidItem>;
    compatibilityMode: boolean;
    textElementCommentedOut: boolean;
    selectedElementIds: Readonly<Record<string, boolean>>;
}
export declare class ExcalidrawData {
    plugin: ExcalidrawPlugin;
    private view?;
    textElements: Map<string, TextElementData>;
    scene: ExcalidrawDataScene;
    deletedElements: ExcalidrawElement[];
    file: TFile;
    app: App;
    private showLinkBrackets;
    private linkPrefix;
    embeddableTheme: "light" | "dark" | "auto" | "default";
    private urlPrefix;
    autoexportPreference: AutoexportPreference;
    private textMode;
    loaded: boolean;
    elementLinks: Map<string, string>;
    files: Map<FileId, EmbeddedFile>;
    markdownImages: Map<FileId, MarkdownImageData>;
    equations: Map<FileId, EquationItem>;
    mermaids: Map<FileId, MermaidItem>;
    private compatibilityMode;
    private textElementCommentedOut;
    selectedElementIds: {
        [key: string]: boolean;
    };
    private embeddedDataRegistries;
    constructor(plugin: ExcalidrawPlugin, view?: ExcalidrawView);
    destroy(): void;
    /** Captures only the data registries needed by a prepared save export. */
    exportPreparedSaveData(): ExcalidrawDataExportState | null;
    /**
     * Exports drawing-owned state for a one-shot window migration.
     *
     * Collection containers and mutable metadata records are copied. Immutable
     * Excalidraw elements and `EmbeddedFile` descriptors are transferred by
     * reference: neither owns a view, DOM node, `Window`, React runtime, or
     * package lease, and retaining their cached asset metadata is intentional.
     */
    exportMigrationState(): ExcalidrawDataMigrationState | null;
    /** Adopts a validated drawing-state export into this new view-owned model. */
    adoptMigrationState(state: ExcalidrawDataMigrationState, file: TFile): boolean;
    /**
     * 1.5.4: for backward compatibility following the release of container bound text elements and the depreciation boundElementIds field
     */
    private initializeNonInitializedFields;
    /**
     * Loads a new drawing
     * @param {TFile} file - the MD file containing the Excalidraw drawing
     * @returns {boolean} - true if file was loaded, false if there was an error
     */
    loadData(data: string, file: TFile, textMode: TextMode, isCurrent?: LoadGenerationGuard): Promise<boolean>;
    loadLegacyData(data: string, file: TFile, isCurrent?: LoadGenerationGuard): Promise<boolean>;
    setTextMode(textMode: TextMode, isCurrent?: LoadGenerationGuard): Promise<boolean>;
    /**
     * Updates the TextElements in the Excalidraw scene based on textElements MAP in ExcalidrawData
     * Depending on textMode, TextElements will receive their raw or parsed values
     * @param forceupdate : will update text elements even if text contents has not changed, this will
     * correct sizing issues
     */
    private updateSceneTextElements;
    private getText;
    private findNewElementLinksInScene;
    /**
     * check for textElements in Scene missing from textElements Map
     * @returns {boolean} - true if there were changes
     */
    private findNewTextElementsInScene;
    private getSceneElementIndexes;
    private updateElementLinksFromScene;
    /**
     * update text element map by deleting entries that are no long in the scene
     * and updating the textElement map based on the text updated in the scene
     */
    private updateTextElementsFromScene;
    private parseasync;
    private parseLinks;
    /**
     *
     * @param text
     * @returns [string,number] - the transcluded text, and the line number for the location of the text
     */
    getTransclusion(link: string): Promise<{
        contents: string;
        lineNum: number;
    }>;
    /**
     * Process aliases and block embeds
     * @param text
     * @returns
     */
    private parse;
    /**
     * Public wrapper around the internal text parser.
     *
     * This reuses existing ExcalidrawData parsing behavior, including
     * transclusions, link formatting, and prefix handling.
     * @param text Raw text to parse.
     * @returns Parsed text string.
     */
    parseText(text: string): Promise<string>;
    private parseCheckbox;
    private unescapeSquareBrackets;
    /**
     * Does a quick parse of the raw text. Returns the parsed string if raw text does not include a transclusion.
     * Return null if raw text includes a transclusion.
     * This is implemented in a separate function, because by nature resolving a transclusion is an asynchronious
     * activity. Quick parse gets the job done synchronously if possible.
     * @param text
     */
    private quickParse;
    /**
     * Generate markdown file representation of excalidraw drawing
     * @returns markdown string
     */
    disableCompression: boolean;
    generateMDBase(deletedElements?: ExcalidrawElement[]): {
        outString: string;
        sceneJSONstring: string;
    };
    generateMDAsync(deletedElements?: ExcalidrawElement[]): Promise<string>;
    generateMDSync(deletedElements?: ExcalidrawElement[]): string;
    saveDataURLtoVault(dataURL: DataURL, mimeType: MimeType, key: FileId, name?: string): Promise<TFile>;
    private syncCroppedPDFs;
    /**
     * deletes fileIds from Excalidraw data for files no longer in the scene
     * @returns
     */
    private syncFiles;
    syncElements(newScene: SceneDataWithFiles, selectedElementIds?: {
        [key: string]: boolean;
    }): Promise<boolean>;
    updateScene(newScene: string): Promise<boolean>;
    getRawText(id: string): string;
    /**
     * returns parsed text with the correct line length
     * @param id
     * @returns
     */
    getParsedText(id: string): string;
    getParsedResult(id: string): TextElementData;
    /**
     * Attempts to quickparse (sycnhronously) the raw text.
     *
     * If successful:
     *   - it will set the textElements cache with the parsed result, and
     *   - return the parsed result as an array of 3 values: [parsedTextWrapped, parsedText, link]
     *
     * If the text contains a transclusion:
     *   - it will initiate the async parse, and
     *   - it will return [null,null,null].
     * @param elementID
     * @param rawText
     * @param rawOriginalText
     * @param updateSceneCallback
     * @returns [parseResultOriginal: string, link: string]
     */
    setTextElement(elementID: string, rawOriginalText: string, updateSceneCallback: (parsedText: string) => void): [parseResultOriginal: string, link: string];
    addTextElement(elementID: string, rawText: string, rawOriginalText: string): Promise<{
        parseResult: string;
        link: string;
    }>;
    deleteTextElement(id: string): void;
    getOpenMode(): {
        viewModeEnabled: boolean;
        zenModeEnabled: boolean;
    };
    getLinkOpacity(): number;
    getOnLoadScript(): string;
    private setLinkPrefix;
    private setUrlPrefix;
    private setAutoexportPreferences;
    private setembeddableThemePreference;
    private setShowLinkBrackets;
    /**
     Files, equations and mermaid copy/paste support
     This is not a complete solution, it assumes the source document is opened first
     at that time the fileId is stored in the master files/equations map
     when pasted the map is checked if the file already exists
     This will not work if pasting from one vault to another, but for the most common usecase
     of copying an image or equation from one drawing to another within the same vault
     this is going to do the job
    */
    setFile(fileId: FileId, data: EmbeddedFile): void;
    getFiles(): EmbeddedFile[];
    getFile(fileId: FileId): EmbeddedFile;
    getFileEntries(): MapIterator<[FileId, EmbeddedFile]>;
    deleteFile(fileId: FileId): void;
    hasFile(fileId: FileId): boolean;
    setEquation(fileId: FileId, data: {
        latex: string;
        isLoaded: boolean;
    }): void;
    getEquation(fileId: FileId): {
        latex: string;
        isLoaded: boolean;
    };
    getEquationEntries(): MapIterator<[FileId, EquationItem]>;
    deleteEquation(fileId: FileId): void;
    hasEquation(fileId: FileId): boolean;
    /** Stores a local Markdown-image source and makes it available for intra-vault copy/paste. */
    setMarkdownImage(fileId: FileId, data: MarkdownImageData): void;
    /** Returns local Markdown, restoring it from the intra-vault copy master. */
    getMarkdownImage(fileId: FileId): MarkdownImageData | undefined;
    /** Returns whether local Markdown exists, restoring intra-vault clipboard data. */
    hasMarkdownImage(fileId: FileId): boolean;
    /** Removes a local source, optionally discarding its clipboard master entry. */
    deleteMarkdownImage(fileId: FileId, clearMaster?: boolean): void;
    setMermaid(fileId: FileId, data: {
        mermaid: string;
        isLoaded: boolean;
    }): void;
    getMermaid(fileId: FileId): {
        mermaid: string;
        isLoaded: boolean;
    };
    getMermaidEntries(): MapIterator<[FileId, MermaidItem]>;
    deleteMermaid(fileId: FileId): void;
    hasMermaid(fileId: FileId): boolean;
}
export declare const getTransclusion: (linkParts: LinkParts, app: App, file: TFile, charCountLimit?: number) => Promise<{
    contents: string;
    lineNum: number;
    leadingHashes?: string;
}>;
