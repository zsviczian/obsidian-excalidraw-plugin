import ExcalidrawScene from "./elements/ExcalidrawScene";
import Group from "./elements/Group";
export declare function createTreeWalker(dom: Node): TreeWalker;
type WalkerArgs = {
    root: Document;
    tw: TreeWalker;
    scene: ExcalidrawScene;
    groups: Group[];
};
export declare function walk(args: WalkerArgs, nextNode: Node | null): void;
export {};
