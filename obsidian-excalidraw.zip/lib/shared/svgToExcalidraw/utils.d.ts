import type { Point } from "./elements/ExcalidrawElement";
export declare const randomInteger: () => number;
export declare const randomId: () => string;
export declare function dimensionsFromPoints(points: number[][]): number[];
export declare function getWindingOrder(points: Point[]): "clockwise" | "counterclockwise";
