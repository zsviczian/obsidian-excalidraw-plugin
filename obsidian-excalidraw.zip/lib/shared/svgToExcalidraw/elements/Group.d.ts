import { ExcalidrawElementBase } from "../elements/ExcalidrawElement";
export declare function getGroupAttrs(groups: Group[]): Partial<ExcalidrawElementBase>;
declare class Group {
    id: string;
    element: Element;
    constructor(element: Element);
}
export default Group;
