import { RawElement } from "../../types";
export declare const convert: (node: Element) => RawElement[];
