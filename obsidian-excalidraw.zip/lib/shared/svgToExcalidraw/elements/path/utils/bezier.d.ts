/**
 * Get list of points for a cubic bézier curve.
 * Starting point is not returned
 */
export declare const curveToPoints: (type: "cubic" | "quadratic", controlPoints: number[][], nbPoints?: number) => number[][];
