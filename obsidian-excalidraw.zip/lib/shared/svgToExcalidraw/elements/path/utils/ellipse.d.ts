/**
 * Get each possible ellipses center points given two points and ellipse radius
 * @see https://math.stackexchange.com/questions/2240031/solving-an-equation-for-an-ellipse
 */
export declare const getEllipsesCenter: (curX: number, curY: number, destX: number, destY: number, radiusX: number, radiusY: number) => number[][];
/**
 * Get all points of a given ellipse
 */
export declare const getEllipsePoints: (centerX: number, centerY: number, radiusX: number, radiusY: number) => number[][];
/**
 * Find ellipse arc given sweep parameter
 */
export declare const findArc: (points: number[][], sweep: boolean, curX: number, curY: number, destX: number, destY: number) => number[][];
