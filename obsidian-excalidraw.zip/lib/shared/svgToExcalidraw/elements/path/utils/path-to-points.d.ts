/**
 * Convert a SVG path data to list of points
 */
declare const pathToPoints: (path: string) => number[][][];
export default pathToPoints;
