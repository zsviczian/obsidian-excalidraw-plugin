import { ElementBoundaries } from "../types";
export declare const getElementBoundaries: (points: number[][]) => ElementBoundaries;
