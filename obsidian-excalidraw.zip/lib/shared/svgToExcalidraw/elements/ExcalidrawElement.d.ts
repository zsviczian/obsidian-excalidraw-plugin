import type { ExcalidrawEllipseElement, ExcalidrawLineElement, ExcalidrawRectangleElement } from "@zsviczian/excalidraw/types/element/src/types";
import type { Mutable } from "@zsviczian/excalidraw/types/common/src/utility-types";
/** Internal, unbranded working point used by every geometry helper in this
 * module (bezier/ellipse/path math, matrix transforms). Only converted to
 * the real fork's branded `LocalPoint` at the point an element is finalized
 * -- see `toLocalPoint()`. */
export type Point = [number, number];
/**
 * Mutable local copy of the fork's element base shape. The real
 * `_ExcalidrawElementBase` type is `Readonly` and not exported on its own,
 * so this is derived via `Omit` from `ExcalidrawRectangleElement` (which
 * adds nothing beyond the `type` discriminant over the real base) rather
 * than hand-duplicating every field -- field types can't drift from the
 * real ones this way. `Mutable` strips the `readonly` modifiers so the
 * existing object-literal-mutation style in attributes.ts keeps working.
 */
export type ExcalidrawElementBase = Mutable<Omit<ExcalidrawRectangleElement, "type">>;
export type ExcalidrawRectangle = Mutable<ExcalidrawRectangleElement>;
export type ExcalidrawEllipse = Mutable<ExcalidrawEllipseElement>;
export type ExcalidrawLine = Mutable<ExcalidrawLineElement>;
export type ExcalidrawGenericElement = ExcalidrawRectangle | ExcalidrawEllipse | ExcalidrawLine;
export declare function createExElement(): ExcalidrawElementBase;
export declare function createExRect(): ExcalidrawRectangle;
export declare function createExEllipse(): ExcalidrawEllipse;
/** SVG shapes converted to a "line" element are always closed, fillable
 * regions (the polygon feature didn't exist yet when this module was
 * written; every caller wants `polygon: true`). */
export declare function createExLine(points?: readonly Point[]): ExcalidrawLine;
