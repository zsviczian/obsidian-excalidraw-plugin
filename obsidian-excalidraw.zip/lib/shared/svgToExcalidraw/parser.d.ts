import { ExcalidrawGenericElement } from "./elements/ExcalidrawElement";
export type ConversionResult = {
    hasErrors: boolean;
    errors: string;
    content: ExcalidrawGenericElement[];
};
export declare const svgToExcalidraw: (svgString: string) => ConversionResult;
