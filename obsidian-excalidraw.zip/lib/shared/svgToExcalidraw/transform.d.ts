import Group from "./elements/Group";
import { mat4 } from "gl-matrix";
export declare const createDOMMatrixFromSVGStr: (svgTransformStr: string) => DOMMatrix;
export declare function getElementMatrix(el: Element): mat4;
export declare function getTransformMatrix(el: Element, groups: Group[]): mat4;
export declare function transformPoints(points: number[][], transform: mat4): [number, number][];
