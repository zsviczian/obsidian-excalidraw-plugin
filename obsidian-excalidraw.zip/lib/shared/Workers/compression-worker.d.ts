export declare function initCompressionWorker(): void;
export declare function runCompressionWorker(data: string, action: "compress" | "decompress"): Promise<string>;
export declare function terminateCompressionWorker(): void;
export declare let IS_WORKER_SUPPORTED: boolean;
