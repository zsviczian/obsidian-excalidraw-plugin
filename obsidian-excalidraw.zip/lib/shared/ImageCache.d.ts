import ExcalidrawPlugin from "src/core/main";
import { PDFPageViewProps, Size } from "src/types/embeddedFileLoaderTypes";
import { FILENAMEPARTS, PreviewImageType } from "../types/utilTypes";
type FileCacheData = {
    schemaVersion: 2;
    payloadKind: "svg" | "raster";
    mtime: number;
    blob: Blob;
    renderScale?: number;
    size?: Size;
    hasSVGwithBitmap?: boolean;
    pdfPageViewProps?: PDFPageViewProps;
};
type ImageCacheMetadata = Partial<Pick<FileCacheData, "renderScale" | "size" | "hasSVGwithBitmap" | "pdfPageViewProps">>;
type BackupData = string;
export type ImageKey = {
    filepath: string;
    cacheId?: string;
    blockref: string;
    sectionref: string;
    isDark: boolean;
    previewImageType: PreviewImageType;
    scale: number;
    isTransparent: boolean;
    inlineFonts: boolean;
} & FILENAMEPARTS;
type GetImageFromCacheOptions = {
    skipDependencyCheck?: boolean;
    minRenderScale?: number;
    expectedPayloadKind?: FileCacheData["payloadKind"];
    requireSvgInspectionMetadata?: boolean;
    svgFormat?: "element" | "data-url";
    onCacheHit?: (metadata: {
        mtime: number;
        renderScale?: number;
        size?: Size;
        hasSVGwithBitmap?: boolean;
        payloadKind: FileCacheData["payloadKind"];
    }) => void;
};
declare class ImageCache {
    private dbName;
    private cacheStoreName;
    private cacheAccessStoreName;
    private backupStoreName;
    private legacyCacheStoreNames;
    private db;
    private isInitializing;
    private plugin;
    private app;
    initializationNotice: boolean;
    private obsidanURLCache;
    private purgeInvalidCacheTimer;
    private purgeInvalidBackupTimer;
    private touchedCacheKeys;
    private cacheReadinessPromise;
    private backupWrites;
    private getCacheRetentionCutoff;
    /**
     * Records cache use without rewriting the potentially very large image value.
     * The access store has a disjoint transaction scope, so these small writes do
     * not block image-cache reads. One write per key and plugin session is enough
     * for retention-based housekeeping.
     */
    private touchCacheData;
    destroy(): void;
    constructor(dbName: string, cacheStoreName: string, cacheAccessStoreName: string, backupStoreName: string, legacyCacheStoreNames: readonly string[]);
    /**
     * Creates the current cache stores and removes disposable legacy image-cache
     * stores in the same IndexedDB version-change transaction.
     *
     * The drawing backup store is deliberately preserved. Legacy image payloads
     * are not converted because doing so would deserialize and rewrite the full
     * cache during startup; the v2 cache is rebuilt lazily as images are used.
     */
    private applyStoreSchema;
    private requiresStoreUpgrade;
    initializeDB(plugin: ExcalidrawPlugin): Promise<void>;
    private ensureCacheStoreReady;
    private getCacheAccessTimes;
    private isCurrentCacheData;
    private purgeInvalidCacheFiles;
    private purgeInvalidBackupFiles;
    private getObjectStore;
    private getCacheData;
    private getBackupData;
    isReady(): boolean;
    private getResolvedCacheData;
    getImageCacheData(key_: ImageKey, options?: GetImageFromCacheOptions): Promise<FileCacheData | undefined>;
    getImageFromCache(key_: ImageKey, options?: GetImageFromCacheOptions): Promise<string | SVGSVGElement | undefined>;
    /** Returns the number of live raster blob URLs retained by the session cache. */
    getObsidianURLCacheSize(): number;
    releaseObsidianURL(url: string): void;
    getBAKFromCache(filepath: string): Promise<BackupData | null>;
    addImageToCache(key_: ImageKey, obsidianURL: string, image: Blob | SVGSVGElement, metadata?: ImageCacheMetadata): void;
    addBAKToCache(filepath: string, data: BackupData): Promise<void>;
    /**
     * Schedules the latest backup payload through the plugin-global queue.
     */
    scheduleBAKToCache(filepath: string, data: BackupData, delayMs: number): boolean;
    /** Flushes any queued backup before a drawing path is renamed. */
    flushPendingBAK(filepath: string): Promise<void>;
    removeBAKFromCache(filepath: string): Promise<void>;
    clearImageCache(): Promise<void>;
    clearBackupCache(): Promise<void>;
    private clear;
}
export declare const getImageCache: () => ImageCache;
/**
 * Queues the exact text from a completed drawing write for recovery.
 * Backup failure is logged independently and never changes source persistence.
 */
export declare const scheduleBAKAfterSuccessfulPersistence: (filepath: string, data: BackupData) => void;
export {};
