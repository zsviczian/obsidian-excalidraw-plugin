import ExcalidrawPlugin from "src/core/main";
export declare class GlobalTaskQueue {
    private plugin;
    private queue;
    private activeCount;
    constructor(plugin: ExcalidrawPlugin);
    addTask(task: () => Promise<void>): Promise<void>;
    private processNext;
}
export declare const getGlobalTaskQueue: (plugin: ExcalidrawPlugin) => GlobalTaskQueue;
