import { ExcalidrawAutomate } from "../ExcalidrawAutomate";
import ExcalidrawPlugin from "../../core/main";
import { ExcalidrawElement } from "@zsviczian/excalidraw/types/element/src/types";
import ExcalidrawView from "src/view/ExcalidrawView";
export default class Taskbone {
    private plugin;
    get apiKey(): string;
    constructor(plugin: ExcalidrawPlugin);
    destroy(): void;
    initialize(save?: boolean): Promise<string>;
    getTextForElements(elements: ExcalidrawElement[], ea: ExcalidrawAutomate): Promise<string>;
    getTextForView(view: ExcalidrawView, { forceReScan, selectedElementsOnly, addToFrontmatter, }: {
        forceReScan: boolean;
        selectedElementsOnly?: boolean;
        addToFrontmatter?: boolean;
    }): Promise<void>;
    private getTextForImage;
}
