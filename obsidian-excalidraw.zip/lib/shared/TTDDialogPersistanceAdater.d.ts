import type { TTDPersistenceAdapter } from "@zsviczian/excalidraw";
export declare const ttdPersistenceAdapter: TTDPersistenceAdapter;
