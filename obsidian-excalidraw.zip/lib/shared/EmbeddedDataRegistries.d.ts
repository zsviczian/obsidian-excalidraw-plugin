/**
 * Owns the four per-drawing embedded-data registries on `ExcalidrawData`:
 * embedded files, LaTeX equations, local Markdown images, and Mermaid
 * diagrams. Each registry mirrors its entries into a matching plugin-wide
 * "master" map (`ExcalidrawPlugin.filesMaster`/`equationsMaster`/
 * `markdownImagesMaster`/`mermaidsMaster`) so intra-vault copy/paste can
 * restore a fileId's data in a drawing that never natively loaded it.
 * Extracted intact from `ExcalidrawData.ts`; `ExcalidrawData` keeps every
 * method below as a public delegate for compatibility with its existing
 * callers.
 */
import type { FileId } from "@zsviczian/excalidraw/types/element/src/types";
import type { MarkdownImageData } from "src/types/markdownImageTypes";
import type { EmbeddedFile } from "./EmbeddedFileLoader";
import type { ExcalidrawData, EquationItem, MermaidItem } from "./ExcalidrawData";
export declare class EmbeddedDataRegistries {
    private host;
    private embeddedFileCtor;
    /**
     * `embeddedFileCtor` is constructor-injected (rather than imported as a
     * value) so this module stays type-only with respect to
     * `EmbeddedFileLoader.ts`, matching the existing pattern used to avoid
     * adding new circular-import edges around the `ExcalidrawData` cluster
     * (see `ViewLinkNavigationManager`/`ViewExcalidrawExtensionRenderer`).
     */
    constructor(host: ExcalidrawData, embeddedFileCtor: typeof EmbeddedFile);
    setFile(fileId: FileId, data: EmbeddedFile): void;
    getFiles(): EmbeddedFile[];
    getFile(fileId: FileId): EmbeddedFile;
    getFileEntries(): MapIterator<[FileId, EmbeddedFile]>;
    deleteFile(fileId: FileId): void;
    hasFile(fileId: FileId): boolean;
    setEquation(fileId: FileId, data: {
        latex: string;
        isLoaded: boolean;
    }): void;
    getEquation(fileId: FileId): EquationItem;
    getEquationEntries(): MapIterator<[FileId, EquationItem]>;
    deleteEquation(fileId: FileId): void;
    hasEquation(fileId: FileId): boolean;
    /** Stores a local Markdown-image source and makes it available for intra-vault copy/paste. */
    setMarkdownImage(fileId: FileId, data: MarkdownImageData): void;
    /** Returns local Markdown, restoring it from the intra-vault copy master. */
    getMarkdownImage(fileId: FileId): MarkdownImageData | undefined;
    /** Returns whether local Markdown exists, restoring intra-vault clipboard data. */
    hasMarkdownImage(fileId: FileId): boolean;
    /** Removes a local source, optionally discarding its clipboard master entry. */
    deleteMarkdownImage(fileId: FileId, clearMaster?: boolean): void;
    setMermaid(fileId: FileId, data: {
        mermaid: string;
        isLoaded: boolean;
    }): void;
    getMermaid(fileId: FileId): MermaidItem;
    getMermaidEntries(): MapIterator<[FileId, MermaidItem]>;
    deleteMermaid(fileId: FileId): void;
    hasMermaid(fileId: FileId): boolean;
}
