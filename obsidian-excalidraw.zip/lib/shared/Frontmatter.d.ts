export default class FrontmatterEditor {
    private frontmatterStr;
    private dataWOfrontmatter;
    private initialized;
    constructor(data: string);
    hasKey(key: string): boolean;
    setKey(key: string, value: string): void;
    get data(): string;
}
