export declare class WeakArray<T extends object> {
    private weakArray;
    constructor();
    push(obj: T): void;
    forEach(callback: (obj: T, index: number) => void): void;
    removeObjects(objectsToRemove: Set<T>): void;
    clear(): void;
}
