import type { Mutable } from "@zsviczian/excalidraw/types/common/src/utility-types";
import { TFile } from "obsidian";
import type { ExcalidrawElement, ExcalidrawEmbeddableElement, ExcalidrawImageElement } from "@zsviczian/excalidraw/types/element/src/types";
import type ExcalidrawPlugin from "src/core/main";
import type ExcalidrawView from "src/view/ExcalidrawView";
import { EmbeddedFile } from "src/shared/EmbeddedFileLoader";
import { type MarkdownImageCustomData, type MarkdownImageRenderSettings, type MarkdownImageSource } from "src/types/markdownImageTypes";
export type MarkdownImageSourceData = {
    markdown: string;
    source: MarkdownImageSource;
    embeddedFile?: EmbeddedFile;
};
/** Returns whether a fragment would collide with its storage delimiter. */
export declare function containsReservedMarkdownImageMarker(markdown: string): boolean;
/** Reads the feature metadata from an image element without modifying it. */
export declare function getMarkdownImageCustomData(element: ExcalidrawElement): MarkdownImageCustomData | undefined;
/** Resolves the element appearance, then the configured defaults. */
export declare function getMarkdownImageRenderSettings(plugin: ExcalidrawPlugin, element?: ExcalidrawElement): MarkdownImageRenderSettings;
/** Writes Markdown-image metadata through the repository custom-data helper. */
export declare function setMarkdownImageCustomData(element: Mutable<ExcalidrawImageElement>, source: MarkdownImageSource, render: MarkdownImageRenderSettings): void;
/** Resolves a Markdown image element or Markdown file to its renderable source. */
export declare function getMarkdownImageSource(view: ExcalidrawView, source: ExcalidrawImageElement | TFile | EmbeddedFile): Promise<MarkdownImageSourceData | null>;
/** Returns whether an image can be edited through the Markdown-image panel. */
export declare function isMarkdownImageElement(view: ExcalidrawView, element: ExcalidrawImageElement): boolean;
/** Resolves a Markdown embeddable into a local or external image source. */
export declare function getEmbeddableMarkdownImageSource(view: ExcalidrawView, element: ExcalidrawEmbeddableElement): Promise<MarkdownImageSourceData | null>;
/** Retypes a Markdown embeddable as a full-height Markdown image. */
export declare function convertEmbeddableElementToMarkdownImage(view: ExcalidrawView, element: ExcalidrawEmbeddableElement, sourceData: MarkdownImageSourceData): Promise<boolean>;
/** Retypes a Markdown image as an embeddable while preserving scene identity. */
export declare function convertMarkdownImageElementToEmbeddable(view: ExcalidrawView, element: ExcalidrawImageElement, link: string): Promise<boolean>;
/** Finds level-one ATX and Setext headings outside fenced code blocks. */
export declare function getLevelOneMarkdownHeadings(markdown: string): Array<{
    title: string;
    index: number;
}>;
/** Inserts an editable Markdown image from local text or a linked Markdown note. */
export declare function insertMarkdownImage(view: ExcalidrawView, source?: string | TFile | EmbeddedFile, position?: {
    x: number;
    y: number;
}): Promise<ExcalidrawImageElement | null>;
/** Duplicates a local Markdown image with independent element and file IDs. */
export declare function duplicateLocalMarkdownImageElement(view: ExcalidrawView, element: ExcalidrawImageElement): Promise<string | null>;
/** Renders and applies current source and appearance settings to an image. */
export declare function updateMarkdownImage(view: ExcalidrawView, element: ExcalidrawImageElement, markdown: string, render: MarkdownImageRenderSettings, source: MarkdownImageSource, sameFileEditOwnerOrShouldApply?: string | (() => boolean), shouldApplyAfterOwner?: () => boolean): Promise<boolean>;
