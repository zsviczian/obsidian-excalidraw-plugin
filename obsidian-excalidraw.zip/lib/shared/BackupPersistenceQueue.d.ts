type BackupPersistenceQueueOptions = {
    ownerWindow: Window;
    write: (filepath: string, data: string) => Promise<void>;
    onError?: (error: unknown, stage: "write") => void;
};
/**
 * Coalesces plugin-global drawing backups by vault path.
 *
 * @remarks
 * Each path owns at most one IndexedDB write and one latest trailing payload.
 * The timer belongs to the main application window because persistent plugin
 * storage is shared by main and popout views.
 */
export declare class BackupPersistenceQueue {
    private readonly ownerWindow;
    private readonly write;
    private readonly onError?;
    private readonly writes;
    constructor(options: BackupPersistenceQueueOptions);
    /**
     * Schedules the latest payload for a path.
     *
     * @returns `true` when an older pending payload was replaced or the new
     * payload was coalesced behind an active write.
     */
    schedule(filepath: string, data: string, delayMs: number): boolean;
    /** Writes all currently pending data for one path without the normal delay. */
    flush(filepath: string): Promise<void>;
    /** Cancels queued data and waits for an already-active write to settle. */
    cancel(filepath: string): Promise<void>;
    /** Cancels every queued backup before the backup store is cleared. */
    cancelAll(): Promise<void>;
    /** Drops timers and references during plugin unload without starting writes. */
    destroy(): void;
    private clearTimer;
    private scheduleDrain;
    private drain;
}
export {};
