export declare enum TextMode {
    parsed = "parsed",
    raw = "raw"
}
export declare function getTextMode(data: string): TextMode;
