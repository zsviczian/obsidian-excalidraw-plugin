/**
 * Parsing helpers for the "## Drawing" scene section, the user-editable
 * Markdown header that precedes it, and the marker-delimited local
 * Markdown-image blocks stored inside that header. Extracted intact from
 * `ExcalidrawData.ts`, which remains the primary consumer alongside several
 * other modules that read or write the same Markdown structure.
 */
import { FileId } from "@zsviczian/excalidraw/types/element/src/types";
import { type MarkdownImageData } from "src/types/markdownImageTypes";
export declare const DRAWING_COMPRESSED_REG: RegExp;
export declare const changeThemeOfExcalidrawMD: (data: string) => string;
export declare function getJSON(data: string): {
    scene: string;
    pos: number;
};
export declare function getMarkdownDrawingSectionAsync(jsonString: string, compressed: boolean): Promise<string>;
export declare function getMarkdownDrawingSection(jsonString: string, compressed: boolean): string;
/**
 * Reads locally stored Markdown-image bodies from marker-delimited blocks.
 * Marker matching is deliberately independent of headings and block position.
 */
export declare function parseMarkdownImages(data: string): Map<FileId, MarkdownImageData>;
/**
 * Removes a local Markdown-image block's marker comments while preserving its
 * Markdown body and surrounding document content exactly.
 *
 * @param data - Complete Excalidraw Markdown document.
 * @param fileId - File ID identifying the local Markdown-image block.
 * @param markdown - Optional current in-memory body to preserve instead of a
 * potentially stale body from the document.
 * @returns The document with the matching marker comments removed.
 */
export declare function unwrapMarkdownImageBlock(data: string, fileId: FileId, markdown?: string): string;
/**
 * Synchronizes local Markdown-image bodies in the user-editable note header.
 * Existing blocks stay where the user placed them; only missing blocks receive
 * the default scaffolding immediately above Excalidraw Data.
 */
export declare function syncMarkdownImagesInHeader(header: string, markdownImages: ReadonlyMap<FileId, MarkdownImageData>): string;
export declare const RE_EXCALIDRAWDATA_NOSECTION_OK: RegExp;
export declare const RE_TEXTELEMENTS_NOSECTION_OK: RegExp;
export declare const RE_EXCALIDRAWDATA_FALLBACK_2: RegExp;
export declare const RE_TEXTELEMENTS_FALLBACK_2: RegExp;
export declare function getExcalidrawMarkdownHeader(data: string): {
    header: string;
    shouldFixTrailingHashtag: boolean;
    processingOk: boolean;
};
export declare const getExcalidrawMarkdownHeaderSection: (data: string, keys?: [string, string][]) => string;
