import type { ExcalidrawElement, FileId } from "@zsviczian/excalidraw/types/element/src/types";
import { DataURL } from "@zsviczian/excalidraw/types/excalidraw/types";
import { TFile } from "obsidian";
import { ExcalidrawData } from "./ExcalidrawData";
import type ExcalidrawPlugin from "../core/main";
import { LinkParts } from "../utils/sceneDataUtils";
import { FILENAMEPARTS } from "../types/utilTypes";
import { ColorMap, PDFPageViewProps, Size, MimeType, FileData } from "src/types/embeddedFileLoaderTypes";
import { type MarkdownImageRenderSettings } from "src/types/markdownImageTypes";
import { type MarkdownImageRenderCacheEntry } from "src/utils/markdownImageUtils";
/** Minimal drawing-owned data required to resolve export/scene assets. */
export interface EmbeddedFilesDataSource {
    file: ExcalidrawData["file"];
    scene: ExcalidrawData["scene"];
    getFileEntries: ExcalidrawData["getFileEntries"];
    getFile: ExcalidrawData["getFile"];
    getMarkdownImage: ExcalidrawData["getMarkdownImage"];
    getEquationEntries: ExcalidrawData["getEquationEntries"];
    getEquation: ExcalidrawData["getEquation"];
}
/** View-independent state needed to recreate one embedded-file descriptor. */
export interface EmbeddedFileExportState {
    readonly filePath: string | null;
    readonly isSVGwithBitmap: boolean;
    readonly img: string;
    readonly imgInverted: string;
    readonly mtime: number;
    readonly mimeType: MimeType;
    readonly size: Size;
    readonly linkParts: LinkParts | null;
    readonly filenameparts: FILENAMEPARTS | null;
    readonly hostPath: string;
    readonly attemptCounter: number;
    readonly isHyperLink: boolean;
    readonly isLocalLink: boolean;
    readonly isMarkdownSection: boolean;
    readonly hyperlink: DataURL | null;
    readonly colorMap: ColorMap | null;
    readonly pdfPageViewProps: PDFPageViewProps | null;
    readonly renderScale: number;
}
type CacheValidationMode = "validated" | "stale-first";
export type EmbeddedFilesLoaderTerminalState = "idle" | "running" | "completed" | "terminated" | "timed-out" | "failed";
/** Describes the lightweight work required after a stale-first cache hit. */
export type DeferredCacheValidation = {
    kind: "excalidraw-dependencies";
    cacheMtime: number;
} | {
    kind: "reload";
};
type LoadSceneEmitPolicy = "all" | "changed-only";
export type MarkdownSVGRenderResult = {
    dataURL: DataURL;
    hasSVGwithBitmap: boolean;
    size: Size;
};
export declare class EmbeddedFile {
    file: TFile;
    isSVGwithBitmap: boolean;
    private img;
    private imgInverted;
    mtime: number;
    private plugin;
    mimeType: MimeType;
    size: Size;
    linkParts: LinkParts;
    filenameparts: FILENAMEPARTS;
    private hostPath;
    attemptCounter: number;
    isHyperLink: boolean;
    isLocalLink: boolean;
    isMarkdownSection: boolean;
    hyperlink: DataURL;
    colorMap: ColorMap | null;
    pdfPageViewProps: PDFPageViewProps;
    renderScale: number;
    /** Captures loader inputs and reusable data URLs without retaining a view. */
    exportPreparedSaveState(): EmbeddedFileExportState;
    /** Recreates a mutable loader descriptor from detached prepared-save data. */
    static fromPreparedSaveState(plugin: ExcalidrawPlugin, state: EmbeddedFileExportState): EmbeddedFile;
    constructor(plugin: ExcalidrawPlugin, hostPath: string, imgPath: string, colorMapJSON?: string);
    get hasSeparateDarkAndLightVersion(): boolean;
    resetImage(hostPath: string, imgPath: string): void;
    private fileChanged;
    setImage({ imgBase64, mimeType, size, isDark, isSVGwithBitmap, pdfPageViewProps, renderScale, }: {
        imgBase64: string;
        mimeType: MimeType;
        size: Size;
        isDark: boolean;
        isSVGwithBitmap: boolean;
        pdfPageViewProps?: PDFPageViewProps;
        renderScale?: number;
    }): void;
    isLoaded(isDark: boolean, minimumPdfRenderScale?: number): boolean;
    getImage(isDark: boolean): string;
    /**
     *
     * @returns true if image should scale such as the updated images has the same area as the previous images, false if the image should be displayed at 100%
     */
    shouldScale(): boolean;
}
export declare class EmbeddedFilesLoader {
    private pdfDocsMap;
    private pdfDocs;
    private plugin;
    private isDark;
    terminate: boolean;
    terminalState: EmbeddedFilesLoaderTerminalState;
    uid: string;
    constructor(plugin: ExcalidrawPlugin, isDark?: boolean);
    emptyPDFDocsMap(): void;
    /**
     * Renders an in-memory Markdown fragment using the same SVG pipeline as
     * Markdown file embeds. Unlike ordinary embeds, the returned image is never
     * height-clipped.
     */
    renderMarkdownToSVG(sourceFile: TFile, markdown: string, render: MarkdownImageRenderSettings): Promise<MarkdownSVGRenderResult>;
    getObsidianImage(inFile: TFile | EmbeddedFile, depth: number): Promise<{
        mimeType: MimeType;
        fileId: FileId;
        dataURL: DataURL;
        created: number;
        hasSVGwithBitmap: boolean;
        size: {
            height: number;
            width: number;
        };
        pdfPageViewProps?: PDFPageViewProps;
    }>;
    private getExcalidrawSVG;
    private getLocalPath;
    private _getObsidianImage;
    loadSceneFiles({ excalidrawData, addFiles, depth, isThemeChange, fileIDWhiteList, forceReloadFileIDs, cacheValidation, validationConcurrency, emitPolicy, onDeferredValidationCandidates, deferredCacheValidation, sceneElements, waitForRender, prioritizedFileIds, markdownImageRenderCache, loadedMarkdownImageFileIds, markdownImageRenderDefaults, pdfScale, }: {
        excalidrawData: EmbeddedFilesDataSource;
        addFiles: (files: FileData[], isDark: boolean, final?: boolean) => void;
        depth: number;
        isThemeChange?: boolean;
        fileIDWhiteList?: Set<FileId>;
        forceReloadFileIDs?: Set<FileId>;
        cacheValidation?: CacheValidationMode;
        validationConcurrency?: number;
        emitPolicy?: LoadSceneEmitPolicy;
        onDeferredValidationCandidates?: (candidates: Map<FileId, DeferredCacheValidation>) => void;
        deferredCacheValidation?: ReadonlyMap<FileId, DeferredCacheValidation>;
        sceneElements?: readonly ExcalidrawElement[];
        waitForRender?: () => Promise<void>;
        prioritizedFileIds?: ReadonlySet<FileId>;
        markdownImageRenderCache?: Map<FileId, MarkdownImageRenderCacheEntry>;
        loadedMarkdownImageFileIds?: ReadonlySet<FileId>;
        markdownImageRenderDefaults?: MarkdownImageRenderSettings;
        pdfScale?: number;
    }): Promise<void>;
    private pdfToDataURL;
    private convertMarkdownToSVG;
}
export declare const generateIdFromFile: (file: ArrayBuffer, key?: string) => Promise<FileId>;
export {};
