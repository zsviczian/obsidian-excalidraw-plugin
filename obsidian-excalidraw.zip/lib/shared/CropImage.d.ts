import { ExcalidrawElement } from "@zsviczian/excalidraw/types/element/src/types";
import type { BinaryFiles } from "@zsviczian/excalidraw/types/excalidraw/types";
/**
 * Creates a masked image from an Excalidraw scene.
 *
 * The scene must contain:
 * - One element.type="frame" element that defines the crop area
 * - One or more element.type="image" elements
 * - Zero or more non-image shape elements (rectangles, ellipses etc) that define the mask
 *
 * The class splits the scene into two parts:
 * 1. Images (managed in imageEA)
 * 2. Mask shapes (managed in maskEA)
 *
 * A transparent rectangle matching the combined bounding box is added to both
 * imageEA and maskEA to ensure consistent sizing between image and mask.
 *
 * For performance, if there is only one image, it is not rotated, and
 * its size matches the bounding box,
 * the image data is used directly from cache rather than regenerating.
 *
 * @example
 * const cropper = new CropImage(elements, files);
 * const pngBlob = await cropper.getCroppedPNG();
 * cropper.destroy();
 */
export declare class CropImage {
    private elements;
    private imageEA;
    private maskEA;
    private bbox;
    constructor(elements: ExcalidrawElement[], files: BinaryFiles);
    destroy(): void;
    private setBoundingEl;
    private getViewBoxAndSize;
    private getMaskSVG;
    private getImage;
    private buildSVG;
    getCroppedPNG(): Promise<Blob>;
    getCroppedSVG(): Promise<SVGSVGElement>;
}
