import { App, FuzzyMatch, TFile } from "obsidian";
import { SuggestionModal } from "./SuggestionModal";
import { LinkSuggestion } from "src/types/types";
import type ExcalidrawPlugin from "src/core/main";
import { KeyBlocker } from "src/types/excalidrawAutomateTypes";
type HeadingSuggestion = {
    kind: "heading";
    heading: string;
    level: number;
    anchor: string;
    file: TFile;
};
type ParagraphSuggestion = {
    kind: "paragraph";
    text: string;
    id?: string;
    file: TFile;
    node: {
        type: string;
        position?: {
            start: number;
            end: {
                offset: number;
            };
        };
    };
};
type TagSuggestion = {
    kind: "tag";
    tag: string;
    count: number;
};
type FrameSuggestion = {
    kind: "frame";
    label: string;
    target: string;
    id: string;
    file: TFile;
    refKind: "frame" | "clippedframe";
};
type InlineSuggestion = LinkSuggestion | HeadingSuggestion | ParagraphSuggestion | TagSuggestion | FrameSuggestion;
/**
 * Inline link suggester that attaches to a specific input element.
 */
export declare class InlineLinkSuggester extends SuggestionModal<InlineSuggestion> implements KeyBlocker {
    private readonly getSourcePath;
    private readonly plugin;
    private readonly widthHost;
    private readonly hasCustomWidthHost;
    private readonly handleBracketKeyDown;
    private block;
    private activeOpen;
    private activeClose;
    private activeTagStart;
    private activeTagEnd;
    private caretPos;
    private activeAlias;
    private activeSearchTerm;
    private activeFile;
    private mode;
    private headingItems;
    private paragraphItems;
    private frameItems;
    private tagItems;
    private linkItemsLoaded;
    constructor(app: App, plugin: ExcalidrawPlugin, inputEl: HTMLInputElement | HTMLTextAreaElement, getSourcePath: () => string | undefined, widthWrapper?: HTMLElement, suppressPlaceholder?: boolean, collisionBoundary?: HTMLElement);
    isBlockingKeys(): boolean;
    private onBracketKeyDown;
    getItems(): InlineSuggestion[];
    /**
     * Keep the suggestion dropdown aligned to the provided width host (input or wrapper).
     */
    private syncWidth;
    /**
     * Refreshes the suggestion data (e.g. when vault changes) without recreating the instance.
     */
    refreshItems(): void;
    /**
     * Loads the vault-wide file-link candidates only after a wikilink is active.
     */
    private ensureLinkItemsLoaded;
    modifyInput(input: string): string;
    onInputChanged(): void;
    private getTagSuggestions;
    private getTagSearchValue;
    getSuggestions(): FuzzyMatch<InlineSuggestion>[];
    private isHeading;
    private isParagraph;
    private isTag;
    private isFrame;
    getItemText(item: InlineSuggestion): string;
    onChooseItem(item: InlineSuggestion | undefined): void;
    selectSuggestion(value: FuzzyMatch<InlineSuggestion>, evt: MouseEvent | KeyboardEvent): void;
    open(): void;
    renderSuggestion(result: FuzzyMatch<InlineSuggestion>, itemEl: HTMLElement): void;
    private buildLink;
    private insertLink;
    private insertTag;
    private resetSuggestions;
    private parseLinkContext;
    private loadFrames;
    private loadHeadings;
    private loadParagraphs;
    private cleanHeading;
    private renderFrameSuggestionRow;
    private renderTextWithHighlights;
    private ensureParagraphHasId;
    close(): void;
    onEscape(): void;
    private findActiveLink;
    private findActiveTag;
    private extractActiveInfo;
    private dispatchInputChange;
}
export {};
