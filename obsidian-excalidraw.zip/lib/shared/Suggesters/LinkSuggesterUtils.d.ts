import { App, FuzzyMatch } from "obsidian";
import { LinkSuggestion } from "src/types/types";
import ExcalidrawPlugin from "src/core/main";
/**
 * Returns Obsidian link suggestions (files, aliases, unresolved) filtered for invalid characters.
 */
export declare const getLinkSuggestionsFiltered: (app: App) => LinkSuggestion[];
/**
 * Returns fuzzy matches sorted by fuzzy score, then recency, then name for stability.
 */
export declare const getSortedLinkMatches: (term: string, items: LinkSuggestion[]) => FuzzyMatch<LinkSuggestion>[];
export declare const fuzzyMatchTextItems: <T>(term: string, items: T[], getText: (item: T) => string) => FuzzyMatch<T>[];
export declare const fuzzyMatchParagraphsWithId: <T extends {
    id?: string;
    text: string;
}>(term: string, items: T[]) => FuzzyMatch<T>[];
export declare const renderHeadingSuggestionRow: (result: FuzzyMatch<{
    heading: string;
    level?: number;
}>, note: string, itemEl: HTMLElement) => void;
export declare const renderParagraphSuggestionRow: (result: FuzzyMatch<{
    text: string;
    id?: string;
}>, note: string, itemEl: HTMLElement) => void;
/**
 * Standard rendering for link suggestions with icons and highlights.
 */
export declare const renderLinkSuggestion: (plugin: ExcalidrawPlugin, result: FuzzyMatch<LinkSuggestion>, itemEl: HTMLElement, emptyStateText: string) => void;
