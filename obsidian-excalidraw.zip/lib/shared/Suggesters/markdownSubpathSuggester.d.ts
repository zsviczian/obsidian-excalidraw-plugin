import { type App, type TFile } from "obsidian";
export type MarkdownHeadingSubpath = {
    display: string;
    subpath: string;
};
/** Returns link subpaths for user-authored Markdown headings. */
export declare function getMarkdownHeadingSubpaths(app: App, file: TFile, isExcalidrawFile: boolean): Promise<MarkdownHeadingSubpath[]>;
/** Prompts for a Markdown heading and returns its link subpath. */
export declare function selectMarkdownHeadingSubpath(app: App, file: TFile, isExcalidrawFile: boolean, isCancelled?: () => boolean): Promise<string | null>;
/** Prompts for a Markdown block, creating a block ID when required. */
export declare function selectMarkdownBlockSubpath(app: App, file: TFile, isCancelled?: () => boolean): Promise<string | null>;
