import { SuggestModal, Scope } from "obsidian";
export declare class Suggester<T> {
    owner: SuggestModal<T>;
    items: T[];
    suggestions: HTMLElement[];
    selectedItem: number;
    containerEl: HTMLElement;
    constructor(owner: SuggestModal<T>, containerEl: HTMLElement, scope: Scope);
    chooseSuggestion(evt: KeyboardEvent): void;
    onSuggestionClick(event: MouseEvent, el: HTMLElement): void;
    onSuggestionMouseover(event: MouseEvent, el: HTMLElement): void;
    empty(): void;
    setSuggestions(items: T[]): void;
    useSelectedItem(event: MouseEvent | KeyboardEvent): void;
    wrap(value: number, size: number): number;
    setSelectedItem(index: number, scroll: boolean): void;
}
