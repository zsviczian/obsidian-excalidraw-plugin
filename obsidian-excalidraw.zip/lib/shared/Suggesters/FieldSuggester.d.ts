import { Editor, EditorPosition, EditorSuggest, EditorSuggestContext, EditorSuggestTriggerInfo, TFile } from "obsidian";
import type ExcalidrawPlugin from "../../core/main";
/**
 * The field suggester recommends document properties in source mode, ea and utils function and attribute names.
 */
export declare class FieldSuggester extends EditorSuggest<string> {
    plugin: ExcalidrawPlugin;
    suggestType: "ea" | "excalidraw" | "utils";
    latestTriggerInfo: EditorSuggestTriggerInfo;
    constructor(plugin: ExcalidrawPlugin);
    onTrigger(cursor: EditorPosition, editor: Editor, _: TFile): EditorSuggestTriggerInfo | null;
    getSuggestions: (context: EditorSuggestContext) => string[];
    renderSuggestion(suggestion: string, el: HTMLElement): void;
    selectSuggestion(suggestion: string): void;
}
