import { AbstractInputSuggest, App, TAbstractFile } from "obsidian";
type VaultPathSuggestionKind = "file" | "folder" | "file-or-folder";
/** Adds reusable Vault-aware completion to settings path inputs. */
export declare class VaultPathSuggest extends AbstractInputSuggest<TAbstractFile> {
    private readonly candidates;
    private readonly input;
    constructor(app: App, inputEl: HTMLInputElement, kind: VaultPathSuggestionKind, extensions?: readonly string[]);
    protected getSuggestions(query: string): TAbstractFile[];
    renderSuggestion(file: TAbstractFile, el: HTMLElement): void;
    selectSuggestion(file: TAbstractFile): void;
    private getInputEl;
}
export {};
