import { FuzzyMatch, TFile, BlockCache, HeadingCache, CachedMetadata, TextComponent, App } from "obsidian";
import { SuggestionModal } from "./SuggestionModal";
export declare class PathSuggestionModal extends SuggestionModal<TFile | BlockCache | HeadingCache> {
    file: TFile;
    files: TFile[];
    text: TextComponent;
    cache: CachedMetadata;
    private handleGetFile;
    constructor(app: App, input: TextComponent, items: TFile[]);
    getFile(): void;
    close(): void;
    getItemText(item: TFile | HeadingCache | BlockCache): string;
    onChooseItem(item: TFile | HeadingCache | BlockCache): void;
    selectSuggestion({ item }: FuzzyMatch<TFile | BlockCache | HeadingCache>): void;
    renderSuggestion(result: FuzzyMatch<TFile | BlockCache | HeadingCache>, el: HTMLElement): void;
    get headings(): HeadingCache[];
    get blocks(): BlockCache[];
    getItems(): TFile[] | HeadingCache[] | BlockCache[];
}
