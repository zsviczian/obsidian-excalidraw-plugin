import { FuzzyMatch, CachedMetadata, TextComponent, App, TFolder } from "obsidian";
import { SuggestionModal } from "./SuggestionModal";
export declare class FolderSuggestionModal extends SuggestionModal<TFolder> {
    text: TextComponent;
    cache: CachedMetadata;
    folders: TFolder[];
    folder: TFolder;
    private handleGetFolder;
    constructor(app: App, input: TextComponent, items: TFolder[]);
    getFolder(): void;
    close(): void;
    getItemText(item: TFolder): string;
    onChooseItem(item: TFolder): void;
    selectSuggestion({ item }: FuzzyMatch<TFolder>): void;
    renderSuggestion(result: FuzzyMatch<TFolder>, el: HTMLElement): void;
    getItems(): TFolder[];
}
