import { FuzzyMatch, TFile, CachedMetadata, TextComponent, App } from "obsidian";
import { SuggestionModal } from "./SuggestionModal";
import { LinkSuggestion } from "src/types/types";
import ExcalidrawPlugin from "src/core/main";
export declare class FileSuggestionModal extends SuggestionModal<LinkSuggestion> {
    private plugin;
    text: TextComponent;
    cache: CachedMetadata;
    filesAndAliases: LinkSuggestion[];
    file: TFile;
    private handleGetFile;
    constructor(app: App, input: TextComponent, items: TFile[], plugin: ExcalidrawPlugin);
    getFile(): void;
    getSelectedItem(): TFile;
    getItemText(item: LinkSuggestion): string;
    onChooseItem(item: LinkSuggestion): void;
    selectSuggestion({ item }: FuzzyMatch<LinkSuggestion>): void;
    renderSuggestion(result: FuzzyMatch<LinkSuggestion>, itemEl: HTMLElement): void;
    getItems(): LinkSuggestion[];
    close(): void;
}
