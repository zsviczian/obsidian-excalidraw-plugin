import { DataURL } from "@zsviczian/excalidraw/types/excalidraw/types";
import ExcalidrawView from "../view/ExcalidrawView";
import { FileData, MimeType } from "src/types/embeddedFileLoaderTypes";
import { FileId } from "@zsviczian/excalidraw/types/element/src/types";
import ExcalidrawPlugin from "src/core/main";
import type { MathJaxRenderOptions } from "src/types/mathJaxTypes";
export declare const updateEquation: (equation: string, fileId: FileId, view: ExcalidrawView, addFiles: (files: FileData[], view: ExcalidrawView) => void) => Promise<void>;
export declare function tex2dataURL(tex: string, scale: number, plugin: ExcalidrawPlugin, options?: MathJaxRenderOptions): Promise<{
    mimeType: MimeType;
    fileId: FileId;
    dataURL: DataURL;
    created: number;
    size: {
        height: number;
        width: number;
    };
} | null>;
export declare const clearMathJaxVariables: (plugin: ExcalidrawPlugin) => void;
