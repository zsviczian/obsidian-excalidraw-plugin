export declare class ContentSearcher {
    private contentDiv;
    private searchBar;
    private prevButton;
    private nextButton;
    private showHideButton;
    private inputContainer;
    private hitCount;
    private searchBarWrapper;
    constructor(contentDiv: HTMLElement);
    /**
     * Creates search UI elements styled like Obsidian's native search
     */
    private createSearchElements;
    /**
     * Attach event listeners to search elements
     */
    private setupEventListeners;
    /** Copies the complete legacy settings DOM as Markdown. */
    copyContentAsMarkdown(): void;
    /**
     * Highlight all instances of the search term in the content
     */
    highlightSearchTerm(searchTerm: string): void;
    /**
     * Remove all search highlights
     */
    clearHighlights(): void;
    /**
     * Navigate to next or previous search result
     */
    navigateSearchResults(direction: "next" | "previous"): void;
    /**
     * Expand all parent <details> elements to make the element visible
     */
    private expandParentDetails;
    private scrollResultIntoView;
    private getScrollContainer;
}
