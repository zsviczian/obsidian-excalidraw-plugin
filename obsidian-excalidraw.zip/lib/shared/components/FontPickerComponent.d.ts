import { App, ValueComponent } from "obsidian";
import type { SelectableFontOption } from "src/types/fontTypes";
type BuiltInFontCssProvider = (fontFamily: string) => Promise<string | null>;
/**
 * Obsidian-styled font selector whose options preview their respective faces.
 *
 * The option provider is invoked whenever the menu opens, allowing vault font
 * additions, removals, and renames to appear without maintaining a file cache.
 * Local font binaries are loaded only for the selected option and visible menu
 * rows. Callers may also provide built-in font CSS when their owning document
 * does not already receive Excalidraw's window-scoped font registration.
 */
export declare class FontPickerComponent extends ValueComponent<string> {
    private readonly app;
    private readonly getOptions;
    private readonly getBuiltInFontCss?;
    readonly buttonEl: HTMLButtonElement;
    private readonly labelEl;
    private readonly id;
    private previewFontId;
    private value;
    private onChanged;
    private menu;
    private optionObserver;
    private readonly loadedPreviewFonts;
    private readonly builtInPreviewStyles;
    private readonly builtInPreviewLoads;
    private readonly handleClick;
    constructor(containerEl: HTMLElement, app: App, getOptions: () => SelectableFontOption[], getBuiltInFontCss?: BuiltInFontCssProvider);
    /** Returns the currently selected font value. */
    getValue(): string;
    /** Selects a font without invoking the change callback. */
    setValue(value: string): this;
    /** Registers the callback invoked when the user selects a font. */
    onChange(callback: (value: string) => void): this;
    /** Enables or disables interaction with the picker. */
    setDisabled(disabled: boolean): this;
    /** Sets the accessible label on the picker trigger. */
    setAriaLabel(label: string): this;
    /** Releases menu, DOM, observer, and document font resources. */
    destroy(): void;
    private openMenu;
    private observeLocalPreviews;
    private updateTrigger;
    private applyPreview;
    private ensureBuiltInPreviewFont;
    private loadBuiltInPreviewFont;
    private ensureLocalPreviewFont;
    private prunePreviewFonts;
}
export {};
