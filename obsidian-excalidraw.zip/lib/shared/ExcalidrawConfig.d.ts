import type ExcalidrawPlugin from "src/core/main";
export declare class ExcalidrawConfig {
    areaLimit: number;
    widthHeightLimit: number;
    constructor(plugin: ExcalidrawPlugin);
    updateValues(plugin: ExcalidrawPlugin): void;
}
