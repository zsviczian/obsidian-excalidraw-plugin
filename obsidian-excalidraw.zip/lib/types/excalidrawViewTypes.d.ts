import { ViewStateResult, WorkspaceLeaf } from "obsidian";
import { AppState, BinaryFiles, ExcalidrawProps, SceneData } from "@zsviczian/excalidraw/types/excalidraw/types";
import { ExcalidrawElement, FileId } from "@zsviczian/excalidraw/types/element/src/types";
import { CaptureUpdateActionType } from "@zsviczian/excalidraw/types/element/src/store";
import { ObsidianCanvasNode } from "../view/managers/CanvasNodeFactory";
export type Position = {
    x: number;
    y: number;
};
export interface SelectedElementWithLink {
    id: string | null;
    text: string | null;
}
export interface SelectedImage {
    id: string | null;
    fileId: FileId | null;
}
export interface EmbeddableLeafRef {
    leaf: WorkspaceLeaf;
    node?: ObsidianCanvasNode;
    editNode?: () => void;
}
export interface AutoexportConfig {
    png: boolean;
    svg: boolean;
    excalidraw: boolean;
    theme: "light" | "dark" | "both";
}
export type ExcalidrawViewScene = Omit<SceneData, "collaborators" | "captureUpdate"> & {
    elements: NonNullable<SceneData["elements"]>;
    appState: NonNullable<SceneData["appState"]>;
    files: BinaryFiles;
};
export type ExcalidrawViewAppState = Omit<Partial<AppState>, "showHyperlinkPopup"> & {
    pinnedScripts?: string[];
    showHyperlinkPopup?: AppState["showHyperlinkPopup"] | {
        newValue: string;
        oldValue: string;
    };
};
export type ExcalidrawViewUpdateScene = {
    elements?: ExcalidrawElement[];
    appState?: ExcalidrawViewAppState;
    files?: BinaryFiles;
    forceFlushSync?: boolean;
    captureUpdate?: CaptureUpdateActionType;
    storeAction?: "capture" | "none" | "update";
};
export type ExcalidrawLinkOpenEvent = Parameters<NonNullable<ExcalidrawProps["onLinkOpen"]>>[1];
export type { StencilLibraryData } from "./stencilLibraryTypes";
export interface ExcalidrawEphemeralState {
    rename?: string;
    subpath?: string;
    line?: number;
    /** One-shot view/edit mode requested by an integration opening this drawing. */
    mode?: "view" | "edit";
    /** One-shot request to fit the scene after its first complete render. */
    zoomToFit?: boolean;
    match?: {
        content?: string;
        matches?: [number, number][];
    };
}
export type MarkdownViewOpenState = ViewStateResult | {
    focus: boolean;
} | ExcalidrawEphemeralState;
export type MarkdownBlockCacheEntry = {
    display: string;
    node: {
        type: string;
        id?: string;
        [key: string]: unknown;
    };
};
export interface ViewSemaphores {
    warnAboutLinearElementLinkClick: boolean;
    popoutUnload: boolean;
    windowMigrating: boolean;
    viewloaded: boolean;
    viewunload: boolean;
    scriptsReady: boolean;
    justLoaded: boolean;
    preventAutozoom: boolean;
    isEditingText: boolean;
    hoverSleep: boolean;
    wheelTimeout: number | null;
    shouldSaveImportedImage: boolean;
}
