import { FileId } from "@zsviczian/excalidraw/types/element/src/types";
import { BinaryFileData, DataURL } from "@zsviczian/excalidraw/types/excalidraw/types";
import { ValueOf } from "../types/types";
export declare const IMAGE_MIME_TYPES: {
    readonly svg: "image/svg+xml";
    readonly png: "image/png";
    readonly jpg: "image/jpeg";
    readonly jpeg: "image/jpeg";
    readonly gif: "image/gif";
    readonly webp: "image/webp";
    readonly bmp: "image/bmp";
    readonly ico: "image/x-icon";
    readonly avif: "image/avif";
    readonly jfif: "image/jfif";
};
export type ImgData = {
    mimeType: MimeType;
    fileId: FileId;
    dataURL: DataURL;
    created: number;
    loadedFromCache?: boolean;
    hasSVGwithBitmap: boolean;
    size: Size;
    pdfPageViewProps?: PDFPageViewProps;
    renderScale?: number;
};
export declare type MimeType = ValueOf<typeof IMAGE_MIME_TYPES> | "application/octet-stream";
export type FileData = BinaryFileData & {
    size: Size;
    loadedFromCache?: boolean;
    hasSVGwithBitmap: boolean;
    shouldScale: boolean;
    pdfPageViewProps?: PDFPageViewProps;
    renderScale?: number;
};
export type PDFPageViewProps = {
    left: number;
    bottom: number;
    right: number;
    top: number;
    rotate?: number;
};
export type Size = {
    height: number;
    width: number;
};
export interface ColorMap {
    [color: string]: string;
}
