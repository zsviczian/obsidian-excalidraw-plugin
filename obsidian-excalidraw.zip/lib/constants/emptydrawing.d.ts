import type { ExcalidrawElement } from "@zsviczian/excalidraw/types/element/src/types";
type JsonValue = string | number | boolean | null | {
    [key: string]: JsonValue;
} | JsonValue[];
type SerializedExcalidrawElement = {
    id: string;
    type: string;
    isDeleted: boolean;
    index: string;
    [key: string]: JsonValue;
};
export declare const emptyDrawingElements: SerializedExcalidrawElement[];
export declare const getEmptyDrawingElementsRuntime: () => ExcalidrawElement[];
export {};
