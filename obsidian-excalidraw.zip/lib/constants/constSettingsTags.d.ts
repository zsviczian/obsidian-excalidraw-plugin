export declare const TAG_PDFEXPORT = "PDFExport";
export declare const TAG_MDREADINGMODE = "MDReadingMode";
export declare const TAG_AUTOEXPORT = "Autoexport";
