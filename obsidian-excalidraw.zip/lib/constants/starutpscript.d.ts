export declare const startupScript: () => string;
