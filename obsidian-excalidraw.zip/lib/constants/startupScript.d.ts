/**
 * Returns the default startup script embedded from the authoritative Markdown
 * asset by the Rollup build.
 */
export declare const startupScript: () => string;
