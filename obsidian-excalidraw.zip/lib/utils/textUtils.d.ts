/**
 * Wraps text at an approximate character length while preserving line breaks.
 *
 * @param text - Text to wrap.
 * @param lineLen - Target line length. A falsy value disables wrapping.
 * @param forceWrap - Whether to split every input line into fixed-size chunks.
 * @param tolerance - Extra characters allowed for an unbroken word.
 * @returns The wrapped text without an additional trailing newline.
 */
export declare function wrapTextAtCharLength(text: string, lineLen: number, forceWrap?: boolean, tolerance?: number): string;
