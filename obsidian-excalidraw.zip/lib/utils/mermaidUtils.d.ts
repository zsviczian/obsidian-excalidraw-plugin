import { ExcalidrawElement, ExcalidrawImageElement } from "@zsviczian/excalidraw/types/element/src/types";
export declare function getMermaidImageElements(elements: ExcalidrawElement[]): ExcalidrawImageElement[];
export declare function getMermaidText(element: ExcalidrawElement): string;
export declare function shouldRenderMermaid(): boolean;
