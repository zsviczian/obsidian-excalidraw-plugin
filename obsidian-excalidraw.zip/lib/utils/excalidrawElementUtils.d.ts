import type { Mutable } from "@zsviczian/excalidraw/types/common/src/utility-types";
import type { ExcalidrawElement } from "@zsviczian/excalidraw/types/element/src/types";
import type { ElementsInAreaOptions, SceneArea } from "src/types/excalidrawAutomateTypes";
/**
 * Calculates the axis-aligned bounds shared by a collection of elements.
 *
 * @param elements - Elements whose bounds should be measured.
 * @returns The minimum and maximum coordinates as `[minX, minY, maxX, maxY]`.
 */
export declare function estimateBounds(elements: ExcalidrawElement[]): [number, number, number, number];
/**
 * Returns a normalized copy of a scene area, optionally inflated on every side.
 *
 * @param area - Scene rectangle to normalize.
 * @param margin - Scene-unit margin added around the rectangle.
 */
export declare function normalizeSceneArea(area: SceneArea, margin?: number): SceneArea;
/**
 * Returns elements whose axis-aligned rendered bounds intersect a scene area.
 *
 * @remarks
 * Results preserve the source array's stacking order. Marker frames are
 * excluded by default to preserve the historical ExcalidrawAutomate behavior.
 */
export declare function getElementsIntersectionArea(elements: readonly ExcalidrawElement[], area: SceneArea, options?: ElementsInAreaOptions): ExcalidrawElement[];
/**
 * Backward-compatible name for {@link getElementsIntersectionArea}.
 */
export declare function getElementsInArea(elements: readonly ExcalidrawElement[], area: SceneArea, options?: ElementsInAreaOptions): ExcalidrawElement[];
/**
 * Creates an invisible rectangle that pins an export to an exact scene area.
 *
 * @remarks The returned element is detached data and never enters the EA workbench.
 */
export declare function createExportAreaAnchor(area: SceneArea): ExcalidrawElement;
/**
 * Moves elements so their top-left corner or center is at a scene position.
 *
 * @param elements - Elements to reposition. Their coordinates are mutated.
 * @param newPosition - Target scene position.
 * @param center - Whether to align the combined center instead of the top-left.
 * @returns Restored elements with dimensions refreshed and bindings repaired.
 */
export declare function repositionElementsToCursor(elements: ExcalidrawElement[], newPosition: {
    x: number;
    y: number;
}, center?: boolean): ExcalidrawElement[];
/**
 * Deep-clones an element while advancing its Excalidraw version metadata.
 *
 * @param element - Element to clone.
 * @returns A mutable clone with the same ID and refreshed version metadata.
 * @remarks This internal helper does not assign a new element ID.
 */
export declare function cloneElement(element: ExcalidrawElement): Mutable<ExcalidrawElement>;
/**
 * Gets the ID of the first text element bound to a container.
 *
 * @param container - Container element, or `null` when none is available.
 * @returns The bound text element ID, or `null` when no text is bound.
 */
export declare function getBoundTextElementId(container: ExcalidrawElement | null): string | null;
