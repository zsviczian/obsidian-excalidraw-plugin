export declare const durationTreshold = 0;
export declare const DEBUGGING = false;
export declare const log: (...args: unknown[]) => void;
export declare const debug: (fn: (...args: unknown[]) => unknown, fnName: string, ...messages: unknown[]) => void;
export declare function tsInit(msg: string): void;
export declare function ts(msg: string, level: number): void;
export declare class CustomMutationObserver {
    private originalCallback;
    private observer;
    private name;
    constructor(callback: MutationCallback, name: string);
    observe(target: Node, options: MutationObserverInit): void;
    disconnect(): void;
}
