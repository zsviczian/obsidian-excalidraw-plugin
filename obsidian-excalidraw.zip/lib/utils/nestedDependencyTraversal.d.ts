export interface DependencyGraphNode<T> {
    value: T;
    childKeys: readonly string[];
}
export interface DependencyGraph<T> {
    nodes: ReadonlyMap<string, DependencyGraphNode<T>>;
}
/**
 * Returns each dependency reachable from rootKey once, excluding the root.
 */
export declare function collectReachableDependencyValues<T>(graph: DependencyGraph<T>, rootKey: string): T[];
/**
 * Tests each reachable dependency at most once and stops at the first match.
 */
export declare function hasReachableDependency<T>(graph: DependencyGraph<T>, rootKey: string, predicate: (value: T) => boolean): boolean;
/**
 * Returns the root's requested direct dependencies that contain a matching
 * file anywhere in their reachable subgraph. Cycles and shared descendants
 * are visited once per top-level dependency; distinct dependency paths are
 * deliberately never materialized.
 */
export declare function getMatchingTopLevelDependencyKeys<T>(graph: DependencyGraph<T>, rootKey: string, requestedTopLevelKeys: ReadonlySet<string>, predicate: (value: T) => boolean): Set<string>;
