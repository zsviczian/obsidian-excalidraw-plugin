import { App, TFile } from "obsidian";
import { ExcalidrawAutomate } from "src/shared/ExcalidrawAutomate";
import type ExcalidrawView from "src/view/ExcalidrawView";
import { ExcalidrawElement, ExcalidrawFrameElement, ExcalidrawImageElement, FileId } from "@zsviczian/excalidraw/types/element/src/types";
import { AppState } from "@zsviczian/excalidraw/types/excalidraw/types";
import { EmbeddableMDCustomProps } from "src/shared/Dialogs/EmbeddableSettings";
import { EmbeddedFile } from "src/shared/EmbeddedFileLoader";
/**
 * Returns the set of top-level embedded-file IDs that need to be rebuilt on
 * leaf switch because either the file itself or any nested visual dependency
 * was modified since the view last completed a scene load.
 */
export declare function getChangedTopLevelDependencyFileIDs(view: ExcalidrawView): Set<FileId>;
export declare function insertImageToView(ea: ExcalidrawAutomate, position: {
    x: number;
    y: number;
}, file: TFile | string, scale?: boolean, shouldInsertToView?: boolean, repositionToCursor?: boolean): Promise<string>;
export declare function deleteAppStateKeys(st: AppState, [...keys]: (keyof AppState)[]): Partial<AppState>;
export declare function insertEmbeddableToView(ea: ExcalidrawAutomate, position: {
    x: number;
    y: number;
}, file?: TFile, link?: string, shouldInsertToView?: boolean): Promise<string>;
export declare function addTextWithOEmbed(view: ExcalidrawView, text: string): Promise<void>;
export declare function getLinkTextFromLink(text: string): string;
export declare function openTagSearch(link: string, app: App, view?: ExcalidrawView): void;
export declare function sceneRemoveInternalLinks<T extends ExcalidrawElement>(scene: {
    elements: readonly T[];
}): T[];
export declare function openExternalLink(link: string, app: App): boolean;
/**
 *
 * @param link
 * @param app
 * @param returnWikiLink
 * @param openLink: if set to false, the link will not be opened just true will be returned for an obsidian link.
 * @returns
 *   false if the link is not an obsidian link,
 *   true if the link is an obsidian link and it was opened (i.e. it is a link to another Vault or not a file link e.g. plugin link), or
 *   the link to the file path. By default as a wiki link, or as a file path if returnWikiLink is false.
 */
export declare function parseObsidianLink(link: string, app: App, returnWikiLink?: boolean, openLink?: boolean): boolean | string;
export declare function getExcalidrawFileForwardLinks(app: App, excalidrawFile: TFile, secondOrderLinksSet: Set<string>): string;
export declare function getFrameBasedOnFrameNameOrId(frameName: string, elements: readonly ExcalidrawElement[]): ExcalidrawFrameElement | null;
export declare function addBackOfTheNoteCard(view: ExcalidrawView, title: string, activate?: boolean, cardBody?: string, embeddableCustomData?: EmbeddableMDCustomProps, center?: boolean, position?: {
    x: number;
    y: number;
}): Promise<string>;
/** Inserts a complete level-one section immediately before Excalidraw Data. */
export declare function insertBackOfTheNoteContent(view: ExcalidrawView, sectionMarkdown: string): void;
export declare function renderContextMenuAction(React: Pick<typeof import("react"), "createElement">, label: string, action: () => void, onClose: (callback?: () => void) => void, actionId?: string, checked?: boolean): import("react").DetailedReactHTMLElement<{
    key: string;
    onClick: () => void;
    "data-testid": string;
}, HTMLElement>;
export declare function tmpBruteForceCleanup(view: ExcalidrawView): void;
/**
 * Check if the text matches the transclusion pattern and if so,
 * check if the link in the transclusion can be resolved to a file in the vault.
 * if yes, call the callback function with the link and the file.
 * @param text
 * @param callback
 * @returns true if text is a transclusion and the link can be resolved to a file in the vault, false otherwise.
 */
export declare function isTextImageTransclusion(text: string, view: ExcalidrawView, callback: (link: string, file: TFile) => void): boolean;
export declare function displayFontMessage(app: App): void;
export declare function toggleImageAnchoring(el: ExcalidrawImageElement, view: ExcalidrawView, shouldAnchor: boolean, ef: EmbeddedFile): Promise<void>;
export declare function onLoadMessages(scene: {
    elements: ExcalidrawElement[];
    appState: AppState;
}): void;
export declare function getViewColorPalette(palette: "canvasBackground" | "elementBackground" | "elementStroke", view?: ExcalidrawView, includeSceneColors?: boolean): (string[] | string)[];
export declare const setMobileNavbarPosition: (dock: boolean) => void;
