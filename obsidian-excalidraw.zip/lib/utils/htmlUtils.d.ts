export declare const sanitizedFragment: (html: string) => DocumentFragment;
export declare const setSanitizedHtml: (el: HTMLElement, html: string) => void;
export declare const setStyleText: (styleEl: HTMLStyleElement, cssText: string) => void;
export declare const setElementHidden: (el: HTMLElement, hidden: boolean) => void;
export declare const setElementDisplay: (el: HTMLElement, display: "none" | "flex" | "") => void;
export declare const setElementIconAndText: (el: HTMLElement, iconId: string, text: string) => void;
export declare const makeEntitiesXmlSafe: (svgString: string) => string;
