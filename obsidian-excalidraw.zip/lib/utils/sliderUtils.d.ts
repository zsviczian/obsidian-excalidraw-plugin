import { Setting } from "obsidian";
export type SliderSetting = {
    name: string | DocumentFragment;
    desc?: string | DocumentFragment;
    min: number;
    max: number;
    step: number;
    value: number;
    minWidth?: string;
    onChange: (value: number) => void | Promise<void>;
};
export declare const createSliderWithText: (container: HTMLElement, settings: SliderSetting) => void;
/**
 * Configures an existing setting row with the plugin's slider-plus-value UI.
 * This supports declarative `render` callbacks, where Obsidian owns creation
 * of the row but the plugin must preserve its established slider layout.
 */
export declare const configureSliderWithText: (setting: Setting, settings: SliderSetting) => void;
