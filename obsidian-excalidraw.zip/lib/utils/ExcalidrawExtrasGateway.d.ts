import { App } from "obsidian";
import type ExcalidrawPlugin from "../core/main";
import type { ExcalidrawExtrasAPI, ExtrasComponent } from "@zsviczian/excalidraw-extras-api";
export type VersionCheckResult = {
    valid: boolean;
    isExact?: boolean;
    compName?: string;
    reqVersion?: string;
    currentVersion?: string;
};
export declare class ExcalidrawExtrasGateway {
    app: App;
    plugin: ExcalidrawPlugin;
    private ignoredComponents;
    private activationTask;
    constructor(app: App, plugin: ExcalidrawPlugin);
    getMathJax(): Promise<ExcalidrawExtrasAPI["mathjax"] | null>;
    getExportToPDF(): Promise<ExcalidrawExtrasAPI["pdf"] | null>;
    getMermaid(): Promise<ExcalidrawExtrasAPI["mermaid"] | null>;
    getFileSystem(): Promise<ExcalidrawExtrasAPI["filesystem"] | null>;
    private ensureActiveAndGetAPI;
    private handleActivation;
    isInstalled(): boolean;
    isPluginEnabled(): boolean;
    getAPI(): ExcalidrawExtrasAPI | null;
    checkVersion(component: string, api: ExcalidrawExtrasAPI): VersionCheckResult;
    enableFeature(component: ExtrasComponent, api: ExcalidrawExtrasAPI, minutes?: number): Promise<void>;
    private compareVersions;
}
