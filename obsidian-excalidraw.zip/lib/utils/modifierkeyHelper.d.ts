import type React from "react";
import { Modifier } from "obsidian";
import { PaneTarget } from "src/types/utilTypes";
export { labelALT, labelCTRL, labelMETA, labelSHIFT, } from "src/utils/modifierKeyLabels";
export type ModifierKeys = {
    shiftKey: boolean;
    ctrlKey: boolean;
    metaKey: boolean;
    altKey: boolean;
};
export type KeyEvent = PointerEvent | MouseEvent | KeyboardEvent | React.DragEvent | React.PointerEvent | React.MouseEvent | ModifierKeys;
export type WebBrowserDragAction = "link" | "image-url" | "image-import" | "embeddable";
export type LocalFileDragAction = "link" | "image-url" | "image-import" | "embeddable";
export type InternalDragAction = "link" | "image" | "image-fullsize" | "embeddable";
export type ModifierSetType = "WebBrowserDragAction" | "LocalFileDragAction" | "InternalDragAction" | "LinkClickAction";
type ModifierKey = {
    shift: boolean;
    ctrl_cmd: boolean;
    alt_opt: boolean;
    meta_ctrl: boolean;
    result: WebBrowserDragAction | LocalFileDragAction | InternalDragAction | PaneTarget;
};
export type ModifierKeySet = {
    defaultAction: WebBrowserDragAction | LocalFileDragAction | InternalDragAction | PaneTarget;
    rules: ModifierKey[];
};
export type ModifierKeyTooltipMessages = Partial<{
    [modifierSetType in ModifierSetType]: Partial<{
        [action in WebBrowserDragAction | LocalFileDragAction | InternalDragAction | PaneTarget]: string;
    }>;
}>;
export declare const modifierKeyTooltipMessages: () => ModifierKeyTooltipMessages;
export declare const isWinCTRLorMacCMD: (e: KeyEvent) => boolean;
export declare const isWinALTorMacOPT: (e: KeyEvent) => boolean;
export declare const isWinMETAorMacCTRL: (e: KeyEvent) => boolean;
export declare const isSHIFT: (e: KeyEvent) => boolean;
export declare const setCTRL: (e: ModifierKeys, value: boolean) => ModifierKeys;
export declare const setALT: (e: ModifierKeys, value: boolean) => ModifierKeys;
export declare const setMETA: (e: ModifierKeys, value: boolean) => ModifierKeys;
export declare const setSHIFT: (e: ModifierKeys, value: boolean) => ModifierKeys;
export declare const mdPropModifier: (ev: KeyEvent) => boolean;
export declare const scaleToFullsizeModifier: (ev: KeyEvent) => boolean;
export declare const linkClickModifierType: (ev: KeyEvent) => PaneTarget;
export declare const webbrowserDragModifierType: (ev: KeyEvent) => WebBrowserDragAction;
export declare const localFileDragModifierType: (ev: KeyEvent) => LocalFileDragAction;
export declare const internalDragModifierType: (ev: KeyEvent) => InternalDragAction;
export declare const emulateCTRLClickForLinks: (e: KeyEvent) => {
    shiftKey: boolean;
    ctrlKey: boolean;
    metaKey: boolean;
    altKey: boolean;
};
export declare const emulateKeysForLinkClick: (action: PaneTarget) => ModifierKeys;
export declare const anyModifierKeysPressed: (e: ModifierKeys) => boolean;
export declare function modifierLabel(modifiers: Modifier[], platform?: "Mac" | "Other"): string;
