/**
 * Reports whether one semantic-style version is newer than another.
 *
 * @param version - Candidate version containing a `major.minor.patch` sequence.
 * @param otherVersion - Version to compare against.
 * @returns `true` when `version` is newer.
 * @remarks
 * Missing versions intentionally return `true` for backward compatibility.
 * Only the first three numeric components are compared; any surrounding
 * prerelease or build text is ignored.
 */
export declare function isVersionNewerThanOther(version: string, otherVersion: string): boolean;
