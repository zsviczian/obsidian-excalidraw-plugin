import ExcalidrawPlugin from "src/core/main";
import type ExcalidrawView from "src/view/ExcalidrawView";
export declare function getLastActiveExcalidrawView(plugin: ExcalidrawPlugin): ExcalidrawView | null;
