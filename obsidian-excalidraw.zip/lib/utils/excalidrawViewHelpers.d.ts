import type ExcalidrawView from "src/view/ExcalidrawView";
export { cloneElement, getBoundTextElementId, repositionElementsToCursor, } from "./excalidrawElementUtils";
export declare const insertLaTeXToView: (view: ExcalidrawView, center?: boolean) => void;
export declare const search: (view: ExcalidrawView) => Promise<void>;
