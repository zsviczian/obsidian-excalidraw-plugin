import { type TFile } from "obsidian";
export type ScriptFileExtension = "md" | "js";
/** Returns whether a path names a supported Excalidraw Automate script file. */
export declare const isScriptFilePath: (path: string) => boolean;
/** Returns a script path with its final `.md` or `.js` suffix replaced. */
export declare const replaceScriptFileExtension: (path: string, extension: ScriptFileExtension) => string;
/** Returns the filename stem shared by equivalent `.md` and `.js` scripts. */
export declare const getScriptFileStem: (filename: string) => string;
/**
 * Collapses equivalent `.md` and `.js` paths to one script, preferring the
 * Markdown file when both exist.
 */
export declare const getPreferredScriptFiles: (files: Iterable<TFile>) => TFile[];
/**
 * Returns the extension used for locally managed scripts. JavaScript storage
 * is effective only when JavaScript script loading is also enabled.
 */
export declare const getManagedScriptFileExtension: (allowJavaScriptFiles: boolean, storeScriptFilesAsJavaScript: boolean) => ScriptFileExtension;
/** Resolves a configured startup path while preserving the `.md` default. */
export declare const resolveConfiguredStartupScriptPath: (configuredPath: string) => string | null;
