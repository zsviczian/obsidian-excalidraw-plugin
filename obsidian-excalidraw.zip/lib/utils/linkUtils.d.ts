import type { TFile } from "obsidian";
/** Parsed components of an Obsidian drawing or embedded-file link. */
export type LinkParts = {
    original: string;
    path: string;
    isBlockRef: boolean;
    ref: string;
    width: number;
    height: number;
    page: number;
};
/**
 * Splits a drawing or embedded-file link into its path, reference, dimensions,
 * and optional PDF page.
 *
 * @param filename - Link text to parse.
 * @param file - Current file, used when the link omits its path.
 * @returns Parsed link components with cleaned heading or block references.
 * @remarks
 * This preserves the existing permissive regular-expression parser. It is not
 * a general-purpose Obsidian link parser and intentionally retains its current
 * handling of malformed or partially specified links.
 */
export declare function getLinkParts(filename: string, file?: TFile): LinkParts;
