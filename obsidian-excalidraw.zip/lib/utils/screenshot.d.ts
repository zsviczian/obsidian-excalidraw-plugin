import ExcalidrawView from "src/view/ExcalidrawView";
export interface ScreenshotOptions {
    zoom: number;
    margin: number;
    selectedOnly: boolean;
    theme: string;
}
export declare function captureScreenshot(view: ExcalidrawView, options: ScreenshotOptions): Promise<Blob | null>;
