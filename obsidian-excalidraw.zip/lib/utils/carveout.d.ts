import { ExcalidrawEmbeddableElement, ExcalidrawImageElement } from "@zsviczian/excalidraw/types/element/src/types";
import { ExcalidrawAutomate } from "src/shared/ExcalidrawAutomate";
import { TFile } from "obsidian";
export declare const CROPPED_PREFIX = "cropped_";
export declare const ANNOTATED_PREFIX = "annotated_";
export declare const carveOutImage: (sourceEA: ExcalidrawAutomate, viewImageEl: ExcalidrawImageElement) => Promise<void>;
export declare const carveOutPDF: (sourceEA: ExcalidrawAutomate, embeddableEl: ExcalidrawEmbeddableElement, pdfPathWithPage: string, pdfFile: TFile) => Promise<void>;
export declare const createImageCropperFile: (targetEA: ExcalidrawAutomate, imageID: string, imageLink: string, foldername: string, filename: string) => Promise<TFile>;
