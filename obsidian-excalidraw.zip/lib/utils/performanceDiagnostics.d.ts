/**
 * Temporary Phase 0 performance diagnostics.
 *
 * Enable before loading the plugin with:
 * localStorage.setItem("excalidraw-performance-diagnostics", "1")
 *
 * Every emitted record is deliberately one flat, copyable string. The module
 * does not log vault contents or file paths and does not change product state.
 * Remove this module and every EXCALIDRAW_PERF_PHASE0 call before committing.
 */
export declare const PERFORMANCE_DIAGNOSTICS_PREFIX = "EXCALIDRAW_PERF_PHASE0";
export declare const PERFORMANCE_DIAGNOSTICS_STORAGE_KEY = "excalidraw-performance-diagnostics";
type DiagnosticValue = string | number | boolean | null | undefined;
type DiagnosticFields = Record<string, DiagnosticValue>;
export declare function performanceDiagnosticsEnabled(): boolean;
export declare function performanceDiagnosticNow(): number;
export declare function nextPerformanceDiagnosticId(prefix: string): string;
export declare function performanceDiagnosticLog(event: string, fields?: DiagnosticFields): void;
export declare function performanceDiagnosticRecordDuration(metric: string, durationMs: number): void;
export declare function performanceDiagnosticIncrement(counter: string, amount?: number): void;
export declare function performanceDiagnosticSummary(reason: string, fields?: DiagnosticFields): void;
export {};
