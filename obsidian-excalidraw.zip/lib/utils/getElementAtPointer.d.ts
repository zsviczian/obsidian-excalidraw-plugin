import { ExcalidrawElement } from "@zsviczian/excalidraw/types/element/src/types";
import type ExcalidrawView from "src/view/ExcalidrawView";
type PointerPoint = {
    x: number;
    y: number;
};
export declare const getElementsAtPointer: (pointer: PointerPoint, elements: readonly ExcalidrawElement[], type?: string) => ExcalidrawElement[];
export declare const getTextElementAtPointer: (pointer: PointerPoint, view: ExcalidrawView) => {
    id: string;
    text: string;
};
export declare const getImageElementAtPointer: (pointer: PointerPoint, view: ExcalidrawView) => {
    id: string;
    fileId: import("@zsviczian/excalidraw/types/element/src/types").FileId;
};
export declare const getElementWithLinkAtPointer: (pointer: PointerPoint, view: ExcalidrawView) => {
    id: string;
    text: string;
};
export {};
