import { ExcalidrawEmbeddableElement } from "@zsviczian/excalidraw/types/element/src/types";
import { App, TFile, WorkspaceLeaf, WorkspaceSplit } from "obsidian";
import ExcalidrawView from "src/view/ExcalidrawView";
/**
 * Creates a detached workspace leaf for an embedded view.
 *
 * @param view - Excalidraw view that owns the embedded content.
 * @param doc - Document hosting the embedded UI, which may be a popout window.
 */
export declare const createLeaf: (view: ExcalidrawView, doc?: Document) => {
    leaf: WorkspaceLeaf;
    rootSplit: WorkspaceSplit;
};
export declare const useDefaultExcalidrawFrame: (element: ExcalidrawEmbeddableElement) => boolean;
export declare const leafMap: Map<string, WorkspaceLeaf>;
export declare const patchMobileView: (view: ExcalidrawView, opts?: {
    keepAlive?: boolean;
    isActive?: () => boolean;
}) => (() => void) | void;
export declare const processLinkText: (linkText: string, view: ExcalidrawView) => {
    subpath: string;
    file: TFile;
};
export declare function setFileToLocalGraph(app: App, file: TFile): void;
export declare function predictViewType(app: App, file: TFile): string;
