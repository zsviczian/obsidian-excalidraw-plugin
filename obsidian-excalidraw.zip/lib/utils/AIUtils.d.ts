import { RequestUrlResponse } from "obsidian";
import ExcalidrawPlugin from "src/core/main";
import { AIUsageData, ExcalidrawAISettings, AIRequest, AIRequestMessage, AIRequestMessagePart } from "src/types/AIUtilTypes";
type GenerateAITextOptions = {
    plugin?: ExcalidrawPlugin;
    signal?: AbortSignal;
};
type GenerateAITextResult = {
    response: RequestUrlResponse;
    json: Record<string, unknown>;
    content: string;
    rateLimit: number | null;
    rateLimitRemaining: number | null;
};
export type AIGeneratedImage = {
    url?: string;
    b64_json?: string;
    dataURL?: string;
    mimeType?: string;
    revisedPrompt?: string;
};
export type GenerateAIImageResult = {
    response: RequestUrlResponse;
    json: Record<string, unknown>;
    images: AIGeneratedImage[];
    firstImage: AIGeneratedImage | null;
    revisedPrompt: string;
};
export type AIChatSession = {
    getMessages: () => AIRequestMessage[];
    reset: () => void;
    send: (message: string | AIRequestMessage | AIRequestMessagePart[], requestOverrides?: Omit<AIRequest, "messages">) => Promise<GenerateAITextResult>;
};
/**
 * Returns accumulated AI token usage for the current Obsidian session.
 * Usage is not persisted and resets when Obsidian is restarted.
 */
export declare const getAIUsage: () => AIUsageData;
/**
 * Resets the session-scoped AI usage meter. Primarily for testing and tooling.
 */
export declare const resetAIUsage: () => void;
/**
 * Formats total session token usage as a compact label suitable for buttons.
 * Format: "AI Usage: 355k/23k" (input tokens / output tokens).
 * Image generations are appended when present, e.g. "+ 3 imgs".
 */
export declare const formatAIUsageLabel: (usage?: AIUsageData) => string;
export declare const getJsonErrorMessage: (json: unknown) => string | undefined;
export declare const postAI: (request: AIRequest, options?: GenerateAITextOptions) => Promise<RequestUrlResponse>;
export declare const postOpenAI: (request: AIRequest, options?: GenerateAITextOptions) => Promise<RequestUrlResponse>;
export declare const generateAIText: (request: AIRequest, options?: GenerateAITextOptions) => Promise<GenerateAITextResult>;
export declare const getAISettings: (plugin?: ExcalidrawPlugin) => ExcalidrawAISettings | null;
export declare const analyzeAIImage: (request: AIRequest, options?: GenerateAITextOptions) => Promise<GenerateAITextResult>;
export declare const generateAIImage: (request: AIRequest, options?: GenerateAITextOptions) => Promise<GenerateAIImageResult>;
export declare const transformAIImage: (request: AIRequest, options?: GenerateAITextOptions) => Promise<GenerateAIImageResult>;
export declare const maskEditAIImage: (request: AIRequest, options?: GenerateAITextOptions) => Promise<GenerateAIImageResult>;
export declare const createAIChatSession: (initialRequest?: Omit<AIRequest, "messages">, options?: GenerateAITextOptions) => AIChatSession;
/**
 * Grabs the codeblock contents from the supplied markdown string.
 * @param markdown
 * @param codeblockType
 * @returns an array of dictionaries with the codeblock contents and type
 */
export declare const extractCodeBlocks: (markdown: string) => {
    data: string;
    type: string;
}[];
export declare const errorHTML: (message: string) => string;
export {};
