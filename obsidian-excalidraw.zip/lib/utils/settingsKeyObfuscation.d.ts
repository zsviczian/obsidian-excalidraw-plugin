import { AIProviderProfile } from "src/types/AIUtilTypes";
export declare const isObfuscatedAPIKey: (value: unknown) => value is string;
export declare const encryptStoredAPIKey: (value: string) => string;
export declare const decryptStoredAPIKey: (value: string) => string;
export declare const decryptProviderProfiles: (profiles: Record<string, AIProviderProfile>) => Record<string, AIProviderProfile>;
export declare const encryptProviderProfiles: (profiles: Record<string, AIProviderProfile>) => Record<string, AIProviderProfile>;
type PersistedSettingsWithAPIKeys = {
    aiProviderProfiles?: Record<string, AIProviderProfile>;
    taskboneAPIkey?: string;
};
export declare const decryptPersistedAPIKeys: <T extends PersistedSettingsWithAPIKeys>(settings: T) => T;
export declare const encryptPersistedAPIKeys: <T extends PersistedSettingsWithAPIKeys>(settings: T) => T;
export {};
