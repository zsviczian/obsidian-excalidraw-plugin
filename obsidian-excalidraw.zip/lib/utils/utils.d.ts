import { App, TFile } from "obsidian";
import { AppState, BinaryFileData, BinaryFiles, NormalizedZoomValue } from "@zsviczian/excalidraw/types/excalidraw/types";
import type ExcalidrawPlugin from "../core/main";
import { ExcalidrawElement } from "@zsviczian/excalidraw/types/element/src/types";
import { Mutable } from "@zsviczian/excalidraw/types/common/src/utility-types";
import { arrayToMap } from "./collectionUtils";
import { isVersionNewerThanOther } from "./versionUtils";
import type { ExcalidrawSettings } from "src/core/settingsDefaults";
import { FileData } from "src/types/embeddedFileLoaderTypes";
import { ExportSettings } from "src/types/exportUtilTypes";
import { UIMode } from "src/shared/Dialogs/UIModeSettingComponent";
export { arrayToMap };
export { errorlog, getDataURL } from "./coreUtils";
export { addAppendUpdateCustomData } from "./elementCustomDataUtils";
export { getBinaryFileFromDataURL } from "./fileUtils";
export { cropCanvas } from "./embeddedAssetUtils";
export { getFontDataURL } from "./embeddedAssetUtils";
export { getImageSize } from "./embeddedAssetUtils";
export { promiseTry } from "./embeddedAssetUtils";
export { getLinkParts } from "./linkUtils";
export type { LinkParts } from "./linkUtils";
export { svgToBase64 } from "./embeddedAssetUtils";
export { wrapTextAtCharLength } from "./textUtils";
export { isVersionNewerThanOther };
export { getEmbeddedFilenameParts, isImagePartRef, } from "./embeddedFilenameParts";
type SceneForExport = {
    elements: readonly ExcalidrawElement[];
    appState: Partial<AppState>;
    files?: BinaryFiles;
};
type SceneWithElements = Pick<SceneForExport, "elements">;
export declare function checkVersionMismatch(plugin: ExcalidrawPlugin): Promise<void>;
export declare let versionUpdateCheckTimer: number;
export declare function checkExcalidrawVersion(): Promise<void>;
export declare function randomInteger(): number;
export declare function rotatedDimensions(element: ExcalidrawElement): [number, number, number, number];
export declare function base64StringToBlob(base64String: string, mimeType: string): Blob;
/**
 * Exports an Excalidraw scene to SVG.
 *
 * @param allowFramePadding - Whether clipped frame rendering should honor `padding`.
 * Defaults to `false` to preserve the legacy zero-padding behavior for clipped frames.
 */
export declare function getSVG<TScene extends SceneForExport>(scene: TScene, exportSettings: ExportSettings, padding: number, srcFile: TFile | null, //if set, will replace markdown links with obsidian links
overrideFiles?: Record<ExcalidrawElement["id"], BinaryFileData>, allowFramePadding?: boolean): Promise<SVGSVGElement>;
export declare function filterFiles(files: Record<ExcalidrawElement["id"], BinaryFileData>): Record<ExcalidrawElement["id"], BinaryFileData>;
/**
 * Exports an Excalidraw scene to PNG.
 *
 * @param allowFramePadding - Whether clipped frame rendering should honor `padding`.
 * Defaults to `false` to preserve the legacy zero-padding behavior for clipped frames.
 */
export declare function getPNG<TScene extends SceneForExport>(scene: TScene, exportSettings: ExportSettings, padding: number, scale?: number, overrideFiles?: BinaryFiles, allowFramePadding?: boolean): Promise<Blob>;
export declare function getQuickImagePreview(plugin: ExcalidrawPlugin, path: string, extension: "png"): Promise<Blob | null>;
export declare function getQuickImagePreview(plugin: ExcalidrawPlugin, path: string, extension: "svg"): Promise<string | null>;
export declare function scaleLoadedImage<T extends SceneWithElements>(scene: T, files: FileData[]): {
    dirty: boolean;
    scene: Omit<T, "elements"> & {
        elements: Mutable<ExcalidrawElement>[];
    };
};
export declare function setLeftHandedMode(isLeftHanded: boolean): void;
export declare function calculateUIModeValue(settings: ExcalidrawSettings): UIMode;
export declare function setUIMode(app: App, settings: ExcalidrawSettings): void;
export declare function isMaskFile(plugin: ExcalidrawPlugin, file: TFile | null): boolean;
export declare function hasExportTheme(plugin: ExcalidrawPlugin, file: TFile | null): boolean;
export declare function getExportTheme(plugin: ExcalidrawPlugin, file: TFile | null, theme: string): string;
export declare function shouldEmbedScene(plugin: ExcalidrawPlugin, file: TFile | null): boolean;
export declare function hasExportBackground(plugin: ExcalidrawPlugin, file: TFile | null): boolean;
export declare function getWithBackground(plugin: ExcalidrawPlugin, file: TFile | null): boolean;
export declare function getExportInternalLinks(plugin: ExcalidrawPlugin, file: TFile | null): boolean;
export declare function getExportPadding(plugin: ExcalidrawPlugin, file: TFile | null): number;
export declare function getPNGScale(plugin: ExcalidrawPlugin, file: TFile | null): NormalizedZoomValue;
export declare function fragWithHTML(html: string): DocumentFragment;
/**REACT 18
  //see also: https://github.com/zsviczian/obsidian-excalidraw-plugin/commit/b67d70c5196f30e2968f9da919d106ee66f2a5eb
  //https://github.com/zsviczian/obsidian-excalidraw-plugin/commit/cc9d7828c7ee7755c1ef942519c43df32eae249f
export const awaitNextAnimationFrame = async () => new Promise(requestAnimationFrame);
*/
export declare function _getContainerElement(element: (ExcalidrawElement & {
    containerId: ExcalidrawElement["id"] | null;
}) | null, scene: SceneWithElements | null): import("@zsviczian/excalidraw/types/element/src/types").ExcalidrawTextContainer;
export declare function isContainer(el: ExcalidrawElement): boolean;
export declare function hyperlinkIsImage(data: string): boolean;
export declare function getFilePathFromObsidianURL(data: string): string;
export declare function obsidianURLIsImage(data: string): boolean;
export declare function hyperlinkIsYouTubeLink(link: string): boolean;
export declare function getYouTubeThumbnailLink(youtubelink: string): Promise<string>;
export declare function convertSVGStringToElement(svg: string): SVGSVGElement;
export declare function escapeRegExp(str: string): string;
export declare function addYouTubeThumbnail(containerEl: HTMLElement, link: string, startAt?: number, style?: string): void;
export declare class PromisePool<T> {
    private readonly pool;
    private readonly entries;
    constructor(source: IterableIterator<Promise<void | readonly [number, T]>>, concurrency: number);
    all(): Promise<T[]>;
}
