import type { Theme } from "@zsviczian/excalidraw/types/element/src/types";
import type { DataURL } from "@zsviczian/excalidraw/types/excalidraw/types";
export type MagicCacheData = {
    status: "pending";
} | {
    status: "done";
    html: string;
} | {
    status: "error";
    message?: string;
    code: "ERR_GENERATION_INTERRUPTED";
};
export declare function diagramToHTML({ image, text, theme, }: {
    image: DataURL;
    text: string;
    theme?: Theme;
}): Promise<{
    ok: boolean;
    error: string;
    json: Record<string, unknown>;
    html?: undefined;
} | {
    ok: boolean;
    html: string;
    json: Record<string, unknown>;
    error?: undefined;
}>;
