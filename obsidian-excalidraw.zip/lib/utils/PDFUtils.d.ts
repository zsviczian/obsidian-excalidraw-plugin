import { ImageCrop } from "@zsviczian/excalidraw/types/element/src/types";
import { PDFPageViewProps } from "src/types/embeddedFileLoaderTypes";
import type { ExcalidrawPDFCustomData } from "./elementCustomDataUtils";
export declare function getPDFCropRect(props: {
    scale: number;
    link: string;
    naturalHeight: number;
    naturalWidth: number;
    pdfPageViewProps: PDFPageViewProps;
}): ImageCrop | null;
export declare function getPDFRect({ elCrop, scale, customData, }: {
    elCrop: ImageCrop;
    scale: number;
    customData: ExcalidrawPDFCustomData;
}): string;
