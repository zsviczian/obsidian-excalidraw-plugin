export interface RasterCropRegion {
    x: number;
    y: number;
    width: number;
    height: number;
}
/** Crops a PNG blob without converting it through a base64 data URL. */
export declare function cropPNGBlob(blob: Blob, crop: RasterCropRegion): Promise<Blob>;
