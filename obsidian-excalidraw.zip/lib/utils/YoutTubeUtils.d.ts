export declare const isVimeo: (url: string) => boolean;
export declare const isYouTube: (url: string) => boolean;
export declare const getAspectRatio: (url: string) => {
    w: number;
    h: number;
};
export declare const getYouTubeStartAt: (url: string) => string;
export declare const isValidYouTubeStart: (value: string) => boolean;
export declare const updateYouTubeStartTime: (link: string, startTime: string) => string;
