import { ExcalidrawElement } from "@zsviczian/excalidraw/types/element/src/types";
import { Mutable } from "@zsviczian/excalidraw/types/common/src/utility-types";
export declare function updateElementIdsInScene({ elements: sceneElements }: {
    elements: Mutable<ExcalidrawElement>[];
}, elementToChange: Mutable<ExcalidrawElement>, newID: string): void;
