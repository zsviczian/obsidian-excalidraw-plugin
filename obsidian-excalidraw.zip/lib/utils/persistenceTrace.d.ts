interface TraceElement {
    id: string;
    type: string;
    version: number;
    versionNonce: number;
    index?: string | null;
    isDeleted?: boolean;
}
/** Emits one complete, copyable string for the temporary persistence trace. */
export declare const persistenceTrace: (subject: object, event: string, details?: string) => void;
/** Produces a synchronous diagnostic identity without retaining source text. */
export declare const persistenceTraceTextFingerprint: (text: string) => string;
/** Summarizes ordered element identity/version state without logging content. */
export declare const persistenceTraceSceneSummary: (elements: readonly TraceElement[]) => string;
/** Summarizes the first few changed element identities for edit correlation. */
export declare const persistenceTraceElementChanges: (elements: readonly TraceElement[]) => string;
export {};
