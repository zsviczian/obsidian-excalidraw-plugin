import { DataURL } from "@zsviczian/excalidraw/types/excalidraw/types";
import { App, TFile, TFolder, Vault } from "obsidian";
import type { ExcalidrawSettings } from "src/core/settingsDefaults";
import type ExcalidrawPlugin from "src/core/main";
import type ExcalidrawView from "src/view/ExcalidrawView";
import { MimeType } from "src/types/embeddedFileLoaderTypes";
import type { PdfJsDocumentProxy } from "src/types/pdfJsTypes";
import { DependencyGraph, DependencyGraphNode } from "./nestedDependencyTraversal";
export { splitFolderAndFilename } from "./pathUtils";
/**
 * Download data as file from Obsidian, to store on local device
 * @param encoding
 * @param data
 * @param filename
 */
export declare const download: (encoding: string | null, data: string | ArrayBuffer | null, filename: string) => void;
/**
 * Downloads a blob without converting it to a base64 data URL.
 *
 * @remarks
 * Object URLs avoid the large temporary strings and 33% base64 expansion that
 * can otherwise exhaust Electron's renderer process for large SVG or PNG files.
 */
export declare const downloadBlob: (blob: Blob, filename: string) => void;
/**
 * Generates the image filename based on the excalidraw filename
 * @param excalidrawPath - Full filepath of ExclidrawFile
 * @param newExtension - extension of IMG file in ".extension" format
 * @returns
 */
/**
 * Generates the image filename based on the excalidraw filename
 * @param path - path to the excalidraw file
 * @param extension - extension without the preceeding "."
 * @returns
 */
export declare function getIMGFilename(path: string, extension: string): string;
/**
 * Create new file, if file already exists find first unique filename by adding a number to the end of the filename
 * @param filename
 * @param folderpath
 * @returns
 */
export declare function getNewUniqueFilepath(vault: Vault, filename: string, folderpath: string): string;
export declare function getDrawingFilename(settings: ExcalidrawSettings): string;
export declare function getEmbedFilename(notename: string, settings: ExcalidrawSettings): string;
/**
 * Open or create a folderpath if it does not exist
 * @param folderpath
 */
export declare function checkAndCreateFolder(folderpath: string): Promise<TFolder>;
export declare const getURLImageExtension: (url: string) => string;
export declare const getMimeType: (extension: string) => MimeType;
export declare const getDataURLFromURL: (url: string, mimeType: MimeType, timeout?: number) => Promise<DataURL>;
/**
 * Decodes a base64 data URL into binary data, fetching remote URLs first.
 *
 * @param dataURL - A base64 data URL or an HTTP, HTTPS, or FTP URL.
 * @returns The decoded bytes, or `null` when the input cannot be resolved to a
 * base64 payload.
 * @remarks
 * Remote URL handling intentionally preserves the existing MIME inference and
 * `getDataURLFromURL()` fallback behavior used on desktop and mobile.
 */
export declare function getBinaryFileFromDataURL(dataURL: string): Promise<ArrayBuffer>;
export declare const blobToBase64: (blob: Blob) => Promise<string>;
export declare const arrayBufferToBase64: (arrayBuffer: ArrayBuffer) => string;
export declare const getPDFDoc: (f: TFile) => Promise<PdfJsDocumentProxy>;
export declare const readLocalFile: (filePath: string) => Promise<string>;
export declare const readLocalFileBinary: (filePath: string) => Promise<ArrayBuffer>;
export declare const getPathWithoutExtension: (f: TFile) => string;
export declare const getInternalLinkOrFileURLLink: (path: string, plugin: ExcalidrawPlugin, alias?: string, sourceFile?: TFile) => {
    link: string;
    isInternal: boolean;
    file?: TFile;
    url?: string;
};
/**
 * get markdown or wiki link
 * @param plugin
 * @param param1: { embed = true, path, alias }
 * @returns
 */
export declare const getLink: (plugin: ExcalidrawPlugin, { embed, path, alias, }: {
    embed?: boolean;
    path: string;
    alias?: string;
}, wikilinkOverride?: boolean) => string;
export declare const getAliasWithSize: (alias: string, size: string) => string;
export declare const getCropFileNameAndFolder: (plugin: ExcalidrawPlugin, hostPath: string, baseNewFileName: string) => Promise<{
    folderpath: string;
    filename: string;
}>;
export declare const getAnnotationFileNameAndFolder: (plugin: ExcalidrawPlugin, hostPath: string, baseNewFileName: string) => Promise<{
    folderpath: string;
    filename: string;
}>;
export declare const getListOfTemplateFiles: (plugin: ExcalidrawPlugin) => TFile[] | null;
export declare const fileShouldDefaultAsExcalidraw: (path: string, app: App) => boolean;
export interface NestedFileDependencyGraph extends DependencyGraph<TFile> {
    nodes: Map<string, DependencyGraphNode<TFile>>;
}
export interface NestedFileDependencyGraphContext extends NestedFileDependencyGraph {
    includeImages: boolean;
    parsedExcalidrawPaths: Set<string>;
}
export declare const createNestedFileDependencyGraphContext: (includeImages?: boolean) => NestedFileDependencyGraphContext;
/**
 * Builds a path-keyed dependency graph from Obsidian's metadata cache.
 * A context may be shared by related queries so each Excalidraw file is parsed
 * once. The context must remain scoped to one operation to avoid stale edges.
 */
export declare function getNestedFileDependencyGraph(plugin: ExcalidrawPlugin, rootFile: TFile, includeImages?: boolean, sharedContext?: NestedFileDependencyGraphContext): NestedFileDependencyGraph;
export declare const getExcalidrawEmbeddedFilesFiletree: (sourceFile: TFile, plugin: ExcalidrawPlugin) => TFile[];
export declare const hasExcalidrawEmbeddedImagesTreeChanged: (sourceFile: TFile, mtime: number, plugin: ExcalidrawPlugin, sharedContext?: NestedFileDependencyGraphContext) => boolean;
export declare function exportImageToFile(view: ExcalidrawView, path: string, content: string | ArrayBuffer | Blob, extension: string): Promise<TFile>;
export declare function importFileToVault(app: App, fname: string, content: string | ArrayBuffer | Blob, excalidrawFile: TFile, view?: ExcalidrawView): Promise<TFile>;
export declare function createOrOverwriteFile(app: App, path: string, content: string | ArrayBuffer | Blob): Promise<TFile>;
export declare function createFileAndAwaitMetacacheUpdate(app: App, path: string, content: string | ArrayBuffer | Blob): Promise<TFile>;
