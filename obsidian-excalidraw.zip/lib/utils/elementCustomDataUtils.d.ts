import type { Mutable } from "@zsviczian/excalidraw/types/common/src/utility-types";
import type { ExcalidrawElement, ExcalidrawImageElement } from "@zsviczian/excalidraw/types/element/src/types";
import type { PDFPageViewProps } from "src/types/embeddedFileLoaderTypes";
export type ExcalidrawCustomDataValue = string | number | boolean | null | ExcalidrawCustomDataValue[] | {
    [key: string]: ExcalidrawCustomDataValue;
};
export type ExcalidrawCustomData = Record<string, ExcalidrawCustomDataValue | undefined>;
export type ExcalidrawCustomDataPatch = Partial<ExcalidrawCustomData>;
export type ExcalidrawPDFCustomData = ExcalidrawCustomData & {
    pdfPageViewProps?: PDFPageViewProps;
};
export type ExcalidrawLatexCustomData = ExcalidrawCustomData & {
    latex?: string;
    latexscale?: number;
};
export type ExcalidrawImageWithCustomData<TCustomData extends ExcalidrawCustomData = ExcalidrawCustomData> = ExcalidrawImageElement & {
    customData?: TCustomData;
};
export declare function addAppendUpdateCustomData(el: Mutable<ExcalidrawElement>, newData: ExcalidrawCustomDataPatch): ExcalidrawElement;
