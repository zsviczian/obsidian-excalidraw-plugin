import type { App, TFile } from "obsidian";
import type { SelectableFontOption } from "src/types/fontTypes";
declare const MARKDOWN_FONT_FAMILY_IDS: {
    readonly Virgil: 1;
    readonly Cascadia: 3;
    readonly Excalifont: 5;
    readonly "Comic Shanns": 8;
    readonly "Liberation Sans": 9;
};
type MarkdownFontFamily = keyof typeof MARKDOWN_FONT_FAMILY_IDS;
export declare const MARKDOWN_FONT_FAMILIES: readonly MarkdownFontFamily[];
/** Returns Excalidraw's numeric identifier for a built-in Markdown font. */
export declare function getMarkdownFontFamilyId(fontFamily: string): number | null;
/** Returns vault font files that are eligible for user-selectable font lists. */
export declare function getSelectableFontFiles(app: App, fontAssetsPath: string): TFile[];
/** Builds a fresh font option list from bundled names and current vault files. */
export declare function getSelectableFontOptions(app: App, fontAssetsPath: string, builtInFonts?: readonly string[]): SelectableFontOption[];
export {};
