/**
 * Cross-window-safe type guards
 * Uses the element's own window (defaultView) to get the correct HTMLElement constructor.
 */
export declare function isInstanceOfHTMLElement(value: unknown): value is HTMLElement;
export declare function isInstanceOfHTMLDivElement(value: unknown): value is HTMLDivElement;
export declare function isInstanceOfHTMLBodyElement(value: unknown): value is HTMLBodyElement;
export declare function isInstanceOfHTMLImageElement(value: unknown): value is HTMLImageElement;
export declare function isInstanceOfElement(value: unknown): value is Element;
export declare function isInstanceOfDocumentFragment(value: unknown): value is DocumentFragment;
export declare function isInstanceOfSVGSVGElement(value: unknown): value is SVGSVGElement;
export declare function isInstanceOfSVGElement(value: unknown): value is SVGElement;
export declare function isInstanceOfHTMLStyleElement(value: unknown): value is HTMLStyleElement;
export declare function isInstanceOfHTMLInputElement(value: unknown): value is HTMLInputElement;
export declare function isInstanceOfHTMLTextAreaElement(value: unknown): value is HTMLTextAreaElement;
export declare function isInstanceOfHTMLSelectElement(value: unknown): value is HTMLSelectElement;
export declare function isInstanceOfHTMLButtonElement(value: unknown): value is HTMLButtonElement;
