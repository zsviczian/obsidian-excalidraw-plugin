/**
 * Reads only the SFNT metadata required to register a local Excalidraw font.
 *
 * @packageDocumentation
 */
/** Font metrics registered for Excalidraw's local font family. */
export interface FontMetrics {
    /** Raw `head.unitsPerEm` value. The narrow cast preserves uncommon values. */
    unitsPerEm: 1000 | 1024 | 2048;
    /** Raw `hhea.ascender` value. */
    ascender: number;
    /** Raw `hhea.descender` value. */
    descender: number;
    /** Unitless line height derived using the plugin's established formula. */
    lineHeight: number;
}
/**
 * Reads the vertical metrics needed by Excalidraw from a TTF or OTF buffer.
 *
 * @param fontData - Complete SFNT font data from a `.ttf` or `.otf` file.
 * @returns Parsed metrics, or `null` when the font is unsupported or malformed.
 * @remarks
 * Only the SFNT table directory plus `head.unitsPerEm`, `hhea.ascender`, and
 * `hhea.descender` are read. Glyph outlines, names, and layout tables are left
 * to the browser and Excalidraw, as they were never consumed by the plugin.
 */
export declare function getFontMetrics(fontData: ArrayBuffer): FontMetrics | null;
