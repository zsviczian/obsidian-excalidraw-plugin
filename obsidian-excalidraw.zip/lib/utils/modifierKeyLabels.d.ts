export declare const labelCTRL: () => "CMD" | "CTRL";
export declare const labelALT: () => "OPT" | "ALT";
export declare const labelMETA: () => "CTRL" | "WIN" | "META";
export declare const labelSHIFT: () => "SHIFT";
