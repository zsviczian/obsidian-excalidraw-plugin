import type { TFile, App } from "obsidian";
import type ExcalidrawPlugin from "src/core/main";
export { getEmbeddedFilenameParts } from "./embeddedFilenameParts";
/**
 * Loads a vault font and creates its data URL and `@font-face` definition.
 *
 * @param app - Obsidian application used to resolve and read the font file.
 * @param fontFileName - Vault link path or font filename to resolve.
 * @param sourcePath - Vault path from which the font link is resolved.
 * @param name - Optional font-family name overriding the file basename.
 * @returns The font definition, resolved family name, encoded data URL, and
 * original buffer. Empty strings and a null buffer are returned when the font
 * cannot be resolved.
 * @remarks
 * MIME types and CSS format names intentionally preserve the established
 * extension mapping used by plugin startup and embedded SVG font loading.
 */
export declare function getFontDataURL(app: App, fontFileName: string, sourcePath: string, name?: string): Promise<{
    fontDef: string;
    fontName: string;
    dataURL: string;
    arrayBuffer: ArrayBuffer | null;
}>;
/**
 * Encodes SVG markup as a base64 data URL.
 *
 * @param svg - Serialized SVG markup.
 * @returns A base64-encoded `data:image/svg+xml` URL.
 * @remarks
 * Literal `&nbsp;` entities are converted to spaces before encoding because
 * they are not valid predefined XML entities. URI encoding is converted to a
 * byte string before `btoa()` so non-Latin text remains UTF-8 safe.
 */
export declare function svgToBase64(svg: string): string;
/**
 * Loads an image source and reports its intrinsic dimensions.
 *
 * @param src - Image URL, blob URL, or data URL accepted by `HTMLImageElement`.
 * @returns The image's natural width and height after it loads.
 * @throws Rejects with the browser image error when loading fails.
 * @remarks
 * This intentionally preserves native image loading behavior without adding a
 * timeout, cross-origin mode, or rendered-size fallback.
 */
export declare function getImageSize(src: string): Promise<{
    height: number;
    width: number;
}>;
export declare function isMaskFile(plugin: ExcalidrawPlugin, file: TFile): boolean;
export declare function hasExportBackground(plugin: ExcalidrawPlugin, file: TFile): boolean;
export declare function getWithBackground(plugin: ExcalidrawPlugin, file: TFile): boolean;
export declare function getExportPadding(plugin: ExcalidrawPlugin, file: TFile): number;
/**
 * Copies a rectangular canvas region into a new canvas, optionally scaling it.
 * Based on: https://stackoverflow.com/a/54555834
 *
 * @param srcCanvas - Source canvas to crop.
 * @param crop - Source rectangle in canvas coordinates.
 * @param output - Destination dimensions; defaults to the crop dimensions.
 * @returns A newly created canvas containing the cropped image.
 * @remarks
 * This preserves the existing `drawImage()` behavior without clamping the
 * source rectangle or changing browser interpolation and transparency rules.
 */
export declare function cropCanvas(srcCanvas: HTMLCanvasElement, crop: {
    left: number;
    top: number;
    width: number;
    height: number;
}, output?: {
    width: number;
    height: number;
}): HTMLCanvasElement;
/**
 * Invokes a synchronous or asynchronous function through a promise boundary.
 *
 * @param fn - Function to invoke.
 * @param args - Arguments passed to `fn`.
 * @returns A promise that adopts the function's returned value or thenable.
 * @remarks Synchronous exceptions thrown by `fn` become promise rejections.
 */
export declare function promiseTry<TValue, TArgs extends unknown[]>(fn: (...args: TArgs) => PromiseLike<TValue> | TValue, ...args: TArgs): Promise<TValue>;
export declare class PromisePool<T> {
    private readonly pool;
    private readonly entries;
    constructor(source: IterableIterator<Promise<void | readonly [number, T]>>, concurrency: number);
    all(): Promise<T[]>;
}
