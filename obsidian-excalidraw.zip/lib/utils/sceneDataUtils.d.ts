import type { ExcalidrawElement } from "@zsviczian/excalidraw/types/element/src/types";
import type { AppState } from "@zsviczian/excalidraw/types/excalidraw/types";
import type { TFile } from "obsidian";
import type ExcalidrawPlugin from "src/core/main";
import { arrayToMap } from "./collectionUtils";
export { arrayToMap };
export { getBinaryFileFromDataURL } from "./fileUtils";
export { getLinkParts } from "./linkUtils";
export type { LinkParts } from "./linkUtils";
export { wrapTextAtCharLength } from "./textUtils";
export { isVersionNewerThanOther } from "./versionUtils";
export declare function compressAsync(data: string): Promise<string>;
export declare function compress(data: string): string;
export declare function decompressAsync(data: string): Promise<string>;
export declare function decompress(data: string): string;
export declare function hasExportTheme(plugin: ExcalidrawPlugin, file: TFile): boolean;
export declare function getExportTheme(plugin: ExcalidrawPlugin, file: TFile, theme: string): string;
/**
 * Updates or inserts simple, single-line properties in serialized frontmatter.
 *
 * @param data - Markdown text whose frontmatter should be updated.
 * @param keyValuePairs - Property names and serialized values to apply.
 * @returns The updated text, or the original text when there is nothing to do.
 * @remarks
 * This intentionally preserves the existing string-based behavior: it does not
 * parse YAML, and insertion requires an opening `---` followed by a newline.
 */
export declare function updateFrontmatterInString(data: string, keyValuePairs?: [string, string][]): string;
export declare function _getContainerElement(element: (ExcalidrawElement & {
    containerId: ExcalidrawElement["id"] | null;
}) | null, scene: {
    elements?: ExcalidrawElement[];
    appState?: AppState;
}): import("@zsviczian/excalidraw/types/element/src/types").ExcalidrawTextContainer;
