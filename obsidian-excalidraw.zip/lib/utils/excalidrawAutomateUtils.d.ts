import { ExcalidrawAutomate } from "src/shared/ExcalidrawAutomate";
import { BinaryFileData, DataURL, AppState, BinaryFiles } from "@zsviczian/excalidraw/types/excalidraw/types";
import type ExcalidrawPlugin from "src/core/main";
import { ExcalidrawElement, FixedPoint } from "@zsviczian/excalidraw/types/element/src/types";
import { TFile } from "obsidian";
import type ExcalidrawView from "src/view/ExcalidrawView";
import { EmbeddedFilesLoader } from "src/shared/EmbeddedFileLoader";
import { ScriptSettingValue, SVGColorInfo } from "src/types/excalidrawAutomateTypes";
import { ExcalidrawData } from "src/shared/ExcalidrawData";
import { ColorMap } from "src/types/embeddedFileLoaderTypes";
import { ExportSettings } from "src/types/exportUtilTypes";
import type { StrokeWidthKey } from "@zsviczian/excalidraw/types/common/src/constants";
export { cloneElement, estimateBounds, getBoundTextElementId, repositionElementsToCursor, } from "./excalidrawElementUtils";
export declare function isSVGColorInfo(obj: ColorMap | SVGColorInfo): boolean;
export declare function mergeColorMapIntoSVGColorInfo(colorMap: ColorMap, svgColorInfo: SVGColorInfo): SVGColorInfo;
export declare function svgColorInfoToColorMap(svgColorInfo: SVGColorInfo): ColorMap;
export declare function filterColorMap(colorMap: ColorMap): ColorMap;
export declare function updateOrAddSVGColorInfo(svgColorInfo: SVGColorInfo, color: string, info: {
    fill?: boolean;
    stroke?: boolean;
    mappedTo?: string;
}): SVGColorInfo;
export declare function getEmbeddedFileForImageElment(ea: ExcalidrawAutomate, el: ExcalidrawElement): import("src/shared/EmbeddedFileLoader").EmbeddedFile;
export declare function errorMessage(message: string, source: string): void;
export declare function isImageOrPDFTransclusion(ea: ExcalidrawAutomate, text: string): boolean;
export declare function isColorStringTransparent(color: string): boolean;
export declare function initExcalidrawAutomate(plugin: ExcalidrawPlugin): ExcalidrawAutomate;
export declare function normalizeLinePoints(points: [x: number, y: number][]): number[][];
export declare function getLineBox(points: [x: number, y: number][]): {
    x: number;
    y: number;
    w: number;
    h: number;
};
export declare function _measureText(newText: string, fontSize: number, fontFamily: number, lineHeight: number): {
    w: number;
    h: number;
};
export declare function getTemplate(plugin: ExcalidrawPlugin, fileWithPath: string, loadFiles: boolean, loader: EmbeddedFilesLoader, depth: number, convertMarkdownLinksToObsidianURLs?: boolean): Promise<{
    elements: ExcalidrawElement[];
    appState: Partial<AppState>;
    frontmatter: string;
    files: BinaryFiles;
    hasSVGwithBitmap: boolean;
    plaintext: string;
}>;
export declare const generatePlaceholderDataURL: (width: number, height: number) => DataURL;
export declare function createPNG(templatePath: string, scale: number, exportSettings: ExportSettings, loader: EmbeddedFilesLoader, forceTheme: string, canvasTheme: string, canvasBackgroundColor: string, automateElements: ExcalidrawElement[], plugin: ExcalidrawPlugin, depth: number, padding?: number, imagesDict?: Record<ExcalidrawElement["id"], BinaryFileData>, overrideFiles?: Record<ExcalidrawElement["id"], BinaryFileData>): Promise<Blob>;
export declare const updateElementLinksToObsidianLinks: ({ elements, hostFile, }: {
    elements: ExcalidrawElement[];
    hostFile: TFile;
}) => ExcalidrawElement[];
export declare function createSVG(templatePath: string, embedFont: boolean, exportSettings: ExportSettings, loader: EmbeddedFilesLoader, forceTheme: string, canvasTheme: string, canvasBackgroundColor: string, automateElements: ExcalidrawElement[], plugin: ExcalidrawPlugin, depth: number, padding?: number, imagesDict?: Record<ExcalidrawElement["id"], BinaryFileData>, convertMarkdownLinksToObsidianURLs?: boolean, includeInternalLinks?: boolean, overrideFiles?: Record<ExcalidrawElement["id"], BinaryFileData>): Promise<SVGSVGElement>;
export declare const search: (view: ExcalidrawView) => Promise<void>;
/**
 *
 * @param elements
 * @param query
 * @param exactMatch - when searching for section header exactMatch should be set to true
 * @returns the elements matching the query
 */
export declare const getTextElementsMatchingQuery: (elements: ExcalidrawElement[], query: string[], exactMatch?: boolean) => ExcalidrawElement[];
/**
 *
 * @param elements
 * @param query
 * @param exactMatch - when searching for section header exactMatch should be set to true
 * @returns the elements matching the query
 */
export declare const getFrameElementsMatchingQuery: (elements: ExcalidrawElement[], query: string[], exactMatch?: boolean) => ExcalidrawElement[];
/**
 *
 * @param elements
 * @param query
 * @param exactMatch - when searching for section header exactMatch should be set to true
 * @returns the elements matching the query
 */
export declare const getElementsWithLinkMatchingQuery: (elements: ExcalidrawElement[], query: string[], exactMatch?: boolean) => ExcalidrawElement[];
/**
 *
 * @param elements
 * @param query
 * @param exactMatch - when searching for section header exactMatch should be set to true
 * @returns the elements matching the query
 */
export declare const getImagesMatchingQuery: (elements: ExcalidrawElement[], query: string[], excalidrawData: ExcalidrawData, exactMatch?: boolean) => ExcalidrawElement[];
export declare const verifyMinimumPluginVersion: (requiredVersion: string) => boolean;
/**
 *
 * FixedPoint represents the fixed point binding information in form of a vertical and
 * horizontal ratio (i.e. a percentage value in the 0.0-1.0 range). This ratio
 * gives the user selected fixed point by multiplying the bound element width
 * with fixedPoint[0] and the bound element height with fixedPoint[1] to get the
 * bound element-local point coordinate.
 */
export declare const normalizeFixedPoint: <T extends FixedPoint | null | undefined>(fixedPoint: T) => T extends null ? null : FixedPoint;
export declare const normalizeBindMode: (bindMode?: string) => "orbit" | "inside";
/**
 * Ensures that plugin.settings.scriptEngineSettings and the active script's settings object exist.
 * Handles undefined/null during initialization.
 *
 * Note: kept in utils (not as an EA private method) so it won't be exposed on window.ExcalidrawAutomate.
 */
export declare function ensureActiveScriptSettingsObject(ea: ExcalidrawAutomate): Record<string, ScriptSettingValue> | null;
export declare const getStrokeKeyFormLegacyWidth: (strokeWidth: number) => StrokeWidthKey;
export declare const getStrokeWidthKeyByWidth: (strokeWidth: number) => StrokeWidthKey | "extraBold" | undefined;
export declare const getAppStateStrokeWidthEntry: (strokeWidthKey: StrokeWidthKey, legacyStrokeWidth: number) => {
    currentItemStrokeWidth: number;
    currentItemStrokeWidthKey?: undefined;
} | {
    currentItemStrokeWidth?: undefined;
    currentItemStrokeWidthKey?: undefined;
} | {
    currentItemStrokeWidthKey: StrokeWidthKey;
    currentItemStrokeWidth?: undefined;
};
export declare const getFreedrawStrokeWidthByKey: (strokeWidthKey: StrokeWidthKey, strokeWidth?: number) => ExcalidrawElement["strokeWidth"];
