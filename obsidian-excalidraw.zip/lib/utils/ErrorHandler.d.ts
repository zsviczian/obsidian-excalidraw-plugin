/**
 * Centralized error handling for the Excalidraw plugin
 */
export declare class ErrorHandler {
    private static instance;
    private errorLog;
    private errorNoticeTimeout;
    private maxLogEntries;
    private constructor();
    /**
     * Get singleton instance of ErrorHandler
     */
    static getInstance(): ErrorHandler;
    /**
     * Handles errors consistently across the plugin
     * @param error The error object
     * @param context Context information about where the error occurred
     * @param showNotice Whether to show a user-facing notice
     * @param timeout How long to show the notice (in ms)
     */
    handleError(error: Error | string, context: string, showNotice?: boolean, timeout?: number): void;
    /**
     * Safely evaluates code with error handling
     * @param code The code to evaluate
     * @param context The context where evaluation is happening
     * @param win The window object for evaluation context
     * @param fallback Optional fallback value if evaluation fails
     */
    safeEval<T>(code: string, context: string, win: Window, fallback?: T): T;
    /**
     * Wraps a function with try/catch and error handling
     * @param fn Function to wrap
     * @param context Context for error reporting
     * @param fallback Optional fallback value if function fails
     */
    wrapWithTryCatch<T>(fn: () => T, context: string, fallback?: T): T;
    /**
     * Format error message for user-facing notifications
     */
    private formatErrorForUser;
    /**
     * Get recent errors for debugging
     */
    getErrorLog(): Array<{
        error: Error;
        context: string;
        timestamp: number;
    }>;
    /**
     * Clear error log
     */
    clearErrorLog(): void;
}
export declare const errorHandler: ErrorHandler;
