import { PenStyle, PenType } from "src/types/penTypes";
export declare const PENS: Record<PenType, PenStyle>;
