import type { FILENAMEPARTS } from "src/types/utilTypes";
/**
 * Splits an embedded-file link into its path, reference, alias, and image-reference metadata.
 *
 * Image references may end in a non-negative `,padding=N` parameter. The parameter is
 * removed from the resolved block or section reference while the original link text is
 * retained in `linkpartReference` so nested export paths can be parsed again.
 */
export declare function getEmbeddedFilenameParts(fname: string): FILENAMEPARTS;
/** Returns whether parsed filename parts select an image-reference region. */
export declare function isImagePartRef(parts: FILENAMEPARTS): boolean;
