import type { DataURL } from "@zsviczian/excalidraw/types/excalidraw/types";
/**
 * Converts an in-memory browser Blob to a data URL without reading from disk.
 *
 * @param blob - Browser Blob to encode.
 * @returns The Blob contents encoded as a data URL.
 * @remarks Uses the Web FileReader API and is safe in Obsidian's desktop and
 * mobile WebViews. Vault file access must still use Obsidian's Vault API.
 */
export declare function blobToDataURL(blob: Blob): Promise<DataURL>;
export declare function getDataURL(file: ArrayBuffer, mimeType: string): Promise<DataURL>;
export declare function errorlog(data: object): void;
