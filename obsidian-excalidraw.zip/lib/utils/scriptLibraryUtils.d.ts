import { TFile, type App } from "obsidian";
import type { ScriptStoreInstallState } from "src/types/scriptStoreTypes";
type ScriptLibrarySettings = {
    scriptFolderPath: string;
    allowJavaScriptFiles: boolean;
    storeScriptFilesAsJavaScript: boolean;
};
type ScriptLibraryScriptEngine = {
    getScriptName(file: TFile | string): string;
    withScriptFileEventsSuspended<T>(operation: () => Promise<T>): Promise<T>;
    refreshManagedScriptFile(file: TFile): Promise<void>;
    removeManagedScriptFile(scriptPath: string, scriptName: string): Promise<void>;
    renameManagedScriptFile(file: TFile, destinationPath: string): Promise<void>;
};
/** Narrow plugin surface required by the community-script library helpers. */
export type ScriptLibraryPluginContext = {
    app: App;
    settings: ScriptLibrarySettings;
    scriptEngine: ScriptLibraryScriptEngine;
};
/** Returns all managed local copies for one community script. */
export declare const getInstalledScriptFiles: (plugin: ScriptLibraryPluginContext, source: string) => TFile[];
/**
 * Returns the primary managed local copy for one community script.
 * A copy directly under Downloaded wins; otherwise the shallowest grouped copy
 * is used. Additional copies are intentionally ignored for update detection.
 */
export declare const getInstalledScriptFile: (plugin: ScriptLibraryPluginContext, source: string) => TFile | null;
/** Returns existing group folders relative to the Downloaded folder. */
export declare const getInstalledScriptGroups: (plugin: ScriptLibraryPluginContext) => string[];
/** Moves an installed script and its optional icon to a relative script group. */
export declare const moveInstalledScriptToGroup: (plugin: ScriptLibraryPluginContext, source: string, relativeGroup: string, localPath?: string) => Promise<TFile>;
/** Removes an installed community script and its optional local icon. */
export declare const uninstallScript: (plugin: ScriptLibraryPluginContext, source: string, localPath?: string) => Promise<void>;
/**
 * Resolves one community script's install/update state using the legacy mtime
 * contract. directory-info.json is the compatibility source of truth.
 */
export declare const getScriptInstallStates: (plugin: ScriptLibraryPluginContext, sources: readonly string[]) => Promise<Map<string, ScriptStoreInstallState>>;
/** Resolves one community script's install/update state. */
export declare const getScriptInstallState: (plugin: ScriptLibraryPluginContext, source: string) => Promise<ScriptStoreInstallState>;
export type InstalledScriptResult = {
    scriptFile: TFile;
    iconFile: TFile | null;
};
/** Installs or updates one managed community script. */
export declare const installScript: (plugin: ScriptLibraryPluginContext, source: string, showNotice?: boolean) => Promise<InstalledScriptResult>;
/**
 * Returns community scripts with updates, considering only managed copies under
 * the Downloaded folder. When duplicate managed copies exist, update detection
 * uses the same primary-copy selection as the script-store details page.
 */
export declare const getInstalledScriptUpdates: (plugin: ScriptLibraryPluginContext) => Promise<string[]>;
export {};
