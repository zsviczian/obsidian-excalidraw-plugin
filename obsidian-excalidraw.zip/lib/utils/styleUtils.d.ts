import { Setting } from "obsidian";
export declare const setButtonBgColor: (button: HTMLButtonElement, state: "normal" | "accent" | "success") => void;
export declare const hideElement: (el: HTMLElement) => void;
export declare const showElement: (el: HTMLElement) => void;
export declare const setComponentVisibility: (comp: Setting, visible: boolean) => void;
type StyleObject = Partial<CSSStyleDeclaration> & {
    [key: `--${string}`]: string | undefined;
};
export declare const setStyle: (element: HTMLElement | SVGElement | null | undefined, styles: StyleObject) => void;
export declare const removeStyle: (element: HTMLElement | SVGSVGElement | null | undefined, properties: string[]) => void;
export {};
