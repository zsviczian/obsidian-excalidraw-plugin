import { PageDimensions, PageOrientation, PageSize, PDFExportScale, PDFMargin, PDFPageMarginString, PDFPageProperties } from "src/types/exportUtilTypes";
export declare function getMarginValue(margin: PDFPageMarginString): PDFMargin;
export declare function getPageDimensions(pageSize: PageSize, orientation: PageOrientation, dims?: {
    width: number;
    height: number;
}): PageDimensions;
export declare function exportToPDF({ SVG, scale, pageProps, filename, }: {
    SVG: SVGSVGElement[];
    scale: PDFExportScale;
    pageProps: PDFPageProperties;
    filename: string;
}): Promise<void>;
export declare function exportSVGToClipboard(svg: SVGSVGElement): Promise<void>;
export declare function exportPNGToClipboard(png: Blob): Promise<void>;
export declare function exportPNG(png: Blob, filename: string): void;
export declare function exportSVG(svg: SVGSVGElement, filename: string): void;
