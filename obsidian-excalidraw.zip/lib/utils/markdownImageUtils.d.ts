import type { MarkdownImageCustomData, MarkdownImageRenderSettings } from "src/types/markdownImageTypes";
/** View-local identity of the inputs used to render a Markdown image. */
export type MarkdownImageRenderCacheEntry = {
    markdown: string;
    configuration: string;
};
/** Resolves a complete render configuration from stored values and defaults. */
export declare function resolveMarkdownImageRenderSettings(defaults: MarkdownImageRenderSettings, stored?: MarkdownImageRenderSettings | null): MarkdownImageRenderSettings;
/** Captures every persisted or defaulted input that can affect SVG rendering. */
export declare function createMarkdownImageRenderCacheEntry(markdown: string, sourceFilePath: string, customData: MarkdownImageCustomData, render: MarkdownImageRenderSettings): MarkdownImageRenderCacheEntry;
