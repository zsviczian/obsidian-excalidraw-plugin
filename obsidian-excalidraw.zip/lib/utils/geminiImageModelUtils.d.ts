import { AIProvider } from "src/types/AIUtilTypes";
export type GeminiImageSizeTier = "512" | "1K" | "2K" | "4K";
export type GeminiImageSizeEntry = {
    aspectRatio: string;
    size: string;
    imageSize?: GeminiImageSizeTier;
};
export declare const isGeminiImageModel: (provider?: AIProvider, model?: string) => boolean;
export declare const getGeminiSupportedSizes: (provider?: AIProvider, model?: string) => string[];
export declare const getGeminiImageRequestConfig: (provider?: AIProvider, model?: string, size?: string) => {
    aspectRatio: string;
    imageSize?: GeminiImageSizeTier;
} | null;
