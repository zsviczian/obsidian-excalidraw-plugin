import { ExcalidrawAutomate } from "src/shared/ExcalidrawAutomate";
import ExcalidrawView from "src/view/ExcalidrawView";
import { DynamicStyle } from "src/types/types";
export declare const setDynamicStyle: (ea: ExcalidrawAutomate, view: ExcalidrawView, //the excalidraw view
color: string, dynamicStyle: DynamicStyle, textBackgroundColor?: string) => void;
export declare function getHighlightColor(ea: ExcalidrawAutomate, bgColor: string, opacity?: number): string;
