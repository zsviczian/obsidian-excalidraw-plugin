import { type App } from "obsidian";
export declare function splitFolderAndFilename(filepath: string | undefined): {
    folderpath: string;
    filename: string;
    basename: string;
    extension: string;
};
export declare const cleanSectionHeading: (heading: string) => string;
export declare const cleanBlockRef: (blockRef: string) => string;
export declare const getAttachmentsFolderAndFilePath: (app: App, activeViewFilePath: string, newFileName: string) => Promise<{
    folder: string;
    filepath: string;
}>;
