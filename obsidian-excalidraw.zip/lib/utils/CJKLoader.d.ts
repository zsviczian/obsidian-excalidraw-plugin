import ExcalidrawPlugin from "src/core/main";
interface ExcalidrawFontFaceDescriptor {
    uri: string;
    descriptors?: FontFaceDescriptors;
}
/** A locally loaded CJK subset with the descriptors required for font matching. */
export interface CJKFontFaceData {
    dataURL: string;
    descriptors?: FontFaceDescriptors;
}
export declare function matchesCJKRange(descriptor: ExcalidrawFontFaceDescriptor, rangesToLoad: {
    c: boolean;
    j: boolean;
    k: boolean;
}): boolean;
/**
 * Loads the locally configured CJK font subsets selected by plugin settings.
 *
 * @param plugin - Plugin instance used to resolve settings and read font files.
 * @returns Loaded subsets with their original descriptors, `undefined` when no
 * CJK range is enabled, or `false` when no matching local font could be loaded.
 */
export declare function getCJKFontFaceData(plugin: ExcalidrawPlugin): Promise<CJKFontFaceData[] | undefined | false>;
export {};
