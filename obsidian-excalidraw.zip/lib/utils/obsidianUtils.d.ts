import { App, Editor, MarkdownView, OpenViewState, TextFileView, TFile, View, Workspace, WorkspaceLeaf, WorkspaceSplit } from "obsidian";
import ExcalidrawPlugin from "../core/main";
import { ModifierKeys } from "./modifierkeyHelper";
import { FRONTMATTER_KEYS } from "src/constants/constants";
import type ExcalidrawView from "src/view/ExcalidrawView";
export declare const getParentOfClass: (element: Element, cssClass: string) => HTMLElement | null;
export declare function getExcalidrawViews(app: App, initializedOnly?: boolean): ExcalidrawView[];
export declare function getExcalidraAndMarkdowViewsForFile(app: App, file: TFile): TextFileView[];
export declare const getLeaf: (plugin: ExcalidrawPlugin, origo: WorkspaceLeaf, ev: ModifierKeys) => WorkspaceLeaf;
export declare const getNewOrAdjacentLeaf: (plugin: ExcalidrawPlugin, leaf: WorkspaceLeaf) => WorkspaceLeaf | null;
export declare const isObsidianThemeDark: () => boolean;
export type ConstructableWorkspaceSplit = new (ws: Workspace, dir: "horizontal" | "vertical") => WorkspaceSplit;
export declare const getContainerForDocument: (doc: Document) => import("obsidian").WorkspaceContainer;
export declare const legacyCleanBlockRef: (blockRef: string) => string;
export declare const getAllWindowDocuments: (app: App) => Document[];
export declare const obsidianPDFQuoteWithRef: (text: string) => {
    quote: string;
    link: string;
};
export declare const extractSVGPNGFileName: (text: string) => string;
export declare const getFileCSSClasses: (file: TFile) => string[];
export declare const getActivePDFPageNumberFromPDFView: (view: View) => number;
export declare const openLeaf: ({ plugin, fnGetLeaf, file, openState, }: {
    plugin: ExcalidrawPlugin;
    fnGetLeaf: () => WorkspaceLeaf;
    file: TFile;
    openState?: OpenViewState;
}) => {
    leaf: WorkspaceLeaf;
    promise: Promise<void>;
};
/**
 * Merges an Excalidraw Markdown template into a target Markdown document.
 *
 * Existing target frontmatter values take precedence. Arrays present in both
 * documents are merged in target-first order, while template-only keys are
 * appended using Obsidian's YAML parser and serializer.
 *
 * @param template - Template Markdown containing frontmatter and optional body.
 * @param target - Target Markdown whose existing frontmatter is preserved.
 * @returns The merged Markdown document.
 */
export declare function mergeMarkdownFiles(template: string, target: string): string;
export declare const editorInsertText: (editor: Editor, text: string) => void;
export declare const foldExcalidrawSection: (view: MarkdownView) => void;
export declare function setExcalidrawView(leaf: WorkspaceLeaf): Promise<void>;
export declare function closeLeafView(leaf: WorkspaceLeaf): Promise<void>;
export declare function isUnwantedLeaf(leaf: WorkspaceLeaf): boolean;
/**
 * Gets the height of an audio element in Obsidian's CSS environment
 * @returns The height of the audio element in pixels
 */
export declare function getAudioElementHeight(): number;
export declare function stripYamlFrontmatter(text: string): string;
export declare function strictArrayBuffer(buffer: ArrayBuffer | SharedArrayBuffer): ArrayBuffer;
type FrontmatterTypeMap = {
    text: string;
    checkbox: boolean;
    number: number;
};
type FrontmatterValueType<T extends keyof typeof FRONTMATTER_KEYS> = FrontmatterTypeMap[(typeof FRONTMATTER_KEYS)[T]["type"]];
export type ValidFrontmatter = {
    [K in keyof typeof FRONTMATTER_KEYS as (typeof FRONTMATTER_KEYS)[K]["name"]]?: FrontmatterValueType<K>;
};
export declare function getSafeFrontmatter(frontmatter: unknown): ValidFrontmatter;
export {};
